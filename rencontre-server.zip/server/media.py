"""Bounded image decoding and derived previews; no filesystem paths in public URLs."""
from functools import lru_cache
from io import BytesIO
import warnings

from PIL import Image, ImageOps, UnidentifiedImageError

Image.MAX_IMAGE_PIXELS = 20_000_000


def previews(data):
    """Validate once and produce still previews; preserve uploaded animation/original."""
    with warnings.catch_warnings():
        warnings.simplefilter('error', Image.DecompressionBombWarning)
        try:
            with Image.open(BytesIO(data)) as source:
                source.load()
                image = ImageOps.exif_transpose(source).convert('RGBA' if 'A' in source.getbands() else 'RGB')
                result = []
                for size, edge, quality in (('avatar', 384, 90), ('thumb', 640, 82)):
                    small = image.copy()
                    small.thumbnail((edge, edge), Image.Resampling.LANCZOS)
                    output = BytesIO()
                    small.save(output, 'WEBP', quality=quality, method=4)
                    result.append((size, 'image/webp', output.getvalue()))
                return result
        except (UnidentifiedImageError, OSError, ValueError, Image.DecompressionBombWarning, Image.DecompressionBombError) as error:
            raise ValueError('图片无法解码或尺寸过大，请选择有效且不超过 2000 万像素的图片') from error


@lru_cache(maxsize=8)
def legacy_preview(data, size):
    # Existing originals are not rewritten during read requests.
    return next((mime, content) for name, mime, content in previews(data) if name == size)
