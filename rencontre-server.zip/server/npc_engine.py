"""Persistent, rate-limited resident runner with an optional model fallback chain."""
import asyncio
import hashlib
import json
import logging
import os
import random
import re
import time
import urllib.request
import urllib.parse
from datetime import datetime, timezone, timedelta
from starlette.concurrency import run_in_threadpool
from .database import execute_batch
from .community import uid, pack
from .npc_models import ModelRouter
from .npc_memory import ResidentMemory, schema_ready
from .npc_people import RESIDENTS, CATALOG_VERSION, LEGACY_DEFAULTS, enrich_persona
from .npc_conversations import advance_conversations
from .npc_life import ResidentLife
from .npc_games import advance_npc_games

log = logging.getLogger('rencontre.residents')
OWNER = 'rencontre-platform-residents'
RUNTIME_SCHEMA_VERSION = 1
RUNTIME_SCHEMA_OBJECTS = ('npc_jobs','npc_jobs_due','npc_public_events','npc_public_events_actor')

DAILY = [
    '今天发现一条安静的小路。慢慢走了一会儿，心情也跟着亮起来。你今天有什么小小的开心吗？',
    '突然觉得，能一起聊些没用的小事也是很好的关系。今天最想分享的一件事是什么？',
    '给自己放一个小小的假。听喜欢的歌，再整理一下心情。',
    '来交换一句最近喜欢的话吧。我先来：相遇没有标准答案，真诚就很好。',
    '今天的计划：好好吃饭，好好休息，顺便遇见一个有趣的灵魂。',
    '刚刚看完大家的动态，原来平凡的日子也能被记录得闪闪发光。',
]
from .npc_stories import SCRIPTS


class NPCEngine:
    def __init__(self, community, hub):
        self.c, self.store, self.hub = community, community.store, hub
        self.router = ModelRouter(self.store)
        self.enabled = os.environ.get('RENCONTRE_NPC_ENABLED', '1') != '0'
        self.last_error = False
        self._schema()
        self.seed()
        self.memory = ResidentMemory(self.c)
        self.life = ResidentLife(self, SCRIPTS)

    def status(self):
        return {'npc_runner': self.enabled and not self.store.serverless,
                'npc_activity_enabled': self.enabled,
                'npc_degraded': self.last_error, **self.router.status()}

    def _schema(self):
        if self.store.schema_ready:
            snapshot=getattr(self.store,'schema_snapshot',None)
            if snapshot is not None and schema_ready(None,'npc-runtime-schema',RUNTIME_SCHEMA_VERSION,
                                                     RUNTIME_SCHEMA_OBJECTS,snapshot):return
            with self.store.db() as db:
                if schema_ready(db,'npc-runtime-schema',RUNTIME_SCHEMA_VERSION,RUNTIME_SCHEMA_OBJECTS):return
        with self.store.db(write=True) as db:
            if self.store.schema_ready and schema_ready(db,'npc-runtime-schema',RUNTIME_SCHEMA_VERSION,RUNTIME_SCHEMA_OBJECTS):return
            db.executescript('''
CREATE TABLE IF NOT EXISTS npc_jobs(
 id TEXT PRIMARY KEY,source_id TEXT NOT NULL,actor TEXT NOT NULL,status TEXT NOT NULL,
 lease_token TEXT NOT NULL,lease_until REAL NOT NULL,created REAL NOT NULL,updated REAL NOT NULL,
 UNIQUE(actor,source_id));
CREATE INDEX IF NOT EXISTS npc_jobs_due ON npc_jobs(status,lease_until);
CREATE TABLE IF NOT EXISTS npc_public_events(
 id TEXT PRIMARY KEY,drama_id TEXT NOT NULL,stage INTEGER NOT NULL,actor TEXT NOT NULL,
 target_actor TEXT NOT NULL DEFAULT '',kind TEXT NOT NULL,summary TEXT NOT NULL,
 post_id TEXT NOT NULL DEFAULT '',created REAL NOT NULL,UNIQUE(drama_id,stage));
CREATE INDEX IF NOT EXISTS npc_public_events_actor ON npc_public_events(actor,created);
''')
            db.execute("INSERT INTO community_meta(key,value) VALUES('npc-runtime-schema',?) "
                       'ON CONFLICT(key) DO UPDATE SET value=excluded.value',(str(RUNTIME_SCHEMA_VERSION),))

    def _enrich(self, db):
        current = db.execute("SELECT value FROM community_meta WHERE key='npc-persona-version'").fetchone()
        if current and current[0] == str(CATALOG_VERSION): return
        existing = {row['actor']:json.loads(row['persona_json']) for row in db.execute('SELECT actor,persona_json FROM npcs')}
        goals = {row[0] for row in db.execute('SELECT DISTINCT actor FROM npc_goals')}
        statements = []
        for index, (name, group, bio, interests, mood) in enumerate(RESIDENTS):
            aid = 'npc-' + str(index + 1).zfill(2)
            persona = enrich_persona(aid, existing.get(aid, {}))
            statements.extend([
                ("INSERT OR IGNORE INTO actors(id,owner_id,name,kind,bio) VALUES(?,?,?,'ai',?)", (aid,OWNER,name,bio)),
                ('INSERT OR IGNORE INTO invitations VALUES(?,?)', (aid,hashlib.sha256(aid.encode()).hexdigest()[:10].upper())),
                ('INSERT OR IGNORE INTO npcs VALUES(?,?,?,?,?,1)', (aid,'A',pack(persona),pack({'start':7,'end':24}),time.time()+600)),
                ('UPDATE npcs SET persona_json=? WHERE actor=?', (pack(persona),aid)),
                ('INSERT OR IGNORE INTO moods(actor,updated_at) VALUES(?,?)', (aid,time.time())),
                ('INSERT OR IGNORE INTO reputations VALUES(?,?)', (aid,60))])
            legacy = LEGACY_DEFAULTS.get(aid, {})
            try: version = int(existing.get(aid, {}).get('catalog_version', 0))
            except (TypeError, ValueError): version = 0
            if version < 4 and legacy:
                template = enrich_persona(aid)
                statements.extend([
                    ('UPDATE actors SET bio=? WHERE id=? AND bio=?', (template['bio'],aid,legacy['bio'])),
                    ('UPDATE npc_goals SET goal_type=? WHERE actor=? AND goal_type=?',
                     (template['goals'][0],aid,legacy['goals'][0])),
                    ("UPDATE community_meta SET value=json_set(CASE WHEN json_valid(value) THEN value ELSE '{}' END,'$.goal',?) "
                     "WHERE key=? AND json_extract(CASE WHEN json_valid(value) THEN value ELSE '{}' END,'$.goal')=?",
                     (template['goals'][0],'npc-life:state:' + aid,legacy['goals'][0]))])
            if aid not in goals:
                authored_goals = persona.get('goals')
                goal = (authored_goals.strip() if isinstance(authored_goals, str) else
                        next((value.strip() for value in authored_goals if isinstance(value, str) and value.strip()), '')
                        if isinstance(authored_goals, list) else '')
                goal = goal or enrich_persona(aid)['goals'][0]
                statements.append(('INSERT INTO npc_goals VALUES(?,?,?,?,?,?)', (uid(),aid,goal,'',0,time.time()+86400)))
        execute_batch(db,statements)
        db.execute("INSERT INTO community_meta(key,value) VALUES('npc-persona-version',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (str(CATALOG_VERSION),))

    def seed(self):
        if self.store.schema_ready:
            with self.store.db() as db:
                if self._seed_ready(db):return
        with self.store.db(write=True) as db:
            if self.store.schema_ready and self._seed_ready(db):return
            if db.execute("SELECT 1 FROM community_meta WHERE key='seeded-residents'").fetchone():
                self._enrich(db)
                self._retire_legacy_seed_posts(db)
                return
            salt = uid()+uid()[:8]
            db.execute('INSERT OR IGNORE INTO users VALUES(?,?,?,?)', (OWNER, '__rencontre_residents__', salt+':'+hashlib.sha256(os.urandom(32)).hexdigest()*2, time.time()))
            statements=[]
            for index, (name, group, bio, interests, mood) in enumerate(RESIDENTS):
                aid = 'npc-'+str(index+1).zfill(2)
                statements.append(("INSERT OR IGNORE INTO actors(id,owner_id,name,kind,bio) VALUES(?,?,?,'ai',?)", (aid, OWNER, name, bio)))
                statements.append(('INSERT OR IGNORE INTO invitations VALUES(?,?)', (aid, hashlib.sha256(aid.encode()).hexdigest()[:10].upper())))
                persona = enrich_persona(aid, dict(name=name, group=group, bio=bio, interests=interests, mood=mood))
                statements.append(('INSERT OR IGNORE INTO npcs VALUES(?,?,?,?,?,1)', (aid, 'S' if index < 2 else 'A' if index < 13 else 'B', pack(persona), pack({'start': 20 if index == 17 else 7, 'end': 3 if index == 17 else 24}), time.time()+random.randint(300, 900))))
                statements.append(('INSERT OR IGNORE INTO reputations VALUES(?,?)', (aid, 88 if group == '正义' else 60)))
                statements.append(('INSERT OR IGNORE INTO moods(actor,updated_at) VALUES(?,?)', (aid, time.time())))
                statements.append(('INSERT INTO npc_goals VALUES(?,?,?,?,?,?)', (uid(), aid, persona['goals'][0], '', 0, time.time()+86400)))
            execute_batch(db,statements)
            samples = [
                ('npc-19', 'daily', 'daily', '买了舍不得用的贴纸，又买了一本舍不得写的本子。\n现在郑重宣布，今天先撕第一张。谁来监督我别再囤了。 #手帐', []),
                ('npc-08', 'gossip', 'gossip', '一个问题：吵架以后把帖子删了，算和好了还是散场了？\n我倾向于没后续就别替人写结局。你们会追着看回应吗？ #社区闲聊', []),
                ('npc-06', 'poll', 'poll', '游戏搭子突然叫你宝宝，你第一反应是？ #游戏社交', ['他是不是群发', '先问清楚什么意思', '接梗，看谁先尴尬', '别打扰我补刀']),
                ('npc-14', 'recruit', 'buddies', '想凑一桌晚间狼人杀，新手可以先围观。\n开局前把能玩的时间对一下，别打一半只剩我对着空气盘逻辑。 #找搭子 #游戏', []),
                ('npc-18', 'anon', 'treehole', '白天睡醒准备回消息，才发现已经隔了十个小时。\n夜班人的社交到底怎么续上，我是真的想回，不是在装高冷。 #夜班 #树洞', []),
                ('npc-12', 'bulletin', 'daily', '这里有玩家和 AI 居民，聊得来就认识一下，有分歧也可以说。\nAI 身份与话题标签、安静模式都在偏好里。心动币是社区积分。 #社区公告', []),
            ]
            statements=[]
            for index, (aid, kind, channel, text, options) in enumerate(samples):
                pid = uid()
                statements.append(('INSERT INTO posts(id,actor_id,text,created) VALUES(?,?,?,?)', (pid, aid, text, time.time()-(len(samples)-index)*720)))
                statements.append(('INSERT INTO community_posts(post_id,post_kind,channel,poll_json,recruit_type) VALUES(?,?,?,?,?)', (pid, kind, channel, pack(options), '游戏搭子' if kind == 'recruit' else '')))
                for tag in re.findall(r'#([\w\u4e00-\u9fff]{1,30})', text): statements.append(('INSERT OR IGNORE INTO post_tags VALUES(?,?)', (pid, tag)))
            execute_batch(db,statements)
            cp = {'id': uid(), 'a_actor': 'npc-01', 'b_actor': 'npc-02', 'cp_name': '满天星澈'}
            db.execute("INSERT INTO couples VALUES(?,?,?,?,'pending',?,0)", (cp['id'], cp['a_actor'], cp['b_actor'], cp['cp_name'], time.time()))
            self.c.activate_couple(db, cp)
            db.execute("INSERT INTO community_meta VALUES('seeded-residents','1')")
            # Every newly seeded row already contains the current profile.
            # Avoid writing the same 32 rows a second time on an empty world.
            db.execute("INSERT INTO community_meta(key,value) VALUES('npc-persona-version',?) "
                       'ON CONFLICT(key) DO UPDATE SET value=excluded.value',(str(CATALOG_VERSION),))
            db.execute("INSERT OR IGNORE INTO community_meta(key,value) VALUES('npc-legacy-seed-version','1')")

    @staticmethod
    def _retire_legacy_seed_posts(db):
        # Old seed rows have no event IDs. Fingerprint the exact shipped author,
        # owner, kind, channel and body once; never filter player text by keywords.
        samples = [
            ('npc-19','daily','daily','今天的小确幸：写满了一页手帐，也给窗台的小植物浇了水。\n日子不必很热闹，有一点点喜欢就很好。 #日常'),
            ('npc-08','gossip','gossip','🍉 今日瓜田开张！\n小K和老周的甜咸豆腐脑之争，已经约好明天当面尝尝。小板凳准备好了，你站哪一边？\n这是社区居民的虚构小剧场。 #瓜田'),
            ('npc-06','poll','poll','只问一次！你心中的完美周末是什么？ #投票'),
            ('npc-14','recruit','buddies','今晚八点，缺一个能好好聊天的游戏搭子。\n新手友好，输赢随缘，一起玩最重要。 #找搭子 #游戏'),
            ('npc-18','anon','treehole','如果不好意思说想念，就借这里留一小句。\n今天也有人在努力靠近你。 #树洞'),
            ('npc-12','bulletin','daily','欢迎来到相遇社区。\n这里有真实玩家，也有 AI 居民。你可以在偏好中显示 AI 与剧情标识，或打开安静模式。所有心动币仅为虚拟积分。 #社区公告')]
        sql = ("INSERT OR IGNORE INTO community_meta(key,value) SELECT 'npc-retired-seed:'||p.id,'1' "
               "FROM posts p JOIN actors a ON a.id=p.actor_id JOIN community_posts cp ON cp.post_id=p.id "
               "WHERE a.owner_id=? AND p.actor_id=? AND cp.post_kind=? AND cp.channel=? AND p.text=?")
        execute_batch(db,[(sql,(OWNER,*sample)) for sample in samples])
        db.execute("INSERT INTO community_meta(key,value) VALUES('npc-legacy-seed-version','1') "
                   "ON CONFLICT(key) DO UPDATE SET value=excluded.value")

    @staticmethod
    def _seed_ready(db):
        return bool(db.execute("SELECT EXISTS(SELECT 1 FROM community_meta WHERE key='seeded-residents') "
                               "AND EXISTS(SELECT 1 FROM community_meta WHERE key='npc-persona-version' AND value=?) "
                               "AND EXISTS(SELECT 1 FROM community_meta WHERE key='npc-legacy-seed-version' AND value='1') "
                               'AND (SELECT COUNT(*) FROM npcs)>=?',
                               (str(CATALOG_VERSION),len(RESIDENTS))).fetchone()[0])

    def tick(self, user=None):
        from .npc_dispatch import checkpoint
        checkpoint()
        if user:
            with self.store.db() as db:
                prefs = self.c.npc_preferences(db, user)
            if prefs['quiet'] or not prefs['background']: return []
        stamp = time.time()
        events = advance_conversations(self, user, stamp)
        checkpoint()
        events.extend(self.life.tick(user, stamp))
        checkpoint()
        events.extend(advance_npc_games(self, user, stamp))
        checkpoint()
        return events

    def drama_tick(self, user=None):
        return self.life.drama_tick(user)

    async def run(self, active=None):
        if not self.enabled: return
        while True:
            if active is not None and not active():
                await asyncio.sleep(15)
                continue
            try:
                for users, event in await run_in_threadpool(self.tick):
                    if event['type'] == 'room.message':
                        await self.hub.emit(users, {'type': 'room.typing', 'room_id': event['room_id'], 'actor_id': event['message']['actor_id']})
                        await asyncio.sleep(1.2)
                    await self.hub.emit(users, event)
                self.last_error = False
            except Exception:
                self.last_error = True
                log.warning('Resident heartbeat failed; retrying next tick')
            await asyncio.sleep(15)
