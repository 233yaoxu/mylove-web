"""Additive fictional identities for adult residents; no relationship decisions.

This catalog is pure data. It does not access a database, provider or private
conversation. Existing identity choices and living extensions always win.
"""
from copy import deepcopy
import re


WORLDVIEW_VERSION = 1
GENDERS = {
    'male': {'id': 'male', 'label': '普通男'},
    'female': {'id': 'female', 'label': '普通女'},
    'female_dual': {'id': 'female_dual', 'label': '女性双鸾'},
    'male_dual': {'id': 'male_dual', 'label': '男性双鸾'},
}
ORIENTATIONS = {
    'heterosexual': '异性倾向', 'homosexual': '同性倾向', 'bisexual': '双性倾向',
    'pansexual': '泛性倾向', 'demisexual': '半性倾向', 'asexual': '无性倾向',
    'questioning': '探索中',
}
WORLD_RULES = (
    '社区角色都是具有自主意愿的成年人；双鸾是天然的生物学变异，约占全球兽人总人口的十分之一，是被社会普遍接受的常态。',
    '这个世界有普通男性、普通女性、女性双鸾和男性双鸾四种性别；女性双鸾主要具有使伴侣受孕的生殖能力，自身极难受孕；男性双鸾主要具有自身受孕的生殖能力，极难使伴侣受孕。',
    '性别、取向和族群不决定善恶、职业、能力或交友价值；不以身份贬低任何人。',
    '取向描述个人感受，不等于对任何人的恋爱承诺；交友、CP与亲密邀请都需要本人明确同意。',
    '智慧兽人的人形与兽形属于同一位成年人物，保留语言、记忆、人格与自主选择。',
    '公共社区只交流日常、兴趣和非露骨的感情发展，不公开私聊、私人记忆或身体隐私。',
)

# Authored fictional identities; never inferred from a name, avatar or person.
_GENDER_IDS = (
    'female', 'male', 'male_dual', 'female', 'male', 'male_dual', 'female_dual', 'female_dual',
    'female', 'female_dual', 'female', 'male', 'female_dual', 'male_dual', 'female', 'male',
    'male', 'male_dual', 'female', 'male', 'female', 'female_dual', 'male', 'male_dual',
    'female_dual', 'male', 'female', 'female_dual', 'male', 'male_dual', 'female_dual', 'female',
)
_ORIENTATION_IDS = (
    'heterosexual', 'heterosexual', 'homosexual', 'pansexual', 'heterosexual', 'bisexual', 'asexual', 'pansexual',
    'bisexual', 'homosexual', 'demisexual', 'heterosexual', 'questioning', 'bisexual', 'asexual', 'pansexual',
    'homosexual', 'demisexual', 'pansexual', 'bisexual', 'asexual', 'pansexual', 'heterosexual', 'homosexual',
    'demisexual', 'bisexual', 'pansexual', 'asexual', 'heterosexual', 'pansexual', 'questioning', 'bisexual',
)
_SPECIES = (
    ('猫', '安静休息区与尾巴活动空间', '喜欢暖光的阅读角，也会主动约朋友散步'),
    ('狐', '适合收纳小物件的围裙与衣帽架', '会记住朋友提过的兴趣，愿意分享街角的新发现'),
    ('狼', '宽敞的人行道与夜跑反光配件', '喜欢一起完成小目标，也会认真安排独处的时间'),
    ('鹿', '为角形配件留出的门廊与帽架', '会挑安静的公园碰面，用具体的小事表达关心'),
    ('兔', '适合耳形的耳罩与低噪声活动区', '喜欢社区手作和种植活动，习惯提前确认聚会安排'),
    ('熊', '结实舒适的座椅与适配衣物', '乐于分享烘焙成果，忙起来也会直说需要休息'),
    ('水獭', '雨具、泳具和干燥的随身收纳袋', '会组织轻松的水边散步，分享作品也欢迎不同意见'),
    ('鸮', '柔和照明与夜间安静通行安排', '习惯记录夜晚的灵感，尊重朋友不同时段的作息'),
)


def _fill(defaults, existing):
    if not isinstance(existing, dict):
        return deepcopy(defaults)
    result = deepcopy(existing)
    for key, value in defaults.items():
        if key not in result:
            result[key] = deepcopy(value)
        elif isinstance(value, dict) and isinstance(result[key], dict):
            result[key] = _fill(value, result[key])
    return result


def _attraction(gender, orientation):
    same = ('male', 'male_dual') if gender in ('male', 'male_dual') else ('female', 'female_dual')
    if orientation == 'heterosexual':
        return [key for key in GENDERS if key not in same]
    if orientation == 'homosexual':
        return list(same)
    if orientation in ('asexual', 'questioning'):
        return []
    return list(GENDERS)


def resident_worldview(actor_id, existing=None):
    """Return fresh defaults, filling only missing values of existing data."""
    matched = re.fullmatch(r'npc-(\d{2})', str(actor_id))
    index = int(matched[1]) - 1 if matched else -1
    if not 0 <= index < len(_GENDER_IDS):
        return deepcopy(existing) if isinstance(existing, dict) else {}
    old = existing if isinstance(existing, dict) else {}
    gender = old.get('gender', {}).get('id') if isinstance(old.get('gender'), dict) else None
    gender = gender if gender in GENDERS else _GENDER_IDS[index]
    orientation = old.get('orientation', {}).get('id') if isinstance(old.get('orientation'), dict) else None
    orientation = orientation if orientation in ORIENTATIONS else _ORIENTATION_IDS[index]
    beast, accommodation, hook = _SPECIES[index % len(_SPECIES)]
    is_beastkin = index % 5 != 0
    species = {'id': 'beastkin' if is_beastkin else 'human',
               'label': beast + '族智慧兽人' if is_beastkin else '人类',
               'beast_species': beast if is_beastkin else ''}
    forms = [{'id': 'human', 'label': '人形', 'description':
              '成年人的日常人形，穿着和配饰按自己的审美选择；保留' + beast + '族个人特征。'
              if is_beastkin else '成年人的日常形态，个人外观不决定性格与取向。'}]
    if is_beastkin:
        forms.append({'id': 'beast', 'label': '兽形', 'description':
                      '具有' + beast + '族外观的成年智慧形态，仍是同一位能交流、能选择的居民；转换不改变人格和既有关系。'})
    romantic_style = ('无性倾向不排斥按自己意愿发展浪漫陪伴，也可以只交朋友。' if orientation == 'asexual'
                      else '重视情感连接，熟悉和信任建立之后再决定是否发展吸引。' if orientation == 'demisexual'
                      else '尚在探索自己的感受，不需要为了融入社区而急着给出答案。' if orientation == 'questioning'
                      else '重视双方真实感受和相处过程，不根据身份替别人确定关系。')
    default = {
        'version': WORLDVIEW_VERSION, 'setting': '相遇城 · 多族共居的现代日常', 'adult': True,
        'gender': deepcopy(GENDERS[gender]),
        'orientation': {'id': orientation, 'label': ORIENTATIONS[orientation],
                        'attracted_genders': _attraction(gender, orientation), 'romantic_style': romantic_style},
        'species': species, 'forms': forms, 'current_form': 'human',
        'daily_life': [hook, accommodation + '让不同形态的居民都能舒适参与。'
                       if is_beastkin else '和不同族群的邻居平等相处，聚会前主动询问彼此的实际需要。'],
        'norms': list(WORLD_RULES),
    }
    result = _fill(default, old)
    # A catalog upgrade cannot convert an adult identity into a child identity.
    result['adult'] = True
    return result


def enrich_worldview(actor_id, persona):
    """Copy a persona and add worldview defaults; never mutate living state."""
    result = deepcopy(persona) if isinstance(persona, dict) else {}
    worldview = resident_worldview(actor_id, result.get('worldview'))
    if worldview:
        result['worldview'] = worldview
    return result


def public_worldview(persona):
    """Project approved public identity fields, excluding private extensions."""
    raw = persona.get('worldview') if isinstance(persona, dict) else None
    if not isinstance(raw, dict):
        return {}
    def project(record, strings, lists=()):
        result = {key: record[key] for key in strings if isinstance(record.get(key), str)}
        for key in lists:
            if isinstance(record.get(key), list):
                result[key] = [value for value in record[key] if isinstance(value, str)]
        return result

    result = project(raw, ('setting', 'current_form'), ('daily_life', 'norms'))
    if type(raw.get('version')) is int: result['version'] = raw['version']
    if type(raw.get('adult')) is bool: result['adult'] = raw['adult']
    fields = {
        'gender': ('id', 'label'),
        'orientation': ('id', 'label', 'romantic_style'),
        'species': ('id', 'label', 'beast_species'),
    }
    for key, allowed in fields.items():
        if isinstance(raw.get(key), dict):
            result[key] = project(raw[key], allowed, ('attracted_genders',) if key == 'orientation' else ())
    if isinstance(raw.get('forms'), list):
        result['forms'] = [project(form, ('id', 'label', 'description'))
                           for form in raw['forms'] if isinstance(form, dict)]
    return result
