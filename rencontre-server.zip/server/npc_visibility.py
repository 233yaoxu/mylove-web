"""Batchable source checks shared by public sheets and resident recollections."""
import json
from .resident_comments import comment_visibility


def discovery_post_visibility(post_id='p.id'):
    """Discovery uses source markers; existing details and comments are retained."""
    return ("NOT EXISTS(SELECT 1 FROM npc_public_events legacy "
            "WHERE legacy.post_id=" + post_id + " AND legacy.kind='drama') "
            "AND NOT EXISTS(SELECT 1 FROM community_meta retired "
            "WHERE retired.key='npc-retired-seed:'||" + post_id + " AND retired.value='1')")


def public_event_visibility(alias='e', *, include_drama=False):
    # Aliases are internal constants. JSON is guarded even for old/corrupt metadata.
    value = "CASE WHEN json_valid(evidence.value) THEN evidence.value ELSE '{}' END"
    def field(key): return "json_extract(" + value + ",'$." + key + "')"
    valid = (
        "EXISTS(SELECT 1 FROM community_meta evidence "
        "JOIN posts origin ON origin.id=" + field('post_id') +
        " LEFT JOIN community_posts detail ON detail.post_id=origin.id "
        "JOIN comments utterance ON utterance.id=" + field('output_id') +
        " WHERE evidence.key='npc-life:evidence:'||" + alias + ".id "
        "AND origin.id=" + alias + ".post_id AND origin.actor_id=" + field('post_actor') +
        " AND origin.text=" + field('post_text') + " AND COALESCE(detail.post_kind,'daily')<>'anon' "
        "AND utterance.post_id=origin.id AND utterance.actor_id=" + alias + ".actor "
        "AND utterance.text=" + field('output_text') + " AND " + comment_visibility('utterance') + " AND ((" + field('source_kind') + "='post' "
        "AND " + field('source_id') + "=origin.id AND " + field('source_actor') + "=origin.actor_id "
        "AND " + field('source_text') + "=origin.text) OR (" + field('source_kind') + "='comment' "
        "AND EXISTS(SELECT 1 FROM comments source WHERE source.id=" + field('source_id') +
        " AND source.post_id=origin.id AND source.actor_id=" + field('source_actor') +
        " AND source.text=" + field('source_text') + " AND " + comment_visibility('source') + "))))"
    )
    condition = "(COALESCE(" + alias + ".drama_id,'') NOT LIKE 'social:%' OR " + valid + ")"
    return condition if include_drama else "(" + alias + ".kind<>'drama' AND " + condition + ")"


def public_life_state(value, events=()):
    if isinstance(value, str):
        try: value = json.loads(value)
        except (ValueError, TypeError): return {}
    if not isinstance(value, dict): return {}
    result = {k: value[k][:240] for k in ('day', 'goal', 'activity', 'expectation')
              if isinstance(value.get(k), str)}
    result['progress'] = max(0, min(100, value.get('progress', 0))) if type(value.get('progress')) is int else 0
    # A withdrawn source must not survive indirectly as a mood explanation.
    event = next((row for row in events if row.get('id') == value.get('mood_event')), None)
    result['mood_reason'] = (event.get('summary') or event.get('text') or '')[:240] if event else '安排自己的生活，看看今天有什么想聊的'
    return result
