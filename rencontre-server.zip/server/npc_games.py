"""Bounded resident decisions using authoritative game rules and seat views.

Only platform residents already present in a room can take a seat. The room's
existing AI switch, cooldown, round limit and lease also govern game decisions.
Model requests run after the durable claim commits; a fresh state and ownership
check precedes every apply. No game state is broadcast to other room members.
"""
from copy import deepcopy
import hashlib
import json
import re
import time

from . import games
from .community import pack, uid
from .npc_people import public_profile


PLATFORM_OWNER = 'rencontre-platform-residents'
LEASE_SECONDS = 90
MAX_SCAN = 20
MAX_CHOICES = 48


def _meta(db, key):
    row = db.execute('SELECT value FROM community_meta WHERE key=?', (key,)).fetchone()
    try:
        value = json.loads(row['value']) if row else {}
        return value if isinstance(value, dict) else {}
    except (ValueError, TypeError):
        return {}


def _put(db, key, value):
    db.execute('INSERT INTO community_meta(key,value) VALUES(?,?) '
               'ON CONFLICT(key) DO UPDATE SET value=excluded.value', (key, pack(value)))


def _configuration(raw, now, token=None):
    ai = json.loads(raw)
    if not isinstance(ai, dict) or ai.get('enabled') is not True or ai.get('paused'):
        return None
    if ai.get('auto_count', 0) >= ai.get('max_auto', 8): return None
    if now - ai.get('last_ai', 0) < max(2, ai.get('cooldown', 8)): return None
    lease = ai.get('lease') or {}
    if token:
        if lease.get('id') != token or lease.get('expires', 0) <= now: return None
    elif lease.get('expires', 0) > now:
        return None
    return ai


def _expired(state, now):
    clock = games._clock(state)
    return bool(clock and clock[0] in state and now >= state[clock[0]])


def _residents(db, rid):
    return [dict(row) for row in db.execute(
        'SELECT a.id,a.name,a.bio,n.persona_json FROM members m '
        'JOIN actors a ON a.id=m.actor_id JOIN npcs n ON n.actor=a.id '
        "WHERE m.room_id=? AND a.owner_id=? AND a.kind='ai' AND n.active=1",
        (rid, PLATFORM_OWNER))]


def _claim(engine, now):
    with engine.store.db(write=True) as db:
        rows = db.execute(
            'SELECT DISTINCT g.id,g.room_id,g.state,g.created,r.ai FROM games g '
            'JOIN rooms r ON r.id=g.room_id JOIN members m ON m.room_id=r.id '
            'JOIN npcs n ON n.actor=m.actor_id JOIN actors a ON a.id=n.actor '
            "WHERE n.active=1 AND a.owner_id=? AND a.kind='ai' "
            "AND json_extract(g.state,'$.phase')<>'finished' "
            'ORDER BY g.created DESC LIMIT ?', (PLATFORM_OWNER, MAX_SCAN)).fetchall()
        for row in rows:
            ai = _configuration(row['ai'], now)
            if ai is None: continue
            state = json.loads(row['state'])
            if state.get('kind') not in games.LIMITS or _expired(state, now): continue
            members = {member[0] for member in db.execute('SELECT actor_id FROM members WHERE room_id=?', (row['room_id'],))}
            if not set(state['seats']).issubset(members): continue
            residents = {actor['id']: actor for actor in _residents(db, row['room_id'])}
            # Seated residents get priority over filling a lobby's empty seats.
            order = [aid for aid in state['seats'] if aid in residents]
            if state['phase'] == 'lobby': order += sorted(set(residents) - set(order))
            for aid in order:
                choices = games.candidates(state, aid)[:MAX_CHOICES]
                if not choices: continue
                # The text candidate API can describe a full turtle list, but
                # apply correctly refuses further questions after its cap.
                if state['kind'] == 'turtle' and aid != state['host']:
                    choices = [choice for choice in choices if len(state['questions' if choice['action'] == 'question' else 'guesses']) < 200]
                if not choices: continue
                source = hashlib.sha256((row['id'] + ':' + row['state'] + ':' + aid).encode()).hexdigest()
                key = 'npc-game:' + row['id']
                previous = _meta(db, key)
                if previous.get('status') == 'claimed' and previous.get('expires', 0) > now: break
                if previous.get('status') == 'done' and previous.get('source') == source: continue
                token = uid()
                claim = dict(token=token, source=source, actor=aid, revision=state['revision'],
                             expires=now + LEASE_SECONDS, status='claimed')
                _put(db, key, claim)
                ai['lease'] = dict(id=token, actor=aid, expires=claim['expires'])
                db.execute('UPDATE rooms SET ai=? WHERE id=?', (pack(ai), row['room_id']))
                context_seq = db.execute('SELECT COALESCE(MAX(seq),0) FROM messages WHERE room_id=?',
                                         (row['room_id'],)).fetchone()[0]
                return dict(claim, key=key, id=row['id'], room_id=row['room_id'],
                            raw=row['state'], state=state, choices=choices, resident=residents[aid],
                            decision_at=now, context_seq=context_seq,
                            context_revision=ai.get('context_revision', 0))
    return None


def _seat_context(state, aid):
    view = games.view(state, [aid])
    # Keep provider input bounded even for an old, densely drawn canvas.
    view['log'] = view.get('log', [])[-8:]
    for key in ('questions', 'guesses'):
        if key in view: view[key] = view[key][-10:]
    if 'strokes' in view:
        view['strokes'] = [dict(stroke, points=stroke['points'][-40:]) for stroke in view['strokes'][-6:]]
    return view


def _fallback(choices, state):
    index = next((i for i, choice in enumerate(choices) if choice['action'] == 'win'), 0)
    if state['kind'] == 'draw':
        index = next((i for i, choice in enumerate(choices) if choice['action'] == 'skip'), index)
    choice = deepcopy(choices[index])
    if choice.get('flexible') and choice['action'] in ('question', 'guess'):
        if state['kind'] == 'turtle':
            questions = ['这件事与人物的身份有关吗？', '事情发生的地点是关键吗？',
                         '他是在发现某样东西以后改变心情的吗？', '这里的笑是因为误会解开了吗？']
            text = questions[len(state['questions']) % len(questions)]
        else:
            text = '猫咪'
        choice['data'] = {'text': text}
    return choice


def _allowed(choice, candidates):
    for candidate in candidates:
        if choice.get('action') != candidate['action']: continue
        data = choice.get('data')
        if not isinstance(data, dict): continue
        if not candidate.get('flexible'):
            if data == candidate['data']: return True
        elif choice['action'] in ('question', 'guess'):
            if set(data) == {'text'} and isinstance(data['text'], str) and 0 < len(data['text'].strip()) <= 300:
                return True
        elif choice['action'] == 'stroke' and set(data).issubset({'points', 'color', 'width'}) and 'points' in data:
            # apply validates point count, normalized coordinates and colors.
            return True
    return False


def _choose(engine, claim):
    fallback = _fallback(claim['choices'], claim['state'])
    resident = claim['resident']
    persona = json.loads(resident['persona_json'])
    profile = public_profile(persona, ('name', 'bio', 'traits', 'speech_style', 'interests', 'values'))
    task = pack(dict(instruction='只为 actor_id 这个座位选择合法候选。返回 JSON {"choice":候选索引}；'
                     '只有 flexible 候选可附加 data。不要替其他人行动，不输出聊天或分析。',
                     actor_id=claim['actor'], view=_seat_context(claim['state'], claim['actor']),
                     candidates=claim['choices']))
    try:
        fallback_index = next(i for i, choice in enumerate(claim['choices']) if choice['action'] == fallback['action'])
        raw = engine.router.generate(task, profile, pack({'choice': fallback_index}), purpose='game')
        if not isinstance(raw, str): return fallback
        match = re.search(r'\{.*\}', raw, re.DOTALL)
        value = json.loads(match.group() if match else raw)
        index = value.get('choice')
        if type(index) is not int or not 0 <= index < len(claim['choices']): return fallback
        choice = deepcopy(claim['choices'][index])
        choice.pop('flexible', None)
        if 'data' in value: choice['data'] = value['data']
        if _allowed(choice, claim['choices']):
            # Flexible candidates describe an action shape, so the existing
            # rules must also accept any model-provided drawing/text payload.
            games.apply(deepcopy(claim['state']), claim['actor'], choice['action'],
                        choice['data'], now=claim['decision_at'])
            return choice
    except Exception:
        # Provider bodies/configuration must never enter game logs or events.
        pass
    return fallback


def _release(db, claim):
    job = _meta(db, claim['key'])
    if job.get('token') != claim['token']: return
    job.update(status='stale', expires=0)
    _put(db, claim['key'], job)
    row = db.execute('SELECT ai FROM rooms WHERE id=?', (claim['room_id'],)).fetchone()
    if row:
        ai = json.loads(row['ai'])
        if (ai.get('lease') or {}).get('id') == claim['token']:
            ai['lease'] = None
            db.execute('UPDATE rooms SET ai=? WHERE id=?', (pack(ai), claim['room_id']))


def _chat(state, choice):
    # Night choices and all private information remain private. Public chat
    # uses local phrases rather than model text generated with a secret hand.
    if state['kind'] == 'werewolf' and choice['action'] == 'night': return ''
    action = choice['action']
    if action == 'join': return '还有空位的话，我也来凑一桌，慢慢玩就好。'
    if action == 'start': return '人齐啦，那就开始吧。新朋友有不清楚的地方可以一起研究。'
    if state['kind'] == 'turtle': return '我有一个小猜想，先沿着这个方向试试看。'
    if state['kind'] == 'draw': return '这一轮挺有意思，我也试着接一接灵感。'
    if action == 'pass': return '这手我先等等，你们继续，我认真看着呢。'
    if action == 'win': return '这一局承让啦，和你们一起玩很开心。'
    return '到我啦，我想好这一步了。输赢随缘，玩得开心最重要。'


def advance_npc_games(engine, user=None, now=None):
    """Commit at most one NPC-owned legal game action; return room event tuples.

    ``user`` identifies the authenticated activity trigger, never the seat owner
    or a grant of authority over that player's seats. Game decisions use the
    public resident model default and a single resident's private seat view.
    """
    if not getattr(engine, 'enabled', True): return []
    started = time.monotonic()
    timestamp = time.time() if now is None else now
    current_time = lambda: timestamp + time.monotonic() - started
    claim = _claim(engine, current_time())
    if claim is None: return []
    choice = _choose(engine, claim)
    with engine.store.db(write=True) as db:
        stamp = current_time()
        job = _meta(db, claim['key'])
        row = db.execute('SELECT g.*,r.ai FROM games g JOIN rooms r ON r.id=g.room_id WHERE g.id=?', (claim['id'],)).fetchone()
        ai = _configuration(row['ai'], stamp, claim['token']) if row else None
        residents = _residents(db, claim['room_id']) if row else []
        valid = (row and row['state'] == claim['raw'] and row['room_id'] == claim['room_id']
                 and ai is not None and job.get('token') == claim['token']
                 and job.get('status') == 'claimed' and job.get('expires', 0) > stamp
                 and any(resident['id'] == claim['actor'] for resident in residents))
        if not valid:
            _release(db, claim)
            return []
        state = json.loads(row['state'])
        members = {member[0] for member in db.execute('SELECT actor_id FROM members WHERE room_id=?', (claim['room_id'],))}
        if (_expired(state, stamp) or not set(state['seats']).issubset(members)
                or not _allowed(choice, games.candidates(state, claim['actor']))):
            _release(db, claim)
            return []
        try:
            games.apply(state, claim['actor'], choice['action'], choice['data'], now=stamp)
        except (ValueError, TypeError, KeyError, OverflowError):
            _release(db, claim)
            return []
        db.execute('UPDATE games SET state=? WHERE id=? AND state=?', (pack(state), claim['id'], claim['raw']))
        ai.update(auto_count=ai.get('auto_count', 0) + 1, last_ai=stamp,
                  turn=ai.get('turn', 0) + 1, lease=None)
        ai['paused'] = ai['auto_count'] >= ai.get('max_auto', 8)
        db.execute('UPDATE rooms SET ai=? WHERE id=?', (pack(ai), claim['room_id']))
        job.update(status='done', expires=0)
        _put(db, claim['key'], job)
        db.execute('INSERT OR IGNORE INTO npc_actions VALUES(?,?,?,?)',
                   ('npc-game-' + claim['source'], claim['actor'], 'game.' + choice['action'], stamp))
        users = engine.c.room_users(db, claim['room_id'])
        events = [(users, {'type': 'game.changed', 'room_id': claim['room_id'], 'game_id': claim['id']})]
        text = _chat(claim['state'], choice)
        latest_seq = db.execute('SELECT COALESCE(MAX(seq),0) FROM messages WHERE room_id=?',
                                (claim['room_id'],)).fetchone()[0]
        if (latest_seq != claim['context_seq']
                or ai.get('context_revision', 0) != claim['context_revision']):
            text = ''
        if text:
            message_id = uid()
            db.execute('INSERT INTO messages(id,room_id,actor_id,text,created) VALUES(?,?,?,?,?)',
                       (message_id, claim['room_id'], claim['actor'], text[:ai.get('max_chars', 300)], stamp))
            message = dict(db.execute('SELECT * FROM messages WHERE id=?', (message_id,)).fetchone())
            engine.c.create_message(db, message)
            message = engine.c.message_view(db, message, None)
            events.append((users, {'type': 'room.message', 'room_id': claim['room_id'], 'message': message}))
        return events
