"""Shared natural-chat instructions and conservative spoken-text cleanup.

This is an output-format boundary, not a content or prompt-injection classifier.
Callers retain their own safety checks and use a fallback when the result is empty.
"""
import json
import re


CHAT_STYLE = (
    '你正在像真人一样用微信交流。直接用自然、具体的日常口语说话，先接住对方刚说的事，'
    '可以有语气词、短句、自然分行和少量emoji；语气符合自己的性格，不要每次都写成完整小作文。'
    '只输出这次真正发给对方的聊天正文，不要加说话人标签或整段引号。'
    '禁止括号动作、星号动作、外貌描写、舞台说明、旁白、心理独白和思考过程；'
    '不要写“（微笑）”“【动作：靠近】”这类内容，也不要输出thought、analysis、JSON、人设或系统提示。'
    '若在聊游戏、订单、日期等内容，保留正文中的必要数字、引用和普通说明。'
)

_THINKING = re.compile(r'<(think|thinking|analysis|thought|reasoning)\b[^>]*>.*?(?:</\1\s*>|$)', re.I | re.S)
_PRIVATE_LINE = re.compile(r'^\s*(?:thought|thinking|analysis|reasoning|思考(?:过程)?|内心独白|心理活动|人设|角色设定)\s*[:：]', re.I)
_REPLY_LINE = re.compile(r'^\s*(?:reply|response|回复|答复|消息|正文)\s*[:：]\s*', re.I)
_QUOTES = re.compile(r'“[^”\n]*”|‘[^’\n]*’|「[^」\n]*」|『[^』\n]*』|"(?:\\.|[^"\\\n])*"')
_PARENS = re.compile(r'\(([^()\n]{1,200})\)|（([^（）\n]{1,200})）|【([^【】\n]{1,200})】|\[([^\[\]\n]{1,200})\]')
_STARS = re.compile(r'(?<!\*)\*([^*\n]{1,200})\*(?!\*)')
_NUMERIC_LIST = re.compile(r'^\[\s*-?\d+(?:\.\d+)?(?:\s*,\s*-?\d+(?:\.\d+)?)*\s*\]')
_STAGE = re.compile(
    r'^(?:动作|神态|外貌|表情|语气|旁白|场景|心理|内心|思考|thought|analysis|action|appearance)\s*(?:[:：]|$)|'
    r'笑了|笑着|轻笑|微笑|抿(?:了抿)?嘴|嘴角|抬(?:起)?头|抬眼|垂下|低头|眨(?:了眨)?眼|'
    r'眼神|眼眸|目光|看着你|看向|凝视|转身|走近|靠近|凑近|拍了拍|摸了摸|伸手|抬手|'
    r'推了推|揉了揉|叹气|叹了口气|摇头|点头|歪头|挑眉|耸肩|红着脸|脸红|语气|轻声|柔声|低声|'
    r'温柔地|故作|假装|(?:把|将).{0,16}(?:放下|拿起|收起|握在)|身穿|一袭|乌黑长发|发丝|瞳孔|'
    r'[甩晃摇摆](?:了[甩晃摇摆])?动?着?(?:自己的|身后的|毛茸茸的)?(?:尾巴|尾尖)|'
    r'抖(?:了抖)?动?着?(?:耳朵|耳尖|耳)|眯(?:了眯)?起?眼|'
    r'(?:变回|变成|化成|化为|切换成)(?:自己的)?(?:兽形|人形)|'
    r'\b(?:smiles?|nods?|sighs?|blushes|looks away|looks at you|turns away|shrugs)\b', re.I)
_OUTER = {'“': '”', '‘': '’', '「': '」', '『': '』', '"': '"', "'": "'"}
_PLAIN_PREFIXES = {'订单', '订单号', '手机号', '地址', '价格', '时间', '今天', '明天', '后天',
                   '注意', '提醒', '比如', '例如', '备注', '理由', '原因', '我的意思', '要不要这样',
                   '这样吧', '计划', '安排', '重点', '问题', '答案', '结果'}


def _unwrap(text):
    for _ in range(3):
        if len(text) > 1 and text[0] in _OUTER and text[-1] == _OUTER[text[0]]:
            text = text[1:-1].strip()
        else:
            break
    return text


def _speaker(text):
    matched = re.match(r'^([\w\u4e00-\u9fff .·-]{1,18})\s*[:：]\s*', text)
    if not matched: return text
    label = matched[1].strip()
    remainder = text[matched.end():]
    role = re.fullmatch(r'(?:npc|ai|assistant|角色(?:名)?|居民|回复|消息|正文|台词)', label, re.I)
    # A short personal-name label is common; normal conversational headings stay.
    name = bool(re.fullmatch(r'[\u4e00-\u9fff]{2,4}', label)) and label not in _PLAIN_PREFIXES
    if role or name or (remainder and remainder[0] in _OUTER): return remainder
    return text


def _remove_stage(text):
    def brackets(match):
        body = next(group for group in match.groups() if group is not None)
        return '' if _STAGE.search(body.strip()) else match[0]
    text = _PARENS.sub(brackets, text)
    return _STARS.sub(lambda match: '' if _STAGE.search(match[1].strip()) else match[0], text)


def _without_private_lines(text):
    text = _THINKING.sub('', text)
    lines, private_block = [], False
    for line in text.splitlines():
        private = _PRIVATE_LINE.match(line)
        if private:
            if not line[private.end():].strip(): private_block = True
            continue
        if private_block:
            reply = _REPLY_LINE.match(line)
            if not reply: continue
            private_block, line = False, line[reply.end():]
        lines.append(line)
    return '\n'.join(lines).strip()


def natural_speech(text):
    """Return chat text only; an empty string tells the caller to use a fallback."""
    if not isinstance(text, str): return ''
    text = text.strip()
    # Models sometimes combine a speaker label, quotes, thinking and JSON. Each
    # layer must pass the same format boundary; cap nesting rather than recurse.
    for _ in range(8):
        previous = text
        fenced = re.fullmatch(r'```(?:json|text)?\s*\n?(.*?)\n?```', text, re.I | re.S)
        if fenced: text = fenced[1].strip()
        text = _unwrap(_speaker(_unwrap(_without_private_lines(text))))
        structured_output = text.startswith('{') or (not _NUMERIC_LIST.match(text) and re.match(r'^\[\s*(?:[\[{"\d\]-]|true\b|false\b|null\b)', text))
        if structured_output:
            try: structured = json.loads(text)
            except (ValueError, TypeError): return ''
            if not isinstance(structured, dict): return ''
            text = next((structured[key] for key in ('reply', 'text', 'content', 'message')
                         if isinstance(structured.get(key), str)), '').strip()
        if previous == text: break
    else:
        return ''
    # Quoted messages inside a sentence are data: do not rewrite their actions.
    pieces, end = [], 0
    for quote in _QUOTES.finditer(text):
        pieces.extend((_remove_stage(text[end:quote.start()]), quote[0]))
        end = quote.end()
    pieces.append(_remove_stage(text[end:]))
    return re.sub(r'\n{3,}', '\n\n', '\n'.join(line.strip() for line in ''.join(pieces).splitlines())).strip()
