"""Source-bound resident replies with durable claims and no network under writes."""
import hashlib
import json
import time

from fastapi import HTTPException

from .community import pack, uid
from .chat_turns import claim_turn, complete_turn, release_turn, validate_turn
from .npc_people import public_profile


PROFILE_FIELDS = ('name', 'age', 'occupation', 'background', 'traits', 'speech_style',
                  'values', 'goals', 'flaws', 'boundaries', 'relationship_style', 'interests', 'mood')


def public_persona(raw):
    persona = json.loads(raw) if isinstance(raw, str) else raw
    return public_profile(persona, (*PROFILE_FIELDS, 'worldview'))


def _claim(engine, user, stamp):
    with engine.store.db(write=True) as db:
        rows = db.execute('''
SELECT m.*,sender.owner_id,sender.name AS sender_name,n.actor AS resident,n.persona_json,r.ai,r.kind AS room_kind
FROM messages m JOIN actors sender ON sender.id=m.actor_id
JOIN rooms r ON r.id=m.room_id
JOIN members observer ON observer.room_id=r.id
JOIN npcs n ON n.actor=observer.actor_id AND n.active=1
JOIN members present ON present.room_id=r.id AND present.actor_id=m.actor_id
LEFT JOIN message_details details ON details.message_id=m.id
WHERE NOT EXISTS(SELECT 1 FROM npcs author WHERE author.actor=m.actor_id)
AND (? IS NULL OR sender.owner_id=?) AND m.created>?
AND COALESCE(details.kind,'') NOT IN ('recalled','poke')
AND m.seq=(SELECT MAX(last.seq) FROM messages last WHERE last.room_id=m.room_id)
ORDER BY m.seq DESC LIMIT 16
''', (user, user, stamp - 86400)).fetchall()
        for raw in rows:
            row = dict(raw)
            prefs = engine.c.npc_preferences(db, row['owner_id'])
            if prefs['quiet'] or not prefs['background']: continue
            ai = json.loads(row['ai'])
            if ai.get('enabled') is False or ai.get('paused'): continue
            if stamp - ai.get('last_ai', 0) < max(2, ai.get('cooldown', 8)): continue
            if ai.get('auto_count', 0) >= ai.get('max_auto', 8): continue
            if (ai.get('lease') or {}).get('expires', 0) > stamp: continue
            count = db.execute('SELECT COUNT(*) FROM npc_actions WHERE actor=? AND action=? AND created>?',
                               (row['resident'], 'chat_reply', stamp - 3600)).fetchone()[0]
            if count >= 12: continue
            job_id = hashlib.sha256((row['resident'] + ':' + row['id']).encode()).hexdigest()
            previous = db.execute('SELECT * FROM npc_jobs WHERE id=?', (job_id,)).fetchone()
            if previous and (previous['status'] == 'done' or previous['lease_until'] > stamp): continue
            token = uid()
            try:
                claim_turn(db, row['room_id'], row['resident'], ai, stamp, token, row['room_kind'])
            except HTTPException:
                continue
            db.execute('''INSERT INTO npc_jobs VALUES(?,?,?,'claimed',?,?,?,?)
ON CONFLICT(id) DO UPDATE SET status='claimed',lease_token=excluded.lease_token,
lease_until=excluded.lease_until,updated=excluded.updated''',
                       (job_id, row['id'], row['resident'], token, stamp + 90, stamp, stamp))
            db.execute('UPDATE rooms SET ai=? WHERE id=?', (pack(ai), row['room_id']))
            history = [dict(item) for item in db.execute('''
SELECT m.actor_id,a.name,m.text FROM messages m JOIN actors a ON a.id=m.actor_id
LEFT JOIN message_details d ON d.message_id=m.id
WHERE m.room_id=? AND COALESCE(d.kind,'') NOT IN ('recalled','poke')
ORDER BY m.seq DESC LIMIT 10''', (row['room_id'],))]
            relation = db.execute('SELECT type,intimacy,trust,romance,grudge FROM relationships '
                                  'WHERE a_actor=? AND b_actor=?', (row['resident'], row['actor_id'])).fetchone()
            return dict(row, job_id=job_id, token=token, history=list(reversed(history)),
                        relation=dict(relation) if relation else {}, max_chars=ai.get('max_chars', 300))
    return None


def _fallback(claim):
    name = public_persona(claim['persona_json']).get('name', '我')
    sender = claim.get('sender_name', '你')
    text = claim['text'].strip()[:90]
    if any(word in text for word in ('对不起', '抱歉', '误会')):
        return '听到你愿意解释，我松了一口气。刚才我确实有些难受，我们慢慢把话说开吧。'
    if any(word in text for word in ('讨厌', '骗子', '滚')):
        return '这句话让我有些受伤。我愿意听你的原因，但希望我们都能好好说话，先给彼此一点空间。'
    if any(word in text for word in ('喜欢你', '爱你', '想你')):
        return '你这么直接，我反倒有点紧张。能被你惦记很开心，我也想认真了解这份心意，慢慢相处。'
    options = [f'“{text[:45]}”这句我记下了。对我来说，能听你认真讲这些小事就很难得。后来呢？',
               f'你提到“{text[:45]}”，让我想到自己最近也想换一种生活节奏。说说最让你在意的地方吧。',
               f'我在，{name}今天愿意留一点时间听你说。关于“{text[:40]}”，你当时是什么心情？']
    return sender + '，' + options[int(claim['job_id'][:8], 16) % len(options)]


def _relationship(db, claim, stamp):
    text = claim['text']
    conflict = any(word in text for word in ('滚', '讨厌你', '骗子', '恨你'))
    repair = any(word in text for word in ('对不起', '抱歉', '原谅', '误会'))
    affection = any(word in text for word in ('喜欢你', '爱你', '想你', '心动'))
    old = db.execute('SELECT * FROM relationships WHERE a_actor=? AND b_actor=?',
                     (claim['resident'], claim['actor_id'])).fetchone()
    state = dict(old) if old else dict(type='点头之交', intimacy=0, trust=50, romance=0, grudge=0)
    state['intimacy'] = max(0, min(100, state['intimacy'] + (-3 if conflict else 3)))
    state['trust'] = max(0, min(100, state['trust'] + (-6 if conflict else 4 if repair else 1)))
    state['romance'] = max(0, min(100, state['romance'] + (4 if affection else -3 if conflict else 0)))
    state['grudge'] = max(0, min(100, state['grudge'] + (9 if conflict else -8 if repair else -1)))
    # A relationship label records interaction, never substitutes for consent to CP.
    if state['type'] != '恋人':
        state['type'] = ('有心结' if state['grudge'] > 30 else '暧昧' if state['romance'] >= 25
                         else '亲近' if state['intimacy'] >= 55 else '朋友' if state['intimacy'] >= 15 else '点头之交')
    db.execute('''INSERT INTO relationships VALUES(?,?,?,?,?,?,?,?,?)
ON CONFLICT(a_actor,b_actor) DO UPDATE SET type=excluded.type,intimacy=excluded.intimacy,
trust=excluded.trust,romance=excluded.romance,grudge=excluded.grudge,updated_at=excluded.updated_at''',
               (claim['resident'], claim['actor_id'], state['type'], state['intimacy'], state['trust'],
                state['romance'], state['grudge'], old['since'] if old else stamp, stamp))
    db.execute('UPDATE moods SET happy=MAX(0,MIN(100,happy+?)),angry=MAX(0,MIN(100,angry+?)),updated_at=? WHERE actor=?',
               (-4 if conflict else 2, 7 if conflict else -4 if repair else -1, stamp, claim['resident']))


def advance_conversations(engine, user=None, now=None):
    stamp = time.time() if now is None else now
    claim = _claim(engine, user, stamp)
    if not claim: return []
    engine.memory.remember_message(claim['resident'], claim['id'])
    memories = engine.memory.recall(claim['resident'], claim['text'], room_id=claim['room_id'],
                                    subject_actor=claim['actor_id'], limit=5)
    context = dict(persona=public_persona(claim['persona_json']), relationship=claim['relation'],
                   memories=[m['summary'] for m in memories])
    history = [{'name': row['name'], 'actor_id': row['actor_id'], 'text': row['text'][:400]} for row in claim['history']]
    task = '只回复会话里最后一条发言，不替任何其他成员说话。当前会话：\n' + pack(history)
    text = engine.router.generate(task, context, _fallback(claim),
                                  model_id=engine.router.selection_for(claim['owner_id']), purpose='chat')
    with engine.store.db(write=True) as db:
        job = db.execute('SELECT * FROM npc_jobs WHERE id=?', (claim['job_id'],)).fetchone()
        room = db.execute('SELECT * FROM rooms WHERE id=?', (claim['room_id'],)).fetchone()
        source = db.execute('''SELECT m.* FROM messages m LEFT JOIN message_details d ON d.message_id=m.id
WHERE m.id=? AND COALESCE(d.kind,'') NOT IN ('recalled','poke')''', (claim['id'],)).fetchone()
        members = {row[0] for row in db.execute('SELECT actor_id FROM members WHERE room_id=?', (claim['room_id'],))}
        prefs = engine.c.npc_preferences(db, claim['owner_id'])
        ai = json.loads(room['ai']) if room else {}
        valid = (job and job['status'] == 'claimed' and job['lease_token'] == claim['token']
                 and job['lease_until'] > time.time() and source and room
                 and source['text'] == claim['text'] and source['actor_id'] == claim['actor_id']
                 and {claim['actor_id'], claim['resident']}.issubset(members)
                 and not prefs['quiet'] and prefs['background'] and ai.get('enabled') is not False
                 and not ai.get('paused') and (ai.get('lease') or {}).get('id') == claim['token'])
        if valid:
            try:
                turn_lease = validate_turn(db, claim['room_id'], claim['resident'], ai, claim['token'], time.time())
            except HTTPException:
                valid = False
        if valid:
            latest = db.execute('SELECT MAX(seq) FROM messages WHERE room_id=?', (claim['room_id'],)).fetchone()[0]
            valid = latest == claim['seq']
        db.execute("UPDATE npc_jobs SET status='done',updated=? WHERE id=? AND lease_token=?",
                   (time.time(), claim['job_id'], claim['token']))
        if (ai.get('lease') or {}).get('id') == claim['token']:
            if valid:
                complete_turn(ai, turn_lease)
                ai.update(last_ai=time.time(), auto_count=ai.get('auto_count', 0) + 1, turn=ai.get('turn', 0) + 1)
            else:
                release_turn(ai, claim['resident'], claim['token'])
            db.execute('UPDATE rooms SET ai=? WHERE id=?', (pack(ai), claim['room_id']))
        if not valid: return []
        mid = uid()
        db.execute('INSERT INTO messages(id,room_id,actor_id,text,created) VALUES(?,?,?,?,?)',
                   (mid, claim['room_id'], claim['resident'], text[:max(40, min(600, claim['max_chars']))], time.time()))
        db.execute('INSERT INTO npc_actions VALUES(?,?,?,?)', (uid(), claim['resident'], 'chat_reply', time.time()))
        _relationship(db, claim, time.time())
        message = dict(db.execute('SELECT * FROM messages WHERE id=?', (mid,)).fetchone())
        users = engine.c.room_users(db, claim['room_id'])
    return [(users, {'type': 'room.message', 'room_id': claim['room_id'], 'message': message})]
