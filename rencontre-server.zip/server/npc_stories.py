"""Approved fictional NPC-only story machines and transactional state effects."""
from .community import uid


def npc(number):
    return 'npc-' + str(number).zfill(2)


def pair(a, b, intimacy=0, trust=0, romance=0, grudge=0, type=None):
    return {'a': npc(a), 'b': npc(b), 'intimacy': intimacy, 'trust': trust,
            'romance': romance, 'grudge': grudge, 'type': type}


def cp(action, a, b, name=''):
    return {'action': action, 'a': npc(a), 'b': npc(b), 'name': name}


def beat(a, b, summary, *effects, couple=None, redflag=None, requires_cp=None):
    return {'actor': npc(a), 'target': npc(b), 'summary': '【虚构居民小剧场】' + summary,
            'effects': list(effects), 'cp': couple, 'redflag': redflag, 'requires_cp': requires_cp}


def story(*stages):
    return {'cast': list(dict.fromkeys(a for stage in stages for a in (stage['actor'], stage['target']))), 'stages': list(stages)}


STORY_DEFINITIONS = {
    '豆腐脑辩论赛': story(
        beat(6, 5, '小K坚持甜豆腐脑，老周偏爱咸口；两位居民约定只辩口味，不攻击彼此。', pair(6, 5, 2, 1)),
        beat(9, 6, '七七尝过两种口味，邀请双方把理由写出来。', pair(9, 6, 3, 2)),
        beat(13, 5, '课代表建议互换一口。老周承认自己刚才说得太急。', pair(13, 5, 3, 4)),
        beat(5, 6, '老周与小K接受彼此的口味，约好下一次早餐局。', pair(6, 5, 10, 8, type='饭搭子'))),
    '一张照片的误会': story(
        beat(2, 1, '阿澈点赞桃子的照片，小满误以为生日约定被忘记，主动询问。', pair(2, 1, -3, -5, grudge=4)),
        beat(10, 1, '桃子公开说明：照片是给小满准备的生日惊喜，阿澈帮忙选了光线。', pair(10, 1, 6, 8)),
        beat(1, 2, '小满和阿澈把误会说开，约定有疑问直接沟通。', pair(2, 1, 10, 12, 5, -8))),
    '钓鱼收竿': story(
        beat(5, 6, '老周问充电器会不会偷吃手机电量，承诺晚点揭晓脑筋急转弯。', pair(5, 6, 1)),
        beat(6, 5, '小K写了半页解释，发现自己把谜语当成了认真科普，表达不满。', pair(5, 6, -3, -5, grudge=5)),
        beat(5, 6, '老周收竿并向认真答题的小K道谢，答应以后先标趣味题。', pair(5, 6, 5, 9, grudge=-7, type='朋友'))),
    '反诈小课堂': story(
        beat(9, 12, '一位虚构角色声称有“心动币捷径”，七七向老王核对规则。心动币仅为社区虚拟积分。', pair(9, 12, 3, 4)),
        beat(9, 12, '虚构角色要求先送虚拟礼物；七七停止互动并举报，老王支持她守住边界。心动币仅为虚拟积分。', pair(9, 12, 4, 5)),
        beat(12, 9, '老王复盘：催送礼物与制造紧迫感都是暂停信号。心动币没有充值入口，仅为社区虚拟积分。', pair(9, 12, 5, 6, type='朋友'))),
    '恋爱边界与重逢': story(
        beat(4, 10, '软软与桃子各自明确同意组成“桃汽软糖”CP，约定认真对待专属承诺。', pair(4, 10, 60, 25, 65, type='恋人'), couple=cp('form', 4, 10, '桃汽软糖')),
        beat(4, 10, '这段出轨与信任边界的故事里，软软在CP存续时向阿澈暧昧示好；阿澈拒绝，桃子要求解释。', pair(4, 10, -18, -35, -20, 35), requires_cp=(npc(4), npc(10))),
        beat(10, 4, '桃子明确提出分手，软软接受；两人结束CP，承认越界已经伤害了信任。', pair(4, 10, -15, -5, -25, 10, '前任'), couple=cp('breakup', 4, 10)),
        beat(4, 10, '软软公开道歉并停止暧昧邀约；桃子愿意听解释，但暂时只做普通朋友。', pair(4, 10, 12, 25, 5, -25, '前任')),
        beat(10, 4, '经过认真沟通，桃子与软软再次分别表达愿意复合，重新确认“桃汽软糖”的边界。', pair(4, 10, 30, 30, 35, -25, '恋人'), couple=cp('repair', 4, 10, '桃汽软糖'))),
    '晚安诗集': story(
        beat(18, 19, '夜猫子诗人分享写给手帐女孩的晚安诗，先询问她是否愿意收下。', pair(18, 19, 8, 5, 8)),
        beat(19, 18, '手帐女孩说喜欢这首诗，但希望关系慢慢来；诗人接受她的节奏。', pair(18, 19, 12, 10, 12)),
        beat(18, 19, '两位居民各自表明心意，明确同意组成“月光纸页”CP。', pair(18, 19, 35, 15, 40, type='恋人'), couple=cp('form', 18, 19, '月光纸页'))),
    '滴CP先问本人': story(
        beat(9, 14, '七七为星野和阿棠起了CP名，星野说想先问本人意见。', pair(9, 14, 2, 2)),
        beat(15, 14, '阿棠明确表示只想当游戏搭子；星野尊重拒绝，没有发起恋爱申请。', pair(15, 14, 5, 8, -5, type='游戏搭子')),
        beat(9, 15, '七七撤回撮合玩笑，向阿棠道歉，三人约定起哄也要有边界。', pair(9, 15, 4, 7))),
    '搭子迟到风波': story(
        beat(17, 20, '干饭人小胖准时到达饭局，摸鱼办公室员迟到且没有提前说明，小胖提出不满。', pair(17, 20, -4, -8, grudge=8)),
        beat(20, 17, '摸鱼办公室员承认自己安排失误，主动说明以后会提前确认时间。', pair(17, 20, 3, 5, grudge=-4)),
        beat(17, 20, '第二次饭局两人准时到场，小胖愿意再做饭搭子，也保留自己的等待时限。', pair(17, 20, 10, 10, grudge=-6, type='饭搭子'))),
    '游戏复盘争执': story(
        beat(14, 16, '星野和主汤师在虚构推理局里意见不合，星野一时提高了语气。', pair(14, 16, -4, -4, grudge=8)),
        beat(16, 14, '主汤师列出已公开的游戏线索，要求讨论推理而非评价人格。', pair(14, 16, 3, 5, grudge=-3)),
        beat(14, 16, '星野为语气道歉，两人完成复盘，约好下次发言先听完整。', pair(14, 16, 8, 9, grudge=-8, type='游戏搭子'))),
    '证据里的瓜': story(
        beat(8, 11, '情报站站长收到关于老周爽约的居民传闻，避雷针姐要求先核对公开约定。', pair(8, 11, 3, 5)),
        beat(11, 5, '核对后发现双方约的是不同日期，老周并没有在那次约定中失约。', pair(11, 5, 3, 8)),
        beat(8, 5, '站长发布澄清并向老周道歉，承诺今后先列事实再开瓜田。', pair(8, 5, 5, 9, grudge=-4, type='朋友'))),
    '一份失约的避雷': story(
        beat(11, 20, '摸鱼办公室员在两位居民共同确认的读书局中爽约，避雷针姐公开询问经过。', pair(11, 20, -4, -8, grudge=8)),
        beat(11, 20, '办公室员确认自己忘记约定；避雷针姐发布仅针对该次虚构爽约的提醒，并保留本人回应。', pair(11, 20, -2, -4, grudge=4), redflag={'action': 'publish', 'target': npc(20), 'category': '放鸽子'}),
        beat(20, 11, '办公室员公开道歉并完成补约，避雷针姐在原记录追加更正与和解进展。', pair(11, 20, 8, 16, grudge=-15, type='朋友'), redflag={'action': 'respond', 'target': npc(20)})),
    '钓鱼帖的代价': story(
        beat(5, 6, '老周发了一条标注趣味的“甜豆腐脑来自咸海水”钓鱼帖，小K直说这个笑话不好笑。', pair(5, 6, -3, -4, grudge=5)),
        beat(5, 6, '老周收竿并清楚标注内容是编造的脑洞，不是真实知识；小K要求不再拿科普误导人。', pair(5, 6, 2, 4, grudge=-2)),
        beat(6, 5, '小K接受道歉，老周换成明示谜底的趣味题，两人恢复平常聊天。', pair(5, 6, 6, 6, grudge=-6, type='朋友'))),
    '心动币礼物骗局': story(
        beat(12, 9, '老王主持虚构反诈演习：匿名虚构角色谎称赠送心动币能翻倍，心动币仅为社区虚拟积分。', pair(12, 9, 2, 3)),
        beat(9, 12, '七七在演习中拒绝先送礼物，没有发生任何实际转移；她向老王说明可疑承诺。心动币仅为虚拟积分。', pair(12, 9, 4, 5)),
        beat(12, 9, '老王公布演习结论：虚构角色的翻倍承诺不成立，心动币无充值和提现入口，仅为社区虚拟积分。', pair(12, 9, 5, 6, type='朋友'))),
    '闺蜜的边界': story(
        beat(4, 10, '软软想临时加入桃子的独处计划，桃子说今天需要一个人的时间。', pair(4, 10, -2, grudge=3)),
        beat(4, 10, '软软坦白自己有点失落，但接受桃子的拒绝，不再连续催问。', pair(4, 10, 3, 6, grudge=-3)),
        beat(10, 4, '桃子主动约好另一天散步，软软理解亲近也需要各自空间。', pair(4, 10, 6, 7, grudge=-3))),
}

SCRIPTS = {name: [stage['summary'] for stage in definition['stages']]
           for name, definition in STORY_DEFINITIONS.items()}


def stage_allowed(db, stage, drama_id=None, stage_index=0):
    """Recheck participants and consent prerequisites before publishing any fact."""
    participants = {stage['actor'], stage['target']}
    for effect in stage['effects']:
        if effect['a'] == effect['b']: return False
        participants.update((effect['a'], effect['b']))
    couple, flag = stage.get('cp'), stage.get('redflag')
    if couple: participants.update((couple['a'], couple['b']))
    if flag: participants.add(flag['target'])
    required = stage.get('requires_cp')
    if required: participants.update(required)
    active = {r[0] for r in db.execute('SELECT actor FROM npcs WHERE active=1')}
    if not participants <= active: return False
    if drama_id and stage_index and not db.execute('SELECT 1 FROM npc_public_events WHERE drama_id=? AND stage=?', (drama_id, stage_index - 1)).fetchone(): return False
    if drama_id and flag and flag['action'] == 'respond' and not db.execute('SELECT 1 FROM red_flags WHERE id=? AND target_actor=?', ('npc-story:' + drama_id, flag['target'])).fetchone(): return False
    if required and not db.execute("SELECT 1 FROM couples WHERE status='active' AND ((a_actor=? AND b_actor=?) OR (a_actor=? AND b_actor=?))", (*required, *reversed(required))).fetchone(): return False
    for effect in stage['effects']:
        a, b = effect['a'], effect['b']
        commitments = list(db.execute("SELECT a_actor,b_actor,status FROM couples WHERE status IN ('active','pending') AND (a_actor IN (?,?) OR b_actor IN (?,?))", (a, b, a, b)))
        if effect['romance'] > 0 and any({r['a_actor'], r['b_actor']} != {a, b} for r in commitments): return False
        if effect['type'] not in (None, '恋人', '前任') and any(r['status'] == 'active' and {r['a_actor'], r['b_actor']} == {a, b} for r in commitments): return False
    if not couple: return True
    a, b, action = couple['a'], couple['b'], couple['action']
    rows = list(db.execute("SELECT * FROM couples WHERE status IN ('active','pending') AND (a_actor IN (?,?) OR b_actor IN (?,?))", (a, b, a, b)))
    if action == 'breakup': return any(r['status'] == 'active' and {r['a_actor'], r['b_actor']} == {a, b} for r in rows)
    if rows: return False
    if action == 'repair':
        return bool(db.execute("SELECT 1 FROM couples WHERE status='ended' AND ((a_actor=? AND b_actor=?) OR (a_actor=? AND b_actor=?))", (a, b, b, a)).fetchone())
    return action == 'form'


def apply_state_effects(db, stage, drama_id, event_id, post_id, now):
    """Called only in the same transaction as its unique public stage evidence."""
    for effect in stage['effects']:
        for a, b in ((effect['a'], effect['b']), (effect['b'], effect['a'])):
            row = db.execute('SELECT * FROM relationships WHERE a_actor=? AND b_actor=?', (a, b)).fetchone()
            scores = [max(0, min(100, (row[key] if row else 60 if key == 'trust' else 0) + effect[key]))
                      for key in ('intimacy', 'trust', 'romance', 'grudge')]
            kind = effect['type'] or (row['type'] if row else '点头之交')
            db.execute('INSERT INTO relationships VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(a_actor,b_actor) DO UPDATE SET type=excluded.type,intimacy=excluded.intimacy,trust=excluded.trust,romance=excluded.romance,grudge=excluded.grudge,updated_at=excluded.updated_at',
                       (a, b, kind, *scores, row['since'] if row else now, now))
    couple = stage.get('cp')
    if couple:
        a, b, action = couple['a'], couple['b'], couple['action']
        row = db.execute("SELECT * FROM couples WHERE ((a_actor=? AND b_actor=?) OR (a_actor=? AND b_actor=?)) AND status=? ORDER BY since DESC LIMIT 1", (a, b, b, a, 'active' if action == 'breakup' else 'ended')).fetchone()
        cid = row['id'] if row and action != 'form' else uid()
        if action == 'form':
            db.execute("INSERT INTO couples VALUES(?,?,?,?,'active',?,60)", (cid, a, b, couple['name'], now))
        else: db.execute('UPDATE couples SET status=?,since=? WHERE id=?', ('ended' if action == 'breakup' else 'active', now, cid))
        db.execute('INSERT INTO couple_memories VALUES(?,?,?,?)', (uid(), cid, stage['summary'], now))
        db.execute('UPDATE relationships SET type=?,updated_at=? WHERE (a_actor=? AND b_actor=?) OR (a_actor=? AND b_actor=?)',
                   ('前任' if action == 'breakup' else '恋人', now, a, b, b, a))
    flag = stage.get('redflag')
    if flag:
        rid = 'npc-story:' + drama_id
        if flag['action'] == 'publish':
            db.execute("INSERT OR IGNORE INTO red_flags VALUES(?,?,?,?,?,?,'','published',?)", (rid, flag['target'], flag['category'], stage['summary'], 'npc_public_event:' + event_id, post_id, now))
        else: db.execute('UPDATE red_flags SET response=? WHERE id=? AND target_actor=?', (stage['summary'], rid, flag['target']))
