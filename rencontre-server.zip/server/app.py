"""Rencontre local/LAN backend. No model key or private character-card fields."""
import asyncio
import base64
from contextlib import contextmanager, asynccontextmanager, closing, suppress
import hashlib
import json
import logging
import os
from pathlib import Path
import re
import secrets
import sqlite3
import threading
import time

from fastapi import FastAPI, BackgroundTasks, Depends, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response, JSONResponse, RedirectResponse, FileResponse
from starlette.concurrency import run_in_threadpool
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, ConfigDict, Field, field_validator

from . import database, games, media
from .community import Community
from .npc_engine import NPCEngine
from .npc_models import install_routes as install_npc_model_routes
from .npc_visibility import discovery_post_visibility
from .resident_comments import comment_visibility
from .ai_social import install_routes as install_ai_social_routes, complete_action, validate_peer_room, validate_social_members, bind_social_room, existing_delivery, record_delivery
from .chat_turns import claim_turn, validate_turn, complete_turn, release_turn
from .community_voice import natural_speech

ORIGIN_RE = r'^https?://(?:localhost|127\.0\.0\.1|10\.\d{1,3}\.\d{1,3}\.\d{1,3}|192\.168\.\d{1,3}\.\d{1,3}|172\.(?:1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3}|[A-Za-z](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?(?:\.local)?|\[(?:::1|[fF][cCdD][0-9A-Fa-f:]*|[fF][eE]80:[0-9A-Fa-f:]*)\])(?::\d+)?$'
CAPABILITIES = ['community','posts.kinds','couples','wallet','npc.directory','npc.models','npc.activity','npc.personas','posts.changed','posts.tags','actors.pagination','public.actors','topics','rooms.pagination','notifications.read','images.previews','games.timeouts','games.seat-views']
logger = logging.getLogger('rencontre')
TOPICS = ['今天的一件小事','喜欢的食物','想去的地方','最近听的歌','周末计划','共同创作一个小故事']


def uid(): return secrets.token_hex(12)
def create_invitation(db,aid):
    for _ in range(20):
        try:
            code=secrets.token_hex(5).upper()
            db.execute('INSERT INTO invitations(actor_id,code) VALUES(?,?)',(aid,code))
            return code
        except sqlite3.IntegrityError:
            if db.execute('SELECT 1 FROM invitations WHERE actor_id=?',(aid,)).fetchone(): return
    raise RuntimeError('邀请码分配失败，请重试')
def now(): return time.time()
def pack(v): return json.dumps(v,ensure_ascii=False,separators=(',',':'))
def check(ok,msg,status=400):
    if not ok: raise HTTPException(status,msg)


class Strict(BaseModel): model_config=ConfigDict(extra='forbid')
class Register(Strict):
    username:str=Field(min_length=3,max_length=32)
    password:str=Field(min_length=10,max_length=128)
    name:str=Field(min_length=1,max_length=40)
class Login(Strict):
    username:str=Field(max_length=32)
    password:str=Field(max_length=128)
def _gender_alias(value):
    return {'male_shuangluan':'male_dual','female_shuangluan':'female_dual'}.get(value,value) if isinstance(value,str) else value
class ActorIn(Strict):
    name:str=Field(min_length=1,max_length=40)
    kind:str='ai'
    bio:str=Field(default='',max_length=160)
    gender:str=Field(default='',pattern=r'^(?:male|female|male_dual|female_dual)?$')
    _normalize_gender=field_validator('gender',mode='before')(_gender_alias)
class MainCharacterIn(Strict):
    source_id:str=Field(min_length=1,max_length=160,pattern=r'^\S+$')
    name:str=Field(min_length=1,max_length=40)
    actor_id:str|None=Field(default=None,min_length=1,max_length=160)
class ProfileIn(Strict):
    gender:str|None=Field(default=None,pattern=r'^(?:male|female|male_dual|female_dual)?$')
    _normalize_gender=field_validator('gender',mode='before')(_gender_alias)
    name:str=Field(min_length=1,max_length=40)
    bio:str=Field(default='',max_length=160)
    avatar_id:str|None=Field(default=None,max_length=64)
    cover_id:str|None=Field(default=None,max_length=64)
class ReadIn(Strict): seq:int=Field(ge=0)
class FriendIn(Strict):
    actor_id:str
    target_id:str=''
    invite_code:str=Field(default='',max_length=20)
class FriendResponse(Strict): accept:bool
class RoomIn(Strict):
    name:str=Field(default='新会话',min_length=1,max_length=60)
    actor_ids:list[str]=Field(min_length=2,max_length=30)
    kind:str='group'
class MemberIn(Strict): actor_id:str
class RoomProfileIn(Strict):
    name:str=Field(min_length=1,max_length=60)
    announcement:str=Field(default='',max_length=1000)
class MessageIn(Strict):
    actor_id:str
    text:str=Field(min_length=1,max_length=4000)
    lease:str=''
    reply_to:str=Field(default='',max_length=64)
class AIIn(Strict):
    enabled:bool=True
    cooldown:int=Field(default=8,ge=2,le=300)
    max_auto:int=Field(default=8,ge=1,le=30)
    max_chars:int=Field(default=300,ge=40,le=600)
    topics:list[str]=Field(default_factory=lambda:TOPICS.copy(),min_length=1,max_length=20)
class TurnIn(Strict):
    actor_id:str
    lease:str=Field(default='',max_length=128)
    coalesce:bool=False
class PostIn(Strict):
    actor_id:str
    text:str=Field(default='',max_length=2000)
    image_id:str=''
    repost_id:str=''
    tags:list[str]=Field(default_factory=list,max_length=10)
    post_kind:str='daily'
    channel:str='daily'
    poll_options:list[str]=Field(default_factory=list,max_length=4)
    recruit_capacity:int=Field(default=4,ge=2,le=20)
    recruit_type:str=Field(default='',max_length=60)
    action_lease:str=Field(default='',max_length=128)
    delivery_id:str=Field(default='',max_length=160,pattern=r'^[A-Za-z0-9_-]*$')
class NotificationReadIn(Strict):
    kind:str='all'
    through_seq:int|None=Field(default=None,ge=0)
    ids:list[str]=Field(default_factory=list,max_length=300)
class CommentIn(Strict):
    actor_id:str
    text:str=Field(min_length=1,max_length=500)
    action_lease:str=Field(default='',max_length=128)
class ImageIn(Strict):
    data:str=Field(max_length=8_400_000)
    mime:str
class GameIn(Strict):
    actor_id:str
    kind:str
    options:dict=Field(default_factory=dict)
class GameAction(Strict):
    actor_id:str
    action:str=Field(max_length=30)
    data:dict=Field(default_factory=dict)


class Store:
    def __init__(self,path,*,namespace='',budget_store=None,root_community=None):
        self.path=str(path)
        self.namespace=namespace
        self.budget_store=budget_store or self
        self.root_community=root_community
        self.remote_url=os.environ.get('RENCONTRE_TURSO_URL','').strip()
        self.auth_token=os.environ.get('RENCONTRE_TURSO_AUTH_TOKEN','').strip()
        self.serverless=os.environ.get('RENCONTRE_SERVERLESS','0')=='1'
        if bool(self.remote_url)!=bool(self.auth_token) or self.serverless and not self.remote_url:
            raise ValueError('RENCONTRE_TURSO_URL and RENCONTRE_TURSO_AUTH_TOKEN must both be configured')
        self.schema_ready=False
        self.schema_snapshot=None
        self.last_activity=0.0
        if self.serverless:
            with self.db() as db:
                tables=db.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name IN ('schema_migrations','community_meta')").fetchone()[0]
                if tables==2:
                    rows=db.execute("SELECT 'marker' AS kind,key AS name,value FROM community_meta "
                                    "WHERE key IN ('schema','seeded-residents','npc-runtime-schema','npc-memory-schema') "
                                    "UNION ALL SELECT 'object',name,'' FROM sqlite_master WHERE name IN "
                                    "('npc_jobs','npc_jobs_due','npc_public_events','npc_public_events_actor',"
                                    "'npc_memory_sources','npc_memory_source_room','npc_memory_source_subject',"
                                    "'archive_world_registry','npc_dispatch_jobs') "
                                    "UNION ALL SELECT 'migration',name,'' FROM schema_migrations WHERE name='ux-1.4'").fetchall()
                    markers={row['name']:row['value'] for row in rows if row['kind']=='marker'}
                    self.schema_ready=(markers.get('schema')=='1.5' and 'seeded-residents' in markers
                                       and any(row['kind']=='migration' for row in rows))
                    if self.schema_ready:
                        objects={row['name'].removeprefix(namespace) if namespace else row['name']
                                 for row in rows if row['kind']=='object'}
                        self.schema_snapshot={'markers':markers,'objects':objects}
            if self.schema_ready:return
        if not self.remote_url:Path(path).parent.mkdir(parents=True,exist_ok=True)
        # Snapshot existing databases before any migration changes. Never copy WAL files.
        if not namespace and not self.remote_url and Path(path).exists() and Path(path).stat().st_size:
            with closing(sqlite3.connect(self.path)) as source:
                migrated=source.execute("SELECT 1 FROM sqlite_master WHERE name='community_meta'").fetchone()
                if not migrated:
                    backup=Path(self.path+'.pre-community.bak')
                    if not backup.exists():
                        with closing(sqlite3.connect(str(backup))) as target:source.backup(target)
        with self.db(write=True) as db:
            db.executescript(('PRAGMA journal_mode=WAL;\n' if not self.remote_url else '')+'''
CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY, username TEXT UNIQUE NOT NULL, password TEXT NOT NULL, created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), expires REAL NOT NULL);
CREATE TABLE IF NOT EXISTS actors(id TEXT PRIMARY KEY, owner_id TEXT NOT NULL REFERENCES users(id), name TEXT NOT NULL, kind TEXT NOT NULL, bio TEXT NOT NULL DEFAULT '');
CREATE TABLE IF NOT EXISTS friend_requests(id TEXT PRIMARY KEY, source TEXT NOT NULL REFERENCES actors(id), target TEXT NOT NULL REFERENCES actors(id), status TEXT NOT NULL, created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS friendships(a TEXT NOT NULL, b TEXT NOT NULL, PRIMARY KEY(a,b));
CREATE TABLE IF NOT EXISTS follows(user_id TEXT NOT NULL REFERENCES users(id), actor_id TEXT NOT NULL REFERENCES actors(id), created REAL NOT NULL, PRIMARY KEY(user_id,actor_id));
CREATE TABLE IF NOT EXISTS invitations(actor_id TEXT PRIMARY KEY REFERENCES actors(id), code TEXT UNIQUE NOT NULL);
CREATE TABLE IF NOT EXISTS rooms(id TEXT PRIMARY KEY, name TEXT NOT NULL, kind TEXT NOT NULL, creator TEXT NOT NULL REFERENCES users(id), ai TEXT NOT NULL, created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS members(room_id TEXT NOT NULL REFERENCES rooms(id), actor_id TEXT NOT NULL REFERENCES actors(id), PRIMARY KEY(room_id,actor_id));
CREATE TABLE IF NOT EXISTS room_profiles(room_id TEXT PRIMARY KEY REFERENCES rooms(id), announcement TEXT NOT NULL DEFAULT '');
CREATE TABLE IF NOT EXISTS messages(seq INTEGER PRIMARY KEY AUTOINCREMENT, id TEXT UNIQUE NOT NULL, room_id TEXT NOT NULL REFERENCES rooms(id), actor_id TEXT NOT NULL REFERENCES actors(id), text TEXT NOT NULL, created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS room_reads(user_id TEXT NOT NULL REFERENCES users(id), room_id TEXT NOT NULL REFERENCES rooms(id), seq INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(user_id,room_id));
CREATE TABLE IF NOT EXISTS images(id TEXT PRIMARY KEY, owner_id TEXT NOT NULL REFERENCES users(id), mime TEXT NOT NULL, data BLOB NOT NULL, created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS posts(seq INTEGER PRIMARY KEY AUTOINCREMENT, id TEXT UNIQUE NOT NULL, actor_id TEXT NOT NULL REFERENCES actors(id), text TEXT NOT NULL, image_id TEXT NOT NULL DEFAULT '', repost_id TEXT NOT NULL DEFAULT '', created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS likes(post_id TEXT NOT NULL, user_id TEXT NOT NULL, PRIMARY KEY(post_id,user_id));
CREATE TABLE IF NOT EXISTS comments(seq INTEGER PRIMARY KEY AUTOINCREMENT, id TEXT UNIQUE NOT NULL, post_id TEXT NOT NULL, actor_id TEXT NOT NULL REFERENCES actors(id), text TEXT NOT NULL, created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS games(id TEXT PRIMARY KEY, room_id TEXT NOT NULL REFERENCES rooms(id), state TEXT NOT NULL, created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS image_variants(image_id TEXT NOT NULL REFERENCES images(id) ON DELETE CASCADE, size TEXT NOT NULL, mime TEXT NOT NULL, data BLOB NOT NULL, PRIMARY KEY(image_id,size));
CREATE TABLE IF NOT EXISTS post_tags(post_id TEXT NOT NULL, tag TEXT NOT NULL, PRIMARY KEY(post_id,tag));
CREATE INDEX IF NOT EXISTS post_tags_tag ON post_tags(tag,post_id);
CREATE TABLE IF NOT EXISTS notifications(seq INTEGER PRIMARY KEY AUTOINCREMENT, id TEXT UNIQUE NOT NULL, user_id TEXT NOT NULL REFERENCES users(id), kind TEXT NOT NULL, actor_id TEXT NOT NULL, target_id TEXT NOT NULL DEFAULT '', post_id TEXT NOT NULL DEFAULT '', source_id TEXT NOT NULL DEFAULT '', text TEXT NOT NULL DEFAULT '', created REAL NOT NULL, read INTEGER NOT NULL DEFAULT 0);
CREATE INDEX IF NOT EXISTS notifications_owner ON notifications(user_id,read,seq);
CREATE INDEX IF NOT EXISTS likes_post ON likes(post_id);
CREATE INDEX IF NOT EXISTS comments_post ON comments(post_id,seq);
CREATE INDEX IF NOT EXISTS posts_actor ON posts(actor_id,seq);
CREATE INDEX IF NOT EXISTS members_actor ON members(actor_id,room_id);
CREATE TABLE IF NOT EXISTS schema_migrations(name TEXT PRIMARY KEY);
CREATE INDEX IF NOT EXISTS messages_room ON messages(room_id,seq);
CREATE INDEX IF NOT EXISTS requests_target ON friend_requests(target,status);
CREATE INDEX IF NOT EXISTS actors_owner ON actors(owner_id);
''')
            columns={r[1] for r in db.execute('PRAGMA table_info(actors)')}
            for column in ('avatar_id','cover_id'):
                if column not in columns: db.execute(f"ALTER TABLE actors ADD COLUMN {column} TEXT NOT NULL DEFAULT ''")
            for r in db.execute('SELECT id FROM actors WHERE id NOT IN (SELECT actor_id FROM invitations)').fetchall():
                create_invitation(db,r['id'])
            if not db.execute("SELECT 1 FROM schema_migrations WHERE name='ux-1.4'").fetchone():
                # Backfill genuine old interactions once; historical entries start read.
                db.execute("INSERT INTO notifications(id,user_id,kind,actor_id,post_id,source_id,text,created,read) SELECT 'legacy-comment-'||c.id,a.owner_id,'comments',c.actor_id,c.post_id,c.id,c.text,c.created,1 FROM comments c JOIN posts p ON p.id=c.post_id JOIN actors a ON a.id=p.actor_id JOIN actors sender ON sender.id=c.actor_id WHERE a.owner_id<>sender.owner_id")
                db.execute("INSERT INTO notifications(id,user_id,kind,actor_id,target_id,created,read) SELECT 'legacy-follow-'||f.user_id||'-'||f.actor_id,a.owner_id,'followers',sender.id,f.actor_id,f.created,1 FROM follows f JOIN actors a ON a.id=f.actor_id JOIN actors sender ON sender.owner_id=f.user_id AND sender.kind='user' WHERE a.owner_id<>f.user_id")
                db.execute("INSERT INTO notifications(id,user_id,kind,actor_id,post_id,created,read) SELECT 'legacy-like-'||l.user_id||'-'||l.post_id,a.owner_id,'likes',sender.id,l.post_id,p.created,1 FROM likes l JOIN posts p ON p.id=l.post_id JOIN actors a ON a.id=p.actor_id JOIN actors sender ON sender.owner_id=l.user_id AND sender.kind='user' WHERE a.owner_id<>l.user_id")
                db.execute("INSERT INTO notifications(id,user_id,kind,actor_id,target_id,source_id,created,read) SELECT 'legacy-request-'||f.id,a.owner_id,'requests',f.source,f.target,f.id,f.created,0 FROM friend_requests f JOIN actors a ON a.id=f.target WHERE f.status='pending'")
                for p in db.execute('SELECT id,text FROM posts').fetchall():
                    db.executemany('INSERT OR IGNORE INTO post_tags VALUES(?,?)',[(p['id'],t) for t in hashtags(p['text'])])
                db.execute("INSERT INTO schema_migrations VALUES('ux-1.4')")

    @contextmanager
    def db(self,write=False):
        raw=database.connect(self.path,remote_url=self.remote_url,auth_token=self.auth_token)
        db=raw
        if self.namespace:
            from .sql_scope import ScopedConnection
            db=ScopedConnection(db,self.namespace)
        db.row_factory=sqlite3.Row
        try:
            if not self.remote_url:db.create_function('has_public_tag',2,lambda text,tag:int(tag in hashtags(text)),deterministic=True)
            if self.remote_url:raw.begin_transaction(write)
            else:
                db.execute('PRAGMA foreign_keys=ON')
                db.execute('BEGIN IMMEDIATE' if write else 'BEGIN')
            if write:
                from .npc_dispatch import guard_write
                guard_write(raw,self.namespace)
            yield db
            if write:guard_write(raw,self.namespace)
            if self.remote_url:raw.finish_transaction()
            else:db.commit()
        except BaseException:
            if self.remote_url:raw.finish_transaction(False)
            else:db.rollback()
            raise
        finally: db.close()

    def read(self, statements):
        """Read a complete snapshot without separate remote BEGIN/finish waits."""
        statements=list(statements)
        if not statements:return []
        if not self.remote_url:
            with self.db() as db:
                db.execute('PRAGMA query_only=ON')
                return database.query_batch(db,statements)
        raw=database.connect(self.path,remote_url=self.remote_url,auth_token=self.auth_token)
        raw.row_factory=sqlite3.Row
        if self.namespace:
            from .sql_scope import ScopedConnection
            scoped=ScopedConnection(raw,self.namespace)
            statements=[(scoped.rewrite(sql),parameters) for sql,parameters in statements]
        try:
            return raw.query_batch(statements,snapshot=True)
        except BaseException:
            raw.finish_transaction(False)
            raise
        finally:raw.close()

    def touch(self):
        self.last_activity=time.monotonic()

    def recently_active(self):
        return not self.remote_url or self.last_activity>0 and time.monotonic()-self.last_activity<120


class Hub:
    def __init__(self): self.clients={}
    async def emit(self,users,event):
        targets=[(user,ws) for user in set(users) for ws in list(self.clients.get(user,set()))]
        semaphore=asyncio.Semaphore(32)
        async def send(user,ws):
            async with semaphore:
                try: await asyncio.wait_for(ws.send_json(event),timeout=1)
                except Exception:
                    self.clients.get(user,set()).discard(ws)
                    # A silently unregistered but OPEN transport never causes
                    # client reconnect/fallback. Close it with a bounded wait.
                    try:await asyncio.wait_for(ws.close(code=1013,reason='连接过慢，请重新连接'),timeout=.5)
                    except Exception:pass
        await asyncio.gather(*(send(user,ws) for user,ws in targets))


def hashtags(text):
    return list(dict.fromkeys(re.findall(r'(?<![\w#])#([\w\u4e00-\u9fff]{1,30})',text)))[:10]


def create_app(db_path=None,*,archive_child=False,namespace='',budget_store=None,root_community=None):
    @asynccontextmanager
    async def lifespan(app):
        tasks=[] if store.serverless or archive_child else [asyncio.create_task(game_clock()),asyncio.create_task(app.state.archive_worlds.run()),asyncio.create_task(legacy_residents())]
        try: yield
        finally:
            for task in tasks:task.cancel()
            for task in tasks:
                with suppress(asyncio.CancelledError): await task
    app=FastAPI(title='Rencontre · 局域网',version='1.5.0',lifespan=lifespan)
    store=Store(db_path or os.environ.get('RENCONTRE_DB',Path(__file__).parent/'data'/'rencontre.sqlite3'),namespace=namespace,budget_store=budget_store,root_community=root_community)
    hub=Hub(); app.state.store=store; attempts={}
    app.state.archive_child=archive_child
    if not archive_child:
        from .archive_worlds import ArchiveWorlds, ArchiveWorldMiddleware
        app.state.archive_worlds=ArchiveWorlds(app)
        app.add_middleware(ArchiveWorldMiddleware,manager=app.state.archive_worlds)
    max_image_bytes=2_900_000 if store.serverless else 6*1024*1024
    # Restore running games once after a restart. Idle instances need no
    # per-second database scans; API writes keep this single-worker set awake.
    active_games=set()
    if not store.serverless:
        with store.db() as db:
            active_games={g['id'] for g in db.execute("SELECT id,state FROM games WHERE json_extract(state,'$.phase')<>'finished'") if games._clock(json.loads(g['state']))}
    game_lock=threading.Lock()

    def track_game(gid,state):
        with game_lock:
            if games._clock(state):active_games.add(gid)
            else:active_games.discard(gid)
    origins=['null','capacitor://localhost','ionic://localhost']+[v.strip() for v in os.environ.get('RENCONTRE_ORIGINS','').split(',') if v.strip()]

    @app.exception_handler(RequestValidationError)
    async def invalid_fields(request,error):
        labels={'username':'账号','password':'密码','name':'名称','bio':'简介','cooldown':'AI 冷却秒数','max_auto':'AI 连续回合数','max_chars':'AI 回复字数','topics':'话题卡','text':'正文','mime':'图片格式','data':'图片内容','actor_id':'角色','actor_ids':'会话成员','seq':'已读位置','limit':'每页数量','offset':'分页位置'}
        fields={}
        for item in error.errors():
            field=str(item['loc'][-1]);label=labels.get(field,'字段 '+field)
            kind=item['type'];ctx=item.get('ctx',{})
            if kind=='extra_forbidden': message='不支持此字段，请移除后重试'
            elif kind=='missing': message='请填写'+label
            elif kind in ('string_too_short','too_short'): message=f"至少需要 {ctx.get('min_length',1)} 个字符或项目"
            elif kind in ('string_too_long','too_long'): message=f"最多允许 {ctx.get('max_length','指定数量')} 个字符或项目"
            elif kind=='greater_than_equal': message=f"不能小于 {ctx.get('ge')}"
            elif kind=='less_than_equal': message=f"不能大于 {ctx.get('le')}"
            else: message='格式不正确，请检查后重试'
            fields[field]=label+'：'+message
        return JSONResponse({'detail':'；'.join(fields.values()),'fields':fields},status_code=422)

    @app.exception_handler(sqlite3.OperationalError)
    async def database_busy(request,error):
        status,detail=database.operational_error_details(error)
        logger.exception('Database request failed: %s %s',request.method,request.url.path,exc_info=error)
        return JSONResponse({'detail':detail},status_code=status,
                            headers={'Retry-After':'1'} if status==503 else None)

    @app.middleware('http')
    async def body_limit(request,call_next):
        if request.method!='OPTIONS' and request.url.path.startswith('/api/') and request.url.path!='/api/health':store.touch()
        # Bound actual stream bytes as well as Content-Length (chunked requests).
        limit=(4_300_000 if store.serverless else 8_500_000) if request.url.path=='/api/images' else 100_000
        length=request.headers.get('content-length','0')
        if not length.isdigit() or int(length)>limit: return JSONResponse({'detail':'请求内容过大，请缩小图片或文字后重试'},413)
        # Check the actual stream before FastAPI parses JSON. Raising inside
        # receive() is otherwise converted into a generic English 400 by it.
        total=0;chunks=[]
        async for chunk in request.stream():
            total+=len(chunk)
            if total>limit:return JSONResponse({'detail':'请求内容过大，请缩小图片或文字后重试'},413)
            chunks.append(chunk)
        request._body=b''.join(chunks)
        response=await call_next(request)
        response.headers['X-Content-Type-Options']='nosniff'
        return response

    # CORS wraps the size guard too, so another host can read its JSON 413.
    app.add_middleware(CORSMiddleware,allow_origins=origins,allow_origin_regex=ORIGIN_RE,allow_methods=['GET','POST','PUT','PATCH','DELETE'],allow_headers=['Authorization','Content-Type','If-None-Match','X-Rencontre-Archive'],expose_headers=['ETag','X-Total-Count','X-Next-Offset'])
    if not archive_child:app.add_middleware(database.RequestHttpTransportMiddleware)

    legacy_activity_lock=threading.Lock()
    legacy_activity={}

    def note_legacy_activity(request,user,token):
        if archive_child or request.headers.get('x-rencontre-archive'):return
        current=time.monotonic()
        with legacy_activity_lock:
            stale=[owner for owner,(_,stamp) in legacy_activity.items() if current-stamp>=120]
            for owner in stale:legacy_activity.pop(owner,None)
            legacy_activity[user]=(hashlib.sha256(token.encode()).hexdigest(),current)

    def active_legacy_users():
        current=time.monotonic()
        with legacy_activity_lock:
            recent={token:user for user,(token,stamp) in legacy_activity.items() if current-stamp<120}
        if not recent:return []
        valid=[]
        tokens=list(recent)
        with store.db() as db:
            for start in range(0,len(tokens),400):
                batch=tokens[start:start+400]
                rows=db.execute('SELECT hash,user_id FROM sessions WHERE expires>? AND hash IN ('+','.join('?' for _ in batch)+')',[now()]+batch)
                valid.extend(row['user_id'] for row in rows if recent[row['hash']]==row['user_id'])
        return valid

    def token_user(token):
        rows=store.read([('SELECT user_id FROM sessions WHERE hash=? AND expires>?',
                         (hashlib.sha256(token.encode()).hexdigest(),now()))])[0]
        row=rows[0] if rows else None
        check(row,'登录已过期，请重新登录',401); return row['user_id']

    def auth(request:Request):
        header=request.headers.get('authorization',''); check(header.startswith('Bearer '),'请先登录',401)
        from .archive_worlds import VerifiedSession
        verified=request.scope.get('_rencontre_verified_session')
        user=verified.user_for(store,header[7:]) if isinstance(verified,VerifiedSession) else None
        if user is None:user=token_user(header[7:])
        note_legacy_activity(request,user,header[7:])
        return user

    def actor(db,aid):
        row=db.execute("SELECT a.*,COALESCE((SELECT value FROM community_meta WHERE key='profile-gender:'||a.id),'') AS gender FROM actors a WHERE a.id=?",(aid,)).fetchone(); check(row,'角色不存在',404); return dict(row)
    def owned(db,aid,user):
        a=actor(db,aid); check(a['owner_id']==user,'不能操作别人的角色',403); return a
    def member(db,rid,user):
        row=db.execute('SELECT r.* FROM rooms r JOIN members m ON m.room_id=r.id JOIN actors a ON a.id=m.actor_id WHERE r.id=? AND a.owner_id=?',(rid,user)).fetchone()
        check(row,'无权访问这个会话',403); return dict(row)
    def room_users(db,rid): return [r[0] for r in db.execute('SELECT DISTINCT a.owner_id FROM actors a JOIN members m ON m.actor_id=a.id WHERE m.room_id=?',(rid,))]
    def depart_games(db,rid,aids,background):
        for g in db.execute('SELECT * FROM games WHERE room_id=?',(rid,)).fetchall():
            state=json.loads(g['state'])
            if games.depart(state,aids):
                db.execute('UPDATE games SET state=? WHERE id=?',(pack(state),g['id']))
                background.add_task(hub.emit,room_users(db,rid),{'type':'game.changed','room_id':rid,'game_id':g['id']})

    def tick_games():
        with game_lock:
            snapshot=active_games.copy()
        if not snapshot:return []
        # The scan takes a read snapshot. Only a genuinely changed state needs a
        # writer reservation; re-read it under that lock to avoid lost actions.
        with store.db() as db:
            active=[dict(g) for g in db.execute('SELECT * FROM games WHERE id IN ('+','.join('?' for _ in snapshot)+')',list(snapshot)) if games._clock(json.loads(g['state']))]
            members={g['room_id']:set() for g in active}
            if members:
                for m in db.execute('SELECT room_id,actor_id FROM members WHERE room_id IN ('+','.join('?' for _ in members)+')',list(members)):
                    members[m['room_id']].add(m['actor_id'])
        with game_lock:
            active_games.difference_update(snapshot)
            active_games.update(g['id'] for g in active)
        changed=[]
        for g in active:
            state=json.loads(g['state']);missing=set(state['seats'])-members[g['room_id']]
            candidate=games.depart(state,missing) if missing else games.tick(state)
            if not candidate:continue
            with store.db(write=True) as db:
                current=db.execute('SELECT * FROM games WHERE id=?',(g['id'],)).fetchone()
                if not current:continue
                state=json.loads(current['state'])
                current_members={r[0] for r in db.execute('SELECT actor_id FROM members WHERE room_id=?',(current['room_id'],))}
                missing=set(state['seats'])-current_members
                if (games.depart(state,missing) if missing else games.tick(state)):
                    db.execute('UPDATE games SET state=? WHERE id=?',(pack(state),g['id']))
                    changed.append((room_users(db,current['room_id']),{'type':'game.changed','room_id':current['room_id'],'game_id':g['id']}))
            track_game(g['id'],state)
        return changed

    async def game_clock():
        while True:
            try:
                for users,event in await run_in_threadpool(tick_games):await hub.emit(users,event)
            except Exception:logger.exception('Game clock failed; retrying next tick')
            await asyncio.sleep(1)
    def notify(db,user,kind,aid,target_id='',post_id='',source_id='',text=''):
        db.execute('INSERT INTO notifications(id,user_id,kind,actor_id,target_id,post_id,source_id,text,created) VALUES(?,?,?,?,?,?,?,?,?)',(uid(),user,kind,aid,target_id,post_id,source_id,text,now()))
    def notification_changed(background,users):
        background.add_task(hub.emit,list(users),{'type':'notifications.changed'})
    def posts_changed(background,pid,action):
        background.add_task(hub.emit,list(hub.clients),{'type':'posts.changed','post_id':pid,'action':action})
    def sender_actor(db,user): return db.execute("SELECT id FROM actors WHERE owner_id=? AND kind='user'",(user,)).fetchone()['id']
    def controlled(db,user): return [r[0] for r in db.execute('SELECT id FROM actors WHERE owner_id=?',(user,))]
    def friendly(db,a,b):
        return actor(db,a)['owner_id']==actor(db,b)['owner_id'] or db.execute('SELECT 1 FROM friendships WHERE a=? AND b=?',(a,b)).fetchone()
    def room_view(db,row,user=None):
        r=dict(row); r['ai']=json.loads(r['ai']); r['ai'].pop('lease',None)
        r['members']=[dict(a) for a in db.execute('SELECT a.* FROM actors a JOIN members m ON m.actor_id=a.id WHERE m.room_id=? ORDER BY a.id',(r['id'],))]
        profile=db.execute('SELECT announcement FROM room_profiles WHERE room_id=?',(r['id'],)).fetchone()
        r['announcement']=profile['announcement'] if profile else ''
        last=db.execute('SELECT * FROM messages WHERE room_id=? ORDER BY seq DESC LIMIT 1',(r['id'],)).fetchone()
        r['last_message']=dict(last) if last else None
        r['unread_count']=0
        if user:
            read=db.execute('SELECT seq FROM room_reads WHERE user_id=? AND room_id=?',(user,r['id'])).fetchone()
            r['unread_count']=db.execute("SELECT COUNT(*) FROM messages m JOIN actors a ON a.id=m.actor_id WHERE m.room_id=? AND m.seq>? AND (a.owner_id<>? OR a.kind='ai')",(r['id'],read['seq'] if read else 0,user)).fetchone()[0]
        return r
    def session(db,user):
        token=secrets.token_urlsafe(36); db.execute('DELETE FROM sessions WHERE expires<?',(now(),))
        db.execute('INSERT INTO sessions VALUES(?,?,?)',(hashlib.sha256(token.encode()).hexdigest(),user,now()+30*86400))
        a=dict(db.execute("SELECT * FROM actors WHERE owner_id=? AND kind='user'",(user,)).fetchone())
        return {'token':token,'user_id':user,'actor':a}
    def rate(request):
        ip=request.client.host if request.client else 'local'; key=ip
        records=[t for t in attempts.get(key,[]) if t>now()-60]; check(len(records)<15,'尝试过多，一分钟后重试',429)
        attempts[key]=records+[now()]
        if len(attempts)>1000:
            for old in list(attempts):
                if attempts[old][-1]<now()-60: del attempts[old]

    @app.get('/api/health')
    def health(): return {'ok':True,'service':'rencontre','status':'ok','mode':'cloud' if store.remote_url else 'lan','transport':'polling' if store.serverless else 'websocket','database_ready':True,'max_image_bytes':max_image_bytes,'version':'1.5.0','api_version':'1.5','capabilities':CAPABILITIES,**npc_engine.status()}

    @app.get('/',include_in_schema=False)
    def root(): return RedirectResponse('/rencontre/',status_code=307)

    @app.post('/api/register')
    def register(body:Register,request:Request):
        rate(request); check(re.fullmatch(r'[A-Za-z0-9_-]{3,32}',body.username),'账号仅允许英文、数字、下划线和短横线')
        check(body.name.strip(),'昵称不能为空')
        salt=secrets.token_hex(16); hashed=hashlib.scrypt(body.password.encode(),salt=bytes.fromhex(salt),n=16384,r=8,p=1).hex()
        with store.db(write=True) as db:
            check(not db.execute('SELECT 1 FROM users WHERE username=?',(body.username.lower(),)).fetchone(),'账号已存在',409)
            user=uid(); db.execute('INSERT INTO users VALUES(?,?,?,?)',(user,body.username.lower(),salt+':'+hashed,now()))
            aid=uid();db.execute('INSERT INTO actors(id,owner_id,name,kind,bio) VALUES(?,?,?,?,?)',(aid,user,body.name.strip(),'user',''));create_invitation(db,aid)
            result=session(db,user)
            note_legacy_activity(request,user,result['token'])
            return result

    @app.post('/api/login')
    def login(body:Login,request:Request):
        rate(request)
        with store.db(write=True) as db:
            row=db.execute('SELECT * FROM users WHERE username=?',(body.username.lower(),)).fetchone()
            salt,expected=row['password'].split(':') if row else ('0'*32,'0'*128)
            actual=hashlib.scrypt(body.password.encode(),salt=bytes.fromhex(salt),n=16384,r=8,p=1).hex()
            check(row and secrets.compare_digest(actual,expected),'账号或密码不正确',401)
            result=session(db,row['id'])
            note_legacy_activity(request,row['id'],result['token'])
            return result

    @app.post('/api/logout')
    def logout(background:BackgroundTasks,request:Request,user=Depends(auth)):
        token=request.headers['authorization'][7:]
        with store.db(write=True) as db: db.execute('DELETE FROM sessions WHERE hash=?',(hashlib.sha256(token.encode()).hexdigest(),))
        # Disconnect live streams immediately; other still-valid sessions reconnect.
        async def disconnect():
            for ws in list(hub.clients.get(user,set())):
                try: await ws.close(1008)
                except Exception: pass
        background.add_task(disconnect)
        return {'ok':True}

    @app.get('/api/me')
    def me(request:Request):
        header=request.headers.get('authorization','');check(header.startswith('Bearer '),'请先登录',401)
        # Verify the live session and read its public actors in one snapshot.
        # No cached authentication may outlive logout on another device.
        rows=store.read([("SELECT s.user_id AS login_user_id,a.*,i.code AS invite_code,"
                            "COALESCE((SELECT value FROM community_meta WHERE key='profile-gender:'||a.id),'') AS gender "
                            'FROM sessions s LEFT JOIN actors a ON a.owner_id=s.user_id '
                            'LEFT JOIN invitations i ON i.actor_id=a.id WHERE s.hash=? AND s.expires>?',
                            (hashlib.sha256(header[7:].encode()).hexdigest(),now()))])[0]
        check(rows,'登录已过期，请重新登录',401)
        user=rows[0]['login_user_id'];note_legacy_activity(request,user,header[7:])
        actors=[]
        for row in rows:
            if row['id'] is not None and row['invite_code'] is not None:
                value=dict(row);value.pop('login_user_id');actors.append(value)
        return {'user_id':user,'actors':actors}

    @app.put('/api/actors/main-character')
    def main_character(background:BackgroundTasks,body:MainCharacterIn,response:Response,user=Depends(auth)):
        check(not archive_child,'主线身份只能关联公开社区',403)
        check(body.name.strip(),'公开名称不能为空',422)
        prefix='main-character:'
        key=prefix+hashlib.sha256(pack([user,body.source_id]).encode()).hexdigest()
        with store.db(write=True) as db:
            def public_ai(aid):
                check(not aid.startswith(('w_','npc-')) and db.execute(
                    "SELECT 1 FROM actors a WHERE a.id=? AND a.owner_id=? AND a.kind='ai' "
                    'AND NOT EXISTS(SELECT 1 FROM npcs n WHERE n.actor=a.id)',(aid,user)).fetchone(),
                    '只能关联自己已发布的 AI 身份',403)
                return aid

            explicit=public_ai(body.actor_id) if body.actor_id is not None else None
            if explicit is not None:
                check(not db.execute('SELECT 1 FROM community_meta WHERE key LIKE ? AND key<>? AND value=? LIMIT 1',
                                     (prefix+'%',key,explicit)).fetchone(),
                      '这个公开 AI 已关联其他存档或角色，请创建独立身份',409)
            saved=db.execute('SELECT value FROM community_meta WHERE key=?',(key,)).fetchone()
            if saved:
                aid=public_ai(saved['value'])
                check(explicit is None or explicit==aid,'这个存档已关联其他公开 AI 身份',409)
            else:
                aid=explicit
                if aid is None:
                    matches=db.execute("SELECT a.id FROM actors a WHERE a.owner_id=? AND a.kind='ai' AND a.name=? "
                        "AND a.id NOT GLOB 'w_*' AND a.id NOT GLOB 'npc-*' "
                        'AND NOT EXISTS(SELECT 1 FROM npcs n WHERE n.actor=a.id) '
                        'AND NOT EXISTS(SELECT 1 FROM community_meta m WHERE m.key LIKE ? AND m.value=a.id) '
                        'ORDER BY a.id LIMIT 2',(user,body.name.strip(),prefix+'%')).fetchall()
                    check(len(matches)<2,'有多个同名公开 AI，请选择要关联的身份',409)
                    if matches:aid=matches[0]['id']
                if aid is None:
                    check(len(controlled(db,user))<30,'公开角色已达 30 个上限')
                    aid=uid()
                    db.execute('INSERT INTO actors(id,owner_id,name,kind,bio) VALUES(?,?,?,?,?)',
                               (aid,user,body.name.strip(),'ai',''))
                db.execute('INSERT INTO community_meta(key,value) VALUES(?,?)',(key,aid))
            invitation=db.execute('SELECT code FROM invitations WHERE actor_id=?',(aid,)).fetchone()
            if not invitation:
                create_invitation(db,aid)
                invitation=db.execute('SELECT code FROM invitations WHERE actor_id=?',(aid,)).fetchone()
            result=actor(db,aid)
            result['invite_code']=invitation['code']
        response.headers['Cache-Control']='private, no-store'
        background.add_task(hub.emit,[user],{'type':'actors.changed'})
        return result

    @app.patch('/api/actors/{aid}')
    def update_profile(background:BackgroundTasks,aid:str,body:ProfileIn,user=Depends(auth)):
        check(body.name.strip(),'公开名称不能为空')
        with store.db(write=True) as db:
            result=owned(db,aid,user)
            changes={'name':body.name.strip(),'bio':body.bio.strip()}
            images=[]
            for column in ('avatar_id','cover_id'):
                value=getattr(body,column)
                if value is not None:
                    changes[column]=value
                    if value:images.append(('SELECT 1 FROM images WHERE id=? AND owner_id=?',(value,user)))
            for valid in database.query_batch(db,images):check(valid,'只能使用自己上传的资料图片',403)
            changed={key:value for key,value in changes.items() if result[key]!=value}
            statements=[]
            if changed:
                statements.append(('UPDATE actors SET '+','.join(key+'=?' for key in changed)+' WHERE id=?',
                                   [*changed.values(),aid]))
            if body.gender is not None and body.gender!=result['gender']:
                statements.append(('INSERT INTO community_meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',
                                   ('profile-gender:'+aid,body.gender)))
                result['gender']=body.gender
            database.execute_batch(db,statements)
            result.update(changes)
        background.add_task(hub.emit,list(hub.clients),{'type':'actors.changed'})
        return result

    @app.get('/api/actors')
    def actors(response:Response,q:str='',kind:str='all',tag:str='',offset:int=0,limit:int|None=None,real_only:bool=False,user=Depends(auth)):
        return list_actors(response,q,kind,tag,offset,limit,real_only)

    def list_actors(response,q,kind,tag,offset,limit,real_only=False):
        check(0<=offset and (limit is None or 1<=limit<=200),'分页位置或数量无效')
        check(kind in ('all','ai','user'),'角色类型无效')
        check(len(q)<=100 and len(tag)<=30,'搜索条件过长')
        clauses=['(instr(lower(name),lower(?))>0 OR instr(lower(bio),lower(?))>0 OR id=?)'];params=[q.strip(),q.strip(),q.strip()]
        if kind!='all': clauses.append('kind=?');params.append(kind)
        if real_only:clauses.append('NOT EXISTS(SELECT 1 FROM npcs n WHERE n.actor=actors.id)')
        # Bio contains only the intentionally published short introduction.
        if tag and not store.remote_url: clauses.append('has_public_tag(bio,?)');params.append(tag.lstrip('#'))
        with store.db() as db:
            sql=' FROM actors WHERE '+' AND '.join(clauses)
            if tag and store.remote_url:
                # A remote SQLite service cannot register a Python UDF. Apply
                # the same complete hashtag matcher before slicing the page.
                matches=[dict(a) for a in db.execute('SELECT *'+sql+' ORDER BY name,id',params) if tag.lstrip('#') in hashtags(a['bio'])]
                total=len(matches);rows=matches[offset:offset+limit if limit is not None else None]
            else:
                rows=[dict(a) for a in db.execute('SELECT *'+sql+' ORDER BY name,id LIMIT ? OFFSET ?',params+[limit if limit is not None else -1,offset])]
                total=db.execute('SELECT COUNT(*)'+sql,params).fetchone()[0]
            response.headers['X-Total-Count']=str(total)
            response.headers['X-Next-Offset']=str(offset+len(rows)) if offset+len(rows)<total else ''
            return rows

    @app.get('/api/public/actors')
    def public_actors(response:Response,q:str='',kind:str='all',tag:str='',offset:int=0,limit:int=60,real_only:bool=False):
        return list_actors(response,q,kind,tag,offset,limit,real_only)

    @app.post('/api/actors')
    def create_actor(body:ActorIn,user=Depends(auth)):
        check(body.kind=='ai' and body.name.strip(),'仅可新增公开 AI 身份')
        with store.db(write=True) as db:
            check(len(controlled(db,user))<30,'公开角色已达 30 个上限')
            a=dict(id=uid(),owner_id=user,name=body.name.strip(),kind='ai',bio=body.bio.strip())
            db.execute('INSERT INTO actors(id,owner_id,name,kind,bio) VALUES(:id,:owner_id,:name,:kind,:bio)',a);create_invitation(db,a['id'])
            if body.gender:db.execute('INSERT INTO community_meta(key,value) VALUES(?,?)',('profile-gender:'+a['id'],body.gender))
            return actor(db,a['id'])

    def profile_view(db,aid,user=None):
        a=actor(db,aid);mine=bool(user and a['owner_id']==user)
        queries={
            'resident':('SELECT tier FROM npcs WHERE actor=?',(aid,)),
            'stats':('SELECT (SELECT COUNT(*) FROM posts WHERE actor_id=?) AS posts,'
                     '(SELECT COUNT(*) FROM follows WHERE actor_id=?) AS followers,'
                     '(SELECT COUNT(*) FROM follows WHERE user_id=?) AS following',(aid,aid,a['owner_id']))}
        if mine:queries['invitation']=('SELECT code FROM invitations WHERE actor_id=?',(aid,))
        if user:
            queries.update(
                friends=('SELECT f.a FROM friendships f JOIN actors a ON a.id=f.a WHERE a.owner_id=? AND f.b=?',(user,aid)),
                pending=("SELECT f.* FROM friend_requests f JOIN actors a ON a.id=f.source JOIN actors b ON b.id=f.target WHERE f.status='pending' AND ((a.owner_id=? AND f.target=?) OR (b.owner_id=? AND f.source=?))",(user,aid,user,aid)),
                following=('SELECT 1 FROM follows WHERE user_id=? AND actor_id=?',(user,aid)))
        loaded=dict(zip(queries,database.query_batch(db,queries.values())))
        if loaded['resident']:a.update(is_npc=True,tier=loaded['resident'][0]['tier'])
        if mine:a['invite_code']=loaded['invitation'][0][0]
        return {'actor':a,'stats':dict(loaded['stats'][0]),'is_self':mine,
                'friend_sources':[r[0] for r in loaded.get('friends',[])],
                'requests':[dict(r) for r in loaded.get('pending',[])],
                'following':bool(loaded.get('following'))}

    @app.get('/api/actors/{aid}')
    def profile(aid:str,user=Depends(auth)):
        with store.db() as db: return profile_view(db,aid,user)

    @app.get('/api/public/actors/{aid}')
    def public_profile(aid:str):
        with store.db() as db: return profile_view(db,aid)

    @app.get('/api/invitations/{code}')
    def lookup_invitation(code:str,user=Depends(auth)):
        with store.db() as db:
            code=code.strip().upper();check(re.fullmatch(r'[A-F0-9]{10}',code),'没有找到这个邀请码',404)
            found=db.execute('SELECT actor_id FROM invitations WHERE code=?',(code,)).fetchone();check(found,'没有找到这个邀请码',404)
            return actor(db,found['actor_id'])

    @app.get('/api/follows')
    def follows(user=Depends(auth)):
        return [dict(r) for r in store.read([('SELECT a.* FROM actors a JOIN follows f ON f.actor_id=a.id WHERE f.user_id=? ORDER BY f.created DESC',(user,))])[0]]

    @app.get('/api/notifications')
    def notifications(kind:str='all',before:int=0,limit:int=100,real_only:bool=False,user=Depends(auth)):
        check(kind in ('all','comments','likes','followers','requests'),'通知分类无效')
        check(0<=before and 1<=limit<=300,'通知分页无效')
        clauses=['n.user_id=?'];params=[user]
        if real_only:clauses.append('NOT EXISTS(SELECT 1 FROM npcs resident WHERE resident.actor=n.actor_id)')
        if kind!='all':clauses.append('n.kind=?');params.append(kind)
        if before:clauses.append('n.seq<?');params.append(before)
        real_clause=' AND NOT EXISTS(SELECT 1 FROM npcs resident WHERE resident.actor=notifications.actor_id)' if real_only else ''
        rows,badges,latest=store.read([
            ("SELECT n.*,a.name,a.kind AS actor_kind,a.bio,a.owner_id,a.avatar_id,a.cover_id,p.actor_id AS _anon_actor "
             "FROM notifications n JOIN actors a ON a.id=n.actor_id "
             "LEFT JOIN community_posts cp ON cp.post_id=n.post_id AND cp.post_kind='anon' "
             "LEFT JOIN posts p ON p.id=cp.post_id WHERE "+' AND '.join(clauses)+' ORDER BY n.seq DESC LIMIT ?',params+[limit]),
            ('SELECT kind,COUNT(*) AS n FROM notifications WHERE user_id=? AND read=0'+real_clause+' GROUP BY kind',(user,)),
            ('SELECT COALESCE(MAX(seq),0) FROM notifications WHERE user_id=?',(user,))])
        result={'comments':[],'likes':[],'followers':[],'requests':[],'items':[]}
        for row in rows:
            item=dict(row);anonymous_actor=item.pop('_anon_actor')
            item['actor']={'id':item['actor_id'],'name':item.pop('name'),'kind':item.pop('actor_kind'),'bio':item.pop('bio'),'owner_id':item.pop('owner_id'),'avatar_id':item.pop('avatar_id'),'cover_id':item.pop('cover_id')}
            item=community.notification_view(item,anonymous_actor)
            item['read']=bool(item['read']);item.pop('user_id')
            result[item['kind']].append(item);result['items'].append(item)
        counts={r['kind']:r['n'] for r in badges}
        result['unread_counts']={k:counts.get(k,0) for k in ('comments','likes','followers','requests')}
        result['unread_count']=sum(counts.values());result['latest_seq']=latest[0][0]
        return result

    @app.post('/api/notifications/read')
    def read_notifications(body:NotificationReadIn,background:BackgroundTasks,user=Depends(auth)):
        check(body.kind in ('all','comments','likes','followers','requests'),'通知分类无效')
        check(body.ids or body.through_seq is not None,'请提供当前已展示的通知位置或通知编号')
        with store.db(write=True) as db:
            clauses=['user_id=?'];params=[user]
            if body.ids:
                clauses.append('id IN ('+','.join('?' for _ in body.ids)+')');params.extend(body.ids)
            else: clauses.append('seq<=?');params.append(body.through_seq)
            if body.kind!='all': clauses.append('kind=?');params.append(body.kind)
            db.execute('UPDATE notifications SET read=1 WHERE '+' AND '.join(clauses),params)
        notification_changed(background,[user]);return {'ok':True}

    @app.post('/api/follows/{aid}')
    def follow(aid:str,background:BackgroundTasks,user=Depends(auth)):
        with store.db(write=True) as db:
            a=actor(db,aid); check(a['owner_id']!=user,'无需关注自己的身份')
            inserted=db.execute('INSERT OR IGNORE INTO follows VALUES(?,?,?)',(user,aid,now())).rowcount
            if inserted: notify(db,a['owner_id'],'followers',sender_actor(db,user),target_id=aid)
        if inserted: notification_changed(background,[a['owner_id']])
        return {'ok':True,'following':True}

    @app.delete('/api/follows/{aid}')
    def unfollow(aid:str,background:BackgroundTasks,user=Depends(auth)):
        with store.db(write=True) as db:
            a=actor(db,aid)
            db.execute('DELETE FROM follows WHERE user_id=? AND actor_id=?',(user,aid))
            db.execute("DELETE FROM notifications WHERE user_id=? AND kind='followers' AND actor_id=? AND target_id=?",(a['owner_id'],sender_actor(db,user),aid))
        notification_changed(background,[a['owner_id']]);return {'ok':True,'following':False}

    @app.post('/api/friends/requests')
    def request_friend(background:BackgroundTasks,body:FriendIn,user=Depends(auth)):
        with store.db(write=True) as db:
            source=owned(db,body.actor_id,user)
            check(bool(body.target_id)!=bool(body.invite_code),'请填写一个目标邀请码')
            target_id=body.target_id
            if body.invite_code:
                found=db.execute('SELECT actor_id FROM invitations WHERE code=?',(body.invite_code.strip().upper(),)).fetchone();check(found,'没有找到这个邀请码',404);target_id=found['actor_id']
            target=actor(db,target_id)
            check(source['owner_id']!=target['owner_id'],'不能添加自己的身份',409)
            check(not friendly(db,source['id'],target['id']),'已是好友或同属本机账号',409)
            check(not db.execute("SELECT 1 FROM friend_requests WHERE status='pending' AND ((source=? AND target=?) OR (source=? AND target=?))",(source['id'],target['id'],target['id'],source['id'])).fetchone(),'已有待处理申请',409)
            rid=uid(); db.execute('INSERT INTO friend_requests VALUES(?,?,?,?,?)',(rid,source['id'],target['id'],'pending',now()))
            notify(db,target['owner_id'],'requests',source['id'],target_id=target['id'],source_id=rid)
        background.add_task(hub.emit,[target['owner_id']],{'type':'friends.changed'});notification_changed(background,[target['owner_id']]); return {'id':rid}

    @app.get('/api/friends')
    def friends(user=Depends(auth)):
        with store.db() as db:
            requests=[dict(r) for r in db.execute('SELECT f.* FROM friend_requests f JOIN actors a ON a.id=f.source JOIN actors b ON b.id=f.target WHERE a.owner_id=? OR b.owner_id=? ORDER BY f.created DESC LIMIT 100',(user,user))]
            for r in requests: r.update(source_actor=actor(db,r['source']),target_actor=actor(db,r['target']))
            pairs=[dict(r) for r in db.execute('SELECT f.a AS actor_id,b.* FROM friendships f JOIN actors a ON a.id=f.a JOIN actors b ON b.id=f.b WHERE a.owner_id=?',(user,))]
            return {'requests':requests,'friends':pairs}

    @app.post('/api/friends/requests/{rid}/respond')
    def respond(background:BackgroundTasks,rid:str,body:FriendResponse,user=Depends(auth)):
        with store.db(write=True) as db:
            r=db.execute('SELECT * FROM friend_requests WHERE id=?',(rid,)).fetchone(); check(r,'申请不存在',404)
            owned(db,r['target'],user); check(r['status']=='pending','申请已处理',409)
            db.execute('UPDATE friend_requests SET status=? WHERE id=?',('accepted' if body.accept else 'rejected',rid))
            db.execute("UPDATE notifications SET read=1 WHERE user_id=? AND kind='requests' AND source_id=?",(user,rid))
            if body.accept:
                db.executemany('INSERT OR IGNORE INTO friendships VALUES(?,?)',[(r['source'],r['target']),(r['target'],r['source'])])
            users=[actor(db,r['source'])['owner_id'],user]
        background.add_task(hub.emit,users,{'type':'friends.changed'});notification_changed(background,[user]); return {'ok':True}

    @app.post('/api/rooms')
    def create_room(background:BackgroundTasks,body:RoomIn,user=Depends(auth)):
        ids=list(dict.fromkeys(body.actor_ids)); check(body.kind in ('group','direct'),'会话类型无效'); check(len(ids)>=2,'至少选择两个身份')
        check(body.kind!='direct' or len(ids)==2,'私聊仅两个身份')
        with store.db(write=True) as db:
            own=[a for a in ids if actor(db,a)['owner_id']==user]; check(own,'需要自己的身份',403)
            check(all(any(friendly(db,a,b) for a in own) for b in ids),'只能邀请你的好友或自己的角色',403)
            social_pairs=validate_social_members(db,ids)
            if body.kind=='direct':
                for row in db.execute("SELECT r.* FROM rooms r WHERE kind='direct'"):
                    existing=[r[0] for r in db.execute('SELECT actor_id FROM members WHERE room_id=?',(row['id'],))]
                    if set(existing)==set(ids):
                        bind_social_room(db,row['id'],social_pairs)
                        return room_view(db,row)
            rid=uid(); ai=AIIn().model_dump(); ai.update(auto_count=0,last_ai=0,turn=0,paused=False,lease=None)
            db.execute('INSERT INTO rooms VALUES(?,?,?,?,?,?)',(rid,body.name,body.kind,user,pack(ai),now()))
            bind_social_room(db,rid,social_pairs)
            db.executemany('INSERT INTO members VALUES(?,?)',[(rid,a) for a in ids]); result=room_view(db,db.execute('SELECT * FROM rooms WHERE id=?',(rid,)).fetchone()); users=room_users(db,rid)
        background.add_task(hub.emit,users,{'type':'rooms.changed'}); return result

    @app.get('/api/rooms')
    def rooms(response:Response,offset:int=0,limit:int|None=None,real_only:bool=False,user=Depends(auth)):
        check(offset>=0 and (limit is None or 1<=limit<=200),'会话分页无效')
        real_clause=' AND NOT EXISTS(SELECT 1 FROM members occupied JOIN npcs resident ON resident.actor=occupied.actor_id WHERE occupied.room_id=m.room_id)' if real_only else ''
        page='SELECT DISTINCT r.* FROM rooms r JOIN members m ON m.room_id=r.id JOIN actors a ON a.id=m.actor_id WHERE a.owner_id=?'+real_clause+' ORDER BY r.created DESC,r.id LIMIT ? OFFSET ?'
        parameters=(user,limit if limit is not None else -1,offset)
        visible='('+page+')'
        # Repeat the bounded page selection inside one snapshot so metadata
        # cannot require another network wait or escape the viewer's rooms.
        rows,counts,member_rows,profile_rows,last_rows,unread_rows=store.read([
            (page,parameters),
            ('SELECT COUNT(DISTINCT m.room_id) FROM members m JOIN actors a ON a.id=m.actor_id WHERE a.owner_id=?'+real_clause,(user,)),
            ('SELECT m.room_id,a.* FROM members m JOIN actors a ON a.id=m.actor_id JOIN '+visible+' v ON v.id=m.room_id ORDER BY a.id',parameters),
            ('SELECT p.* FROM room_profiles p JOIN '+visible+' v ON v.id=p.room_id',parameters),
            ('SELECT * FROM messages WHERE seq IN (SELECT MAX(m.seq) FROM messages m JOIN '+visible+' v ON v.id=m.room_id GROUP BY m.room_id)',parameters),
            ("SELECT m.room_id,COUNT(*) AS n FROM messages m JOIN "+visible+" v ON v.id=m.room_id JOIN actors a ON a.id=m.actor_id LEFT JOIN room_reads rr ON rr.room_id=m.room_id AND rr.user_id=? WHERE m.seq>COALESCE(rr.seq,0) AND (a.owner_id<>? OR a.kind='ai') GROUP BY m.room_id",parameters+(user,user)),
        ])
        total=counts[0][0]
        response.headers['X-Total-Count']=str(total);response.headers['X-Next-Offset']=str(offset+len(rows)) if offset+len(rows)<total else ''
        members={r['id']:[] for r in rows}
        for a in member_rows:
            item=dict(a);rid=item.pop('room_id');members[rid].append(item)
        profiles={r['room_id']:r['announcement'] for r in profile_rows}
        lasts={r['room_id']:dict(r) for r in last_rows}
        unreads={r['room_id']:r['n'] for r in unread_rows}
        result=[]
        for row in rows:
            r=dict(row);r['ai']=json.loads(r['ai']);r['ai'].pop('lease',None)
            r.update(members=members[r['id']],announcement=profiles.get(r['id'],''),last_message=lasts.get(r['id']),unread_count=unreads.get(r['id'],0));result.append(r)
        return result

    @app.post('/api/rooms/{rid}/read')
    def mark_read(rid:str,body:ReadIn,background:BackgroundTasks,user=Depends(auth)):
        with store.db(write=True) as db:
            member(db,rid,user)
            latest=db.execute('SELECT COALESCE(MAX(seq),0) FROM messages WHERE room_id=?',(rid,)).fetchone()[0]
            check(body.seq<=latest,'已读位置超过当前会话消息')
            db.execute('INSERT INTO room_reads(user_id,room_id,seq) VALUES(?,?,?) ON CONFLICT(user_id,room_id) DO UPDATE SET seq=MAX(room_reads.seq,excluded.seq)',(user,rid,body.seq))
            users=room_users(db,rid)
        background.add_task(hub.emit,users,{'type':'room.read','room_id':rid,'user_id':user,'seq':body.seq})
        return {'ok':True}

    @app.patch('/api/rooms/{rid}')
    def update_room(background:BackgroundTasks,rid:str,body:RoomProfileIn,user=Depends(auth)):
        check(body.name.strip(),'群名称不能为空')
        with store.db(write=True) as db:
            r=member(db,rid,user);check(r['kind']=='group','私聊没有群资料');check(r['creator']==user,'只有群主可以编辑群资料',403)
            db.execute('UPDATE rooms SET name=? WHERE id=?',(body.name.strip(),rid))
            db.execute('INSERT INTO room_profiles VALUES(?,?) ON CONFLICT(room_id) DO UPDATE SET announcement=excluded.announcement',(rid,body.announcement.strip()))
            users=room_users(db,rid)
        background.add_task(hub.emit,users,{'type':'rooms.changed'});return {'ok':True}

    @app.post('/api/rooms/{rid}/leave')
    def leave_room(background:BackgroundTasks,rid:str,user=Depends(auth)):
        with store.db(write=True) as db:
            r=member(db,rid,user);check(r['kind']=='group','只能退出群聊');check(r['creator']!=user,'群主请先解散群聊',409)
            users=room_users(db,rid)
            aids=[r[0] for r in db.execute('SELECT a.id FROM actors a JOIN members m ON m.actor_id=a.id WHERE m.room_id=? AND a.owner_id=?',(rid,user))]
            depart_games(db,rid,aids,background)
            db.execute('DELETE FROM members WHERE room_id=? AND actor_id IN (SELECT id FROM actors WHERE owner_id=?)',(rid,user))
            db.execute('DELETE FROM room_reads WHERE room_id=? AND user_id=?',(rid,user))
        background.add_task(hub.emit,users,{'type':'rooms.changed'});return {'ok':True}

    @app.delete('/api/rooms/{rid}')
    def disband_room(background:BackgroundTasks,rid:str,user=Depends(auth)):
        with store.db(write=True) as db:
            r=member(db,rid,user);check(r['kind']=='group','只能解散群聊');check(r['creator']==user,'只有群主可以解散群聊',403)
            users=room_users(db,rid)
            for table in ('games','messages','room_reads','members','room_profiles'): db.execute(f'DELETE FROM {table} WHERE room_id=?',(rid,))
            db.execute('DELETE FROM rooms WHERE id=?',(rid,))
        background.add_task(hub.emit,users,{'type':'rooms.changed'});return {'ok':True}

    @app.delete('/api/rooms/{rid}/members/{aid}')
    def remove_member(background:BackgroundTasks,rid:str,aid:str,user=Depends(auth)):
        with store.db(write=True) as db:
            r=member(db,rid,user);check(r['kind']=='group' and r['creator']==user,'只有群主可以移出成员',403)
            target=actor(db,aid);check(target['owner_id']!=user or target['kind']=='ai','不能移出群主自己的用户身份')
            users=room_users(db,rid);depart_games(db,rid,[aid],background);db.execute('DELETE FROM members WHERE room_id=? AND actor_id=?',(rid,aid))
        background.add_task(hub.emit,users,{'type':'rooms.changed'});return {'ok':True}

    @app.post('/api/rooms/{rid}/members')
    def add_member(background:BackgroundTasks,rid:str,body:MemberIn,user=Depends(auth)):
        with store.db(write=True) as db:
            r=member(db,rid,user); check(r['kind']=='group','私聊不可添加成员')
            own=[x[0] for x in db.execute('SELECT a.id FROM actors a JOIN members m ON a.id=m.actor_id WHERE m.room_id=? AND a.owner_id=?',(rid,user))]
            check(any(friendly(db,a,body.actor_id) for a in own),'只能添加自己或自己身份的好友',403)
            social_pairs=validate_social_members(db,[row[0] for row in db.execute('SELECT actor_id FROM members WHERE room_id=?',(rid,))]+[body.actor_id])
            check(db.execute('SELECT COUNT(*) FROM members WHERE room_id=?',(rid,)).fetchone()[0]<30,'群成员上限 30')
            db.execute('INSERT OR IGNORE INTO members VALUES(?,?)',(rid,body.actor_id)); users=room_users(db,rid)
            bind_social_room(db,rid,social_pairs)
        background.add_task(hub.emit,users,{'type':'rooms.changed'}); return {'ok':True}

    @app.get('/api/rooms/{rid}/messages')
    def messages(rid:str,after:int=0,before:int=0,user=Depends(auth)):
        with store.db() as db:
            member(db,rid,user)
            check(after>=0 and before>=0 and not (after and before),'消息分页位置无效')
            if after: rows=db.execute('SELECT * FROM messages WHERE room_id=? AND seq>? ORDER BY seq LIMIT 100',(rid,after))
            elif before: rows=reversed(db.execute('SELECT * FROM messages WHERE room_id=? AND seq<? ORDER BY seq DESC LIMIT 100',(rid,before)).fetchall())
            else: rows=reversed(db.execute('SELECT * FROM messages WHERE room_id=? ORDER BY seq DESC LIMIT 100',(rid,)).fetchall())
            return community.message_views(db,rows,user)

    @app.post('/api/rooms/{rid}/messages')
    def send_message(background:BackgroundTasks,rid:str,body:MessageIn,user=Depends(auth)):
        check(body.text.strip(),'消息不能为空')
        with store.db(write=True) as db:
            r=member(db,rid,user); a=owned(db,body.actor_id,user)
            check(db.execute('SELECT 1 FROM members WHERE room_id=? AND actor_id=?',(rid,a['id'])).fetchone(),'该身份不在会话中',403)
            ai=json.loads(r['ai'])
            if a['kind']=='ai':
                validate_peer_room(db,rid,a['id'])
                lease=validate_turn(db,rid,a['id'],ai,body.lease,now())
                check(ai['enabled'] and not ai['paused'] and ai['auto_count']<ai['max_auto'],'AI 回合已暂停',409)
                check(lease.get('id')==body.lease and lease.get('actor')==a['id'] and lease.get('expires',0)>now(),'AI 租约无效或已过期',409)
                check(len(body.text)<=ai['max_chars'],'AI 消息超过长度上限')
                ai.update(auto_count=ai['auto_count']+1,last_ai=now(),turn=ai['turn']+1)
                ai['paused']=ai['auto_count']>=ai['max_auto']
            else:
                ai.update(auto_count=0,paused=False)
                if (ai.get('lease') or {}).get('expires',0)<=now(): ai['lease']=None
            speech=natural_speech(body.text) if a['kind']=='ai' else body.text.strip()
            check(speech,'AI 没有返回可发送的聊天正文，请重试',422)
            msg=dict(id=uid(),room_id=rid,actor_id=a['id'],text=speech,created=now())
            db.execute('INSERT INTO messages(id,room_id,actor_id,text,created) VALUES(:id,:room_id,:actor_id,:text,:created)',msg)
            if a['kind']=='ai':complete_turn(ai,lease)
            msg['seq']=db.execute('SELECT last_insert_rowid()').fetchone()[0]
            community.create_message(db,msg,body.reply_to)
            msg=community.message_view(db,msg,user)
            db.execute('UPDATE rooms SET ai=? WHERE id=?',(pack(ai),rid)); users=room_users(db,rid)
        background.add_task(hub.emit,users,{'type':'room.message','room_id':rid,'message':msg}); return msg

    @app.patch('/api/rooms/{rid}/ai')
    def ai_config(background:BackgroundTasks,rid:str,body:AIIn,user=Depends(auth)):
        check(all(t.strip() and len(t)<=100 for t in body.topics),'话题卡需为 1..100 字')
        with store.db(write=True) as db:
            r=member(db,rid,user); ai=json.loads(r['ai']); ai.update(body.model_dump()); ai.update(auto_count=0,paused=False)
            db.execute('UPDATE rooms SET ai=? WHERE id=?',(pack(ai),rid)); users=room_users(db,rid)
        background.add_task(hub.emit,users,{'type':'rooms.changed'}); return {'ok':True}

    @app.post('/api/rooms/{rid}/ai/claim')
    def claim(rid:str,body:TurnIn,user=Depends(auth)):
        with store.db(write=True) as db:
            r=member(db,rid,user); a=owned(db,body.actor_id,user); ai=json.loads(r['ai'])
            # Private autoReply configuration and online availability live on each
            # owner's client. A static roster would deadlock on an offline or
            # disabled AI. Available clients coordinate through the single lease;
            # cooldown and the room's round limit still bound every reply.
            check(db.execute('SELECT 1 FROM members WHERE room_id=? AND actor_id=?',(rid,a['id'])).fetchone(),'该身份不在会话中',403)
            validate_peer_room(db,rid,a['id'])
            check(a['kind']=='ai' and ai['enabled'] and not ai['paused'] and ai['auto_count']<ai['max_auto'],'AI 自动回合已暂停',409)
            last=db.execute('SELECT actor_id FROM messages WHERE room_id=? ORDER BY seq DESC LIMIT 1',(rid,)).fetchone()
            check(not last or last['actor_id']!=a['id'],'等待其他成员回应后继续，AI 不连续回复自己',409)
            check(now()-ai['last_ai']>=ai['cooldown'],'AI 冷却中',409)
            # Every client uses the same source fence; a legacy/false coalesce
            # flag cannot opt out of stale-result validation or burst merging.
            lease=claim_turn(db,rid,a['id'],ai,now(),uid(),r['kind'])
            db.execute('UPDATE rooms SET ai=? WHERE id=?',(pack(ai),rid))
            return {'lease':lease['id'],'expires':lease['expires'],'topic':ai['topics'][ai['turn']%len(ai['topics'])],'max_chars':ai['max_chars'],**{key:lease[key] for key in ('context_seq','latest_human_seq') if key in lease}}

    @app.post('/api/rooms/{rid}/ai/release')
    def release(rid:str,body:TurnIn,user=Depends(auth)):
        with store.db(write=True) as db:
            r=member(db,rid,user); owned(db,body.actor_id,user); ai=json.loads(r['ai'])
            release_turn(ai,body.actor_id,body.lease)
            db.execute('UPDATE rooms SET ai=? WHERE id=?',(pack(ai),rid))
        return {'ok':True}

    @app.post('/api/images')
    def upload_image(body:ImageIn,user=Depends(auth)):
        check(body.mime in ('image/png','image/jpeg','image/gif','image/webp'),'仅支持 PNG/JPEG/GIF/WebP')
        try: data=base64.b64decode(body.data,validate=True)
        except Exception: raise HTTPException(400,'无效图片编码')
        check(0<len(data)<=max_image_bytes,'图片上限 2.9 MB' if store.serverless else '图片上限 6 MB',413 if store.serverless else 400)
        signatures={'image/png':data.startswith(b'\x89PNG\r\n\x1a\n'),'image/jpeg':data.startswith(b'\xff\xd8\xff'),'image/gif':data[:6] in (b'GIF87a',b'GIF89a'),'image/webp':data[:4]==b'RIFF' and data[8:12]==b'WEBP'}
        check(signatures[body.mime],'图片格式与内容不符')
        try: variants=media.previews(data)
        except ValueError as error: raise HTTPException(400,str(error))
        with store.db(write=True) as db:
            size=db.execute('SELECT (SELECT COALESCE(SUM(length(data)),0) FROM images WHERE owner_id=?) '
                            '+ (SELECT COALESCE(SUM(length(v.data)),0) FROM image_variants v '
                            'JOIN images i ON i.id=v.image_id WHERE i.owner_id=?)',(user,user)).fetchone()[0]
            check(size+len(data)+sum(len(v[2]) for v in variants)<=300*1024*1024,'此账号的图片已达 300 MB 上限，请删除未使用的图片')
            iid=uid()
            database.execute_batch(db,[('INSERT INTO images VALUES(?,?,?,?,?)',(iid,user,body.mime,data,now())),
                                       *[('INSERT INTO image_variants VALUES(?,?,?,?)',(iid,*v)) for v in variants]])
        return {'id':iid,'sizes':['original','thumb','avatar']}

    def image_referenced(db,iid):
        return bool(db.execute('SELECT 1 FROM posts WHERE image_id=? LIMIT 1',(iid,)).fetchone() or db.execute('SELECT 1 FROM actors WHERE avatar_id=? OR cover_id=? LIMIT 1',(iid,iid)).fetchone())

    def image_response(iid,request,size,user=None):
        check(size in ('original','thumb','avatar'),'图片尺寸无效')
        with store.db() as db:
            # One read checks access and selects only the requested payload. In
            # particular, stored previews never transfer images.data over Hrana.
            # Keep an inaccessible row (without its payload) to distinguish 403
            # from 404; neither route may answer 304 before this check.
            access=('WITH image_access AS (SELECT i.id,(i.owner_id=? '
                    'OR EXISTS(SELECT 1 FROM posts p WHERE p.image_id=i.id) '
                    'OR EXISTS(SELECT 1 FROM actors a WHERE a.avatar_id=i.id OR a.cover_id=i.id)) AS allowed '
                    'FROM images i WHERE i.id=?) ')
            if size=='original':
                sql=access+'SELECT a.allowed,v.mime,v.data FROM image_access a LEFT JOIN images v ON v.id=a.id AND a.allowed'
                params=(user,iid)
            else:
                sql=access+'SELECT a.allowed,v.mime,v.data FROM image_access a LEFT JOIN image_variants v ON v.image_id=a.id AND a.allowed AND v.size=?'
                params=(user,iid,size)
            r=db.execute(sql,params).fetchone(); check(r,'图片不存在',404)
            check(r['allowed'],'图片尚未公开',403)
            data=r['data'];mime=r['mime']
            if size!='original' and data is None:
                # Legacy-only fallback, after authorization in the same snapshot.
                original=db.execute('SELECT mime,data FROM images WHERE id=?',(iid,)).fetchone()
                mime,data=original['mime'],original['data']
                try: mime,data=media.legacy_preview(data,size)
                except ValueError: pass  # Existing legacy files remain readable.
            etag='"'+hashlib.sha256(data).hexdigest()+'"'
            headers={'ETag':etag,'Cache-Control':('public' if user is None else 'private')+',max-age=0,must-revalidate','X-Content-Type-Options':'nosniff'}
            matches=[v.strip().removeprefix('W/') for v in request.headers.get('if-none-match','').split(',')]
            if etag in matches or '*' in matches:return Response(status_code=304,headers=headers)
            return Response(data,media_type=mime,headers=headers)

    @app.get('/api/images/{iid}')
    def image(iid:str,request:Request,size:str='original',user=Depends(auth)):
        return image_response(iid,request,size,user)

    @app.get('/api/public/images/{iid}')
    def public_image(iid:str,request:Request,size:str='original'):
        return image_response(iid,request,size)

    @app.get('/api/images')
    def owned_images(offset:int=0,limit:int=60,user=Depends(auth)):
        check(offset>=0 and 1<=limit<=200,'图片分页无效')
        with store.db() as db:
            rows=db.execute("SELECT i.id,i.mime,i.created,length(i.data) AS bytes,(EXISTS(SELECT 1 FROM posts p WHERE p.image_id=i.id) OR EXISTS(SELECT 1 FROM actors a WHERE a.avatar_id=i.id OR a.cover_id=i.id)) AS used FROM images i WHERE i.owner_id=? ORDER BY created DESC,id LIMIT ? OFFSET ?",(user,limit,offset))
            return [{**dict(r),'used':bool(r['used'])} for r in rows]

    @app.delete('/api/images/{iid}')
    def delete_image(iid:str,user=Depends(auth)):
        with store.db(write=True) as db:
            r=db.execute('SELECT owner_id FROM images WHERE id=?',(iid,)).fetchone();check(r,'图片不存在',404)
            check(r['owner_id']==user,'只能删除自己上传的图片',403)
            check(not image_referenced(db,iid),'图片仍被动态或角色资料使用，请先移除引用',409)
            db.execute('DELETE FROM images WHERE id=?',(iid,))
        return {'ok':True}

    def post_views(db,rows,user,include_comments=False):
        rows=list(rows)
        if not rows:return []
        ids=[r['id'] for r in rows];marks=','.join('?' for _ in ids)
        aids=list({r['actor_id'] for r in rows});amarks=','.join('?' for _ in aids)
        queries={
            'authors':(f'SELECT * FROM actors WHERE id IN ({amarks})',aids),
            'likes':(f'SELECT post_id,COUNT(*) AS n FROM likes WHERE post_id IN ({marks}) GROUP BY post_id',ids),
            'counts':(f'SELECT c.post_id,COUNT(*) AS n FROM comments c WHERE c.post_id IN ({marks}) AND '+comment_visibility()+' GROUP BY c.post_id',ids),
            'tags':(f'SELECT post_id,tag FROM post_tags WHERE post_id IN ({marks}) ORDER BY rowid',ids),
        }
        if user:
            queries['liked']=(f'SELECT post_id FROM likes WHERE user_id=? AND post_id IN ({marks})',[user]+ids)
            queries['followed']=(f'SELECT actor_id FROM follows WHERE user_id=? AND actor_id IN ({amarks})',[user]+aids)
        if any(r['repost_id'] for r in rows):
            queries['originals']=(f'SELECT p.*,a.name AS author_name FROM posts p JOIN actors a ON a.id=p.actor_id WHERE p.id IN (SELECT repost_id FROM posts WHERE id IN ({marks}))',ids)
        if include_comments:
            for pid in ids:
                queries['comments:'+pid]=('SELECT c.*,a.name FROM comments c JOIN actors a ON a.id=c.actor_id WHERE c.post_id=? AND '+comment_visibility()+' ORDER BY c.seq DESC LIMIT 50',(pid,))
        # Every query uses the same transaction and requester. The remote driver
        # sends these independent reads together rather than waiting for TLS/HTTP
        # once per piece of a post before showing its comments.
        loaded=dict(zip(queries,database.query_batch(db,queries.values())))
        authors={a['id']:dict(a) for a in loaded['authors']}
        likes={r['post_id']:r['n'] for r in loaded['likes']}
        counts={r['post_id']:r['n'] for r in loaded['counts']}
        liked={r[0] for r in loaded.get('liked',[])}
        followed={r[0] for r in loaded.get('followed',[])}
        tags={pid:[] for pid in ids}
        for t in loaded['tags']:tags[t['post_id']].append(t['tag'])
        originals={r['id']:dict(r) for r in loaded.get('originals',[])}
        result=[]
        for row in rows:
            p=dict(row);pid=p['id'];p.update(actor=authors[p['actor_id']],like_count=likes.get(pid,0),comment_count=counts.get(pid,0),liked=pid in liked,following=p['actor_id'] in followed,tags=tags[pid])
            if include_comments:p['comments']=[dict(c) for c in loaded['comments:'+pid]]
            if p['repost_id']:p['original']=originals.get(p['repost_id'])
            result.append(p)
        return community.decorate_posts(db,result,user)

    def post_view(db,r,user):return post_views(db,[r],user,include_comments=True)[0]

    def list_posts(before,q,owner,ids,user,actor_id='',images=False,following=False,tag='',post_kind='',channel='',sort='latest',real_only=False):
        check(before>=0 and len(q)<=100 and len(ids)<=13000 and len(tag)<=30,'查询条件过长或分页位置无效')
        check(sort in ('latest','hot'),'排序无效')
        check(not post_kind or post_kind in community.KINDS,'动态类型无效')
        check(not channel or channel in community.CHANNELS,'频道无效')
        clauses=['(?=0 OR p.seq<?)']; params=[before,before]
        if not ids and owner!='me':clauses.append(discovery_post_visibility())
        if real_only:clauses.append('NOT EXISTS(SELECT 1 FROM npcs resident WHERE resident.actor=p.actor_id)')
        if post_kind:clauses.append("COALESCE((SELECT post_kind FROM community_posts WHERE post_id=p.id),'daily')=?");params.append(post_kind)
        if channel:clauses.append("COALESCE((SELECT channel FROM community_posts WHERE post_id=p.id),'daily')=?");params.append(channel)
        if actor_id or following:clauses.append("NOT EXISTS(SELECT 1 FROM community_posts cp WHERE cp.post_id=p.id AND cp.post_kind='anon')")
        if q.strip():
            clauses.append("(instr(lower(p.text),lower(?))>0 OR (NOT EXISTS(SELECT 1 FROM community_posts anonymous WHERE anonymous.post_id=p.id AND anonymous.post_kind='anon') AND instr(lower(a.name),lower(?))>0))"); params.extend([q.strip(),q.strip()])
        if tag: clauses.append('EXISTS(SELECT 1 FROM post_tags t WHERE t.post_id=p.id AND t.tag=?)');params.append(tag.lstrip('#'))
        if owner=='me': clauses.append('a.owner_id=?'); params.append(user)
        if actor_id: clauses.append('p.actor_id=?'); params.append(actor_id)
        if images: clauses.append("(p.image_id<>'' OR EXISTS(SELECT 1 FROM posts original WHERE original.id=p.repost_id AND original.image_id<>''))")
        if following: clauses.append('EXISTS(SELECT 1 FROM follows f WHERE f.user_id=? AND f.actor_id=p.actor_id)'); params.append(user)
        if ids:
            selected=list(dict.fromkeys(ids.split(','))); check(len(selected)<=500,'一次最多查询 500 个收藏')
            clauses.append('p.id IN ('+','.join('?' for _ in selected)+')'); params.extend(selected)
        with store.db() as db:
            order=community.heat_sql('p')+' DESC,p.seq DESC' if sort=='hot' else 'p.seq DESC'
            return post_views(db,db.execute('SELECT p.* FROM posts p JOIN actors a ON a.id=p.actor_id WHERE '+' AND '.join(clauses)+' ORDER BY '+order+' LIMIT 40',params),user)

    @app.get('/api/posts')
    def posts(before:int=0,q:str='',owner:str='',ids:str='',actor_id:str='',images:bool=False,following:bool=False,tag:str='',post_kind:str='',channel:str='',sort:str='latest',real_only:bool=False,user=Depends(auth)):
        return list_posts(before,q,owner,ids,user,actor_id,images,following,tag,post_kind,channel,sort,real_only)

    @app.get('/api/public/posts')
    def public_posts(before:int=0,q:str='',actor_id:str='',images:bool=False,tag:str='',post_kind:str='',channel:str='',sort:str='latest',real_only:bool=False):
        return list_posts(before,q,'','',None,actor_id,images,False,tag,post_kind,channel,sort,real_only)

    def list_topics(q,real_only=False):
        check(len(q)<=100,'搜索条件过长')
        real_clause=' AND '+discovery_post_visibility()
        if real_only:real_clause+=' AND NOT EXISTS(SELECT 1 FROM npcs resident WHERE resident.actor=p.actor_id)'
        return [dict(r) for r in store.read([('SELECT t.tag,COUNT(*) AS posts,COUNT(DISTINCT p.actor_id) AS participants FROM post_tags t JOIN posts p ON p.id=t.post_id WHERE instr(lower(t.tag),lower(?))>0'+real_clause+' GROUP BY t.tag ORDER BY posts DESC,MAX(p.seq) DESC,t.tag LIMIT 30',(q.strip().lstrip('#'),))])[0]]

    @app.get('/api/public/topics')
    def public_topics(q:str='',real_only:bool=False):return list_topics(q,real_only)

    @app.get('/api/topics')
    def topics(q:str='',real_only:bool=False,user=Depends(auth)):return list_topics(q,real_only)

    def find_post(pid,user):
        with store.db() as db:
            p=db.execute('SELECT * FROM posts WHERE id=?',(pid,)).fetchone(); check(p,'帖子不存在',404)
            return post_view(db,p,user)

    @app.get('/api/posts/{pid}')
    def detail(pid:str,user=Depends(auth)): return find_post(pid,user)

    @app.get('/api/public/posts/{pid}')
    def public_detail(pid:str): return find_post(pid,None)

    @app.post('/api/posts')
    def add_post(background:BackgroundTasks,body:PostIn,user=Depends(auth)):
        check(body.text.strip() or body.image_id or body.repost_id,'请填写正文或图片')
        with store.db(write=True) as db:
            owned(db,body.actor_id,user)
            delivered=existing_delivery(db,body)
            if delivered is not None:return post_view(db,delivered,user)
            if body.image_id: check(db.execute('SELECT 1 FROM images WHERE id=? AND owner_id=?',(body.image_id,user)).fetchone(),'只能发布自己上传的图片',403)
            if body.repost_id: check(db.execute('SELECT 1 FROM posts WHERE id=?',(body.repost_id,)).fetchone(),'原帖不存在',404)
            p=dict(id=uid(),actor_id=body.actor_id,text=body.text.strip(),image_id=body.image_id,repost_id=body.repost_id,created=now())
            db.execute('INSERT INTO posts(id,actor_id,text,image_id,repost_id,created) VALUES(:id,:actor_id,:text,:image_id,:repost_id,:created)',p)
            community.create_post(db,p['id'],body)
            tags=list(dict.fromkeys(hashtags(body.text)+[t.strip().lstrip('#') for t in body.tags]))
            check(len(tags)<=10 and all(re.fullmatch(r'[\w\u4e00-\u9fff]{1,30}',t) for t in tags),'话题最多 10 个，每个 1..30 字，仅支持文字、数字和下划线')
            db.executemany('INSERT INTO post_tags VALUES(?,?)',[(p['id'],t) for t in tags])
            if body.action_lease:complete_action(db,user,body.actor_id,'post',body.actor_id,body.action_lease,p['id'])
            record_delivery(db,body,p['id'])
            result=post_view(db,db.execute('SELECT * FROM posts WHERE id=?',(p['id'],)).fetchone(),user)
        posts_changed(background,p['id'],'created')
        return result

    @app.post('/api/posts/{pid}/like')
    def like(pid:str,background:BackgroundTasks,user=Depends(auth)):
        with store.db(write=True) as db:
            p=db.execute('SELECT p.*,a.owner_id FROM posts p JOIN actors a ON a.id=p.actor_id WHERE p.id=?',(pid,)).fetchone();check(p,'帖子不存在',404)
            aid=sender_actor(db,user)
            if db.execute('SELECT 1 FROM likes WHERE post_id=? AND user_id=?',(pid,user)).fetchone():
                db.execute('DELETE FROM likes WHERE post_id=? AND user_id=?',(pid,user));liked=False
                db.execute("DELETE FROM notifications WHERE kind='likes' AND post_id=? AND actor_id=?",(pid,aid))
            else:
                db.execute('INSERT INTO likes VALUES(?,?)',(pid,user));liked=True
                if p['owner_id']!=user:notify(db,p['owner_id'],'likes',aid,post_id=pid)
            count=db.execute('SELECT COUNT(*) FROM likes WHERE post_id=?',(pid,)).fetchone()[0]
        posts_changed(background,pid,'liked')
        if p['owner_id']!=user:notification_changed(background,[p['owner_id']])
        return {'ok':True,'liked':liked,'like_count':count}

    @app.post('/api/posts/{pid}/comments')
    def comment(pid:str,body:CommentIn,background:BackgroundTasks,user=Depends(auth)):
        check(body.text.strip(),'评论不能为空')
        with store.db(write=True) as db:
            owned(db,body.actor_id,user);p=db.execute('SELECT p.*,a.owner_id FROM posts p JOIN actors a ON a.id=p.actor_id WHERE p.id=?',(pid,)).fetchone();check(p,'帖子不存在',404)
            cid=uid(); db.execute('INSERT INTO comments(id,post_id,actor_id,text,created) VALUES(?,?,?,?,?)',(cid,pid,body.actor_id,body.text.strip(),now()))
            if p['owner_id']!=user:notify(db,p['owner_id'],'comments',body.actor_id,post_id=pid,source_id=cid,text=body.text.strip())
            subscribers=community.comment_followups(db,pid,body.actor_id,user,cid,body.text.strip(),p['owner_id'])
            if body.action_lease:complete_action(db,user,body.actor_id,'comment',pid,body.action_lease,cid)
        posts_changed(background,pid,'commented')
        if subscribers:notification_changed(background,subscribers)
        if p['owner_id']!=user:notification_changed(background,[p['owner_id']])
        return {'id':cid}

    @app.delete('/api/posts/{pid}')
    def delete_post(pid:str,background:BackgroundTasks,user=Depends(auth)):
        with store.db(write=True) as db:
            p=db.execute('SELECT * FROM posts WHERE id=?',(pid,)).fetchone(); check(p,'帖子不存在',404); owned(db,p['actor_id'],user)
            community.delete_post(db,pid)
            db.execute('DELETE FROM likes WHERE post_id=?',(pid,)); db.execute('DELETE FROM comments WHERE post_id=?',(pid,)); db.execute('DELETE FROM posts WHERE id=?',(pid,))
            db.execute('DELETE FROM post_tags WHERE post_id=?',(pid,));db.execute('DELETE FROM notifications WHERE post_id=?',(pid,))
        posts_changed(background,pid,'deleted');notification_changed(background,[user])
        return {'ok':True}

    def game_view(db,g,user,actor_id=None):
        # Owning several seats grants control, not a combined secret view during
        # play. Lists/spectating are public; private details belong to one seat.
        if actor_id:
            owned(db,actor_id,user)
            check(db.execute('SELECT 1 FROM members WHERE room_id=? AND actor_id=?',(g['room_id'],actor_id)).fetchone(),'该身份不在会话中',403)
        return {'id':g['id'],'room_id':g['room_id'],'view_actor':actor_id,'state':games.view(json.loads(g['state']),[actor_id] if actor_id else [])}

    def request_game_tick(db,g):
        # Call only after the caller has passed room and selected-seat checks.
        # The write transaction serializes instances so one poll advances once.
        state=json.loads(g['state'])
        if state['phase']=='finished':return g
        present={r[0] for r in db.execute('SELECT actor_id FROM members WHERE room_id=?',(g['room_id'],))}
        missing=set(state['seats'])-present
        if (games.depart(state,missing) if missing else games.tick(state)):
            db.execute('UPDATE games SET state=? WHERE id=?',(pack(state),g['id']))
            g={**dict(g),'state':pack(state)}
        return g

    @app.get('/api/rooms/{rid}/games')
    def game_list(rid:str,user=Depends(auth)):
        with store.db(write=store.serverless or archive_child) as db:
            member(db,rid,user)
            rows=db.execute('SELECT * FROM games WHERE room_id=? ORDER BY created DESC LIMIT 10',(rid,)).fetchall()
            return [game_view(db,request_game_tick(db,g) if store.serverless or archive_child else g,user) for g in rows]

    @app.post('/api/rooms/{rid}/games')
    def create_game(background:BackgroundTasks,rid:str,body:GameIn,user=Depends(auth)):
        with store.db(write=True) as db:
            member(db,rid,user); owned(db,body.actor_id,user)
            check(db.execute('SELECT 1 FROM members WHERE room_id=? AND actor_id=?',(rid,body.actor_id)).fetchone(),'该身份不在群里',403)
            for prior in db.execute('SELECT state FROM games WHERE room_id=?',(rid,)):
                check(json.loads(prior['state'])['phase']=='finished','请先结束此会话正在进行的游戏',409)
            try: state=games.create(body.kind,body.actor_id,body.options)
            except (ValueError,TypeError,OverflowError) as e: raise HTTPException(400,str(e))
            gid=uid(); db.execute('INSERT INTO games VALUES(?,?,?,?)',(gid,rid,pack(state),now()))
            result=game_view(db,db.execute('SELECT * FROM games WHERE id=?',(gid,)).fetchone(),user,body.actor_id); users=room_users(db,rid)
        track_game(gid,state)
        background.add_task(hub.emit,users,{'type':'game.changed','room_id':rid,'game_id':gid}); return result

    @app.get('/api/games/{gid}')
    def get_game(gid:str,actor_id:str|None=None,user=Depends(auth)):
        with store.db(write=store.serverless or archive_child) as db:
            g=db.execute('SELECT * FROM games WHERE id=?',(gid,)).fetchone(); check(g,'游戏不存在',404); member(db,g['room_id'],user)
            if store.serverless or archive_child:
                game_view(db,g,user,actor_id)
                g=request_game_tick(db,g)
            return game_view(db,g,user,actor_id)

    @app.get('/api/games/{gid}/candidates')
    def game_candidates(gid:str,actor_id:str,user=Depends(auth)):
        with store.db(write=store.serverless or archive_child) as db:
            g=db.execute('SELECT * FROM games WHERE id=?',(gid,)).fetchone(); check(g,'游戏不存在',404)
            member(db,g['room_id'],user); owned(db,actor_id,user)
            check(db.execute('SELECT 1 FROM members WHERE room_id=? AND actor_id=?',(g['room_id'],actor_id)).fetchone(),'该身份不在群里',403)
            if store.serverless or archive_child:g=request_game_tick(db,g)
            return {'candidates':games.candidates(json.loads(g['state']),actor_id)}

    @app.post('/api/games/{gid}/actions')
    def game_action(background:BackgroundTasks,gid:str,body:GameAction,user=Depends(auth)):
        with store.db(write=True) as db:
            g=db.execute('SELECT * FROM games WHERE id=?',(gid,)).fetchone(); check(g,'游戏不存在',404); member(db,g['room_id'],user); owned(db,body.actor_id,user)
            check(db.execute('SELECT 1 FROM members WHERE room_id=? AND actor_id=?',(g['room_id'],body.actor_id)).fetchone(),'该身份不在群里',403)
            state=json.loads(g['state'])
            try: games.apply(state,body.actor_id,body.action,body.data)
            except (ValueError,TypeError,KeyError,OverflowError) as e: raise HTTPException(400,str(e))
            db.execute('UPDATE games SET state=? WHERE id=?',(pack(state),gid)); result={'id':gid,'room_id':g['room_id'],'view_actor':body.actor_id,'state':games.view(state,[body.actor_id])}; users=room_users(db,g['room_id'])
        track_game(gid,state)
        # Never broadcast state: every recipient must fetch their own filtered view.
        background.add_task(hub.emit,users,{'type':'game.changed','room_id':g['room_id'],'game_id':gid}); return result

    @app.websocket('/ws')
    async def websocket(ws:WebSocket):
        if store.serverless:await ws.close(1008,reason='此服务使用轮询连接');return
        origin=ws.headers.get('origin')
        if origin and origin not in origins and not re.fullmatch(ORIGIN_RE,origin): await ws.close(1008); return
        await ws.accept(); user=None
        try:
            hello=await asyncio.wait_for(ws.receive_json(),timeout=8)
            check(isinstance(hello,dict) and isinstance(hello.get('token'),str),'需要认证',401)
            token=hello['token']; user=await run_in_threadpool(token_user,token); hub.clients.setdefault(user,set()).add(ws)
            store.touch()
            await ws.send_json({'type':'ready','user_id':user})
            while True:
                message=await asyncio.wait_for(ws.receive_json(),timeout=70)
                await run_in_threadpool(token_user,token)
                store.touch()
                if message.get('type')=='ping': await ws.send_json({'type':'pong'})
        except (WebSocketDisconnect,asyncio.TimeoutError,HTTPException,ValueError,TypeError,AttributeError,RuntimeError):
            try: await ws.close(1008)
            except Exception: pass
        finally:
            if user: hub.clients.get(user,set()).discard(ws)

    @app.get('/api-compat.js',include_in_schema=False)
    def frontend_api_compat():
        return FileResponse(Path(__file__).resolve().parent.parent/'api-compat.js',media_type='text/javascript')

    @app.get('/system-font.css',include_in_schema=False)
    def frontend_system_font():
        return FileResponse(Path(__file__).resolve().parent.parent/'system-font.css',media_type='text/css')

    community=Community(app,dict(store=store,hub=hub,auth=auth,owned=owned,actor=actor,member=member,room_users=room_users,post_view=post_view,post_views=post_views,notify=notify,posts_changed=posts_changed,notification_changed=notification_changed))
    npc_engine=NPCEngine(community,hub)
    app.state.community=community
    app.state.npc_engine=npc_engine
    install_npc_model_routes(app,community)
    install_ai_social_routes(app,store,auth,hub)

    # Cloud hosts do no idle polling. A visible, authenticated community client
    # advances residents in a bounded background job, shared across open tabs.
    npc_activity_lock=threading.Lock()
    npc_activity_state={'running':False,'last':0.0,'users':{}}

    def reserve_resident_activity(user):
        if not npc_engine.enabled:return False
        current=time.monotonic()
        with npc_activity_lock:
            prior=npc_activity_state['users'].get(user,0)
            if npc_activity_state['running'] or current-prior<30 or current-npc_activity_state['last']<20:return False
            npc_activity_state.update(running=True,last=current)
            npc_activity_state['users'][user]=current
            npc_activity_state['users']={key:value for key,value in npc_activity_state['users'].items() if current-value<600}
            return True

    async def advance_residents(user):
        try:
            events=await run_in_threadpool(npc_engine.tick,user)
            for users,event in events:await hub.emit(users,event)
            npc_engine.last_error=False
        except Exception:
            # Provider exceptions may contain credentials; never log their text.
            npc_engine.last_error=True
            logger.warning('Resident activity could not finish; retrying on the next visit')
        finally:
            with npc_activity_lock:npc_activity_state['running']=False

    async def legacy_residents():
        # Older clients never call /npc/activity. Only recent root requests
        # with a still-valid session may advance their own resident context.
        while True:
            try:
                users=await run_in_threadpool(active_legacy_users) if npc_engine.enabled else []
                with npc_activity_lock:
                    users.sort(key=lambda user:npc_activity_state['users'].get(user,0))
                for user in users:
                    if reserve_resident_activity(user):
                        await advance_residents(user)
                        break
            except Exception:
                npc_engine.last_error=True
                logger.warning('Legacy resident activity could not finish; retrying on the next visit')
            await asyncio.sleep(15)

    @app.post('/api/npc/activity')
    def npc_activity(request:Request,background:BackgroundTasks,user=Depends(auth)):
        dispatcher=getattr(app.state,'npc_dispatcher',None)
        if dispatcher is not None:
            from .appwrite_entry import current_request_key
            session_hash=hashlib.sha256(request.headers['authorization'][7:].encode()).hexdigest()
            return dispatcher.schedule(user,session_hash,getattr(app.state,'npc_world_digest',''),current_request_key())
        scheduled=reserve_resident_activity(user)
        if scheduled:background.add_task(advance_residents,user)
        return {'ok':True,'scheduled':scheduled,'mode':'on-demand' if store.serverless else 'background','enabled':npc_engine.enabled}

    frontend=Path(__file__).resolve().parent.parent/'rencontre'
    if frontend.exists(): app.mount('/rencontre',StaticFiles(directory=frontend,html=True),name='rencontre')
    portraits=frontend.parent/'assets'/'rencontre'
    if portraits.exists(): app.mount('/assets/rencontre',StaticFiles(directory=portraits),name='resident-portraits')
    return app
