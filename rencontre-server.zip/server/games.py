"""Authoritative table games. State is JSON; views hide other seats' secrets.
No client-provided deck, roles, points, phase or winner is ever accepted.
"""
from collections import Counter
from copy import deepcopy
import secrets
import time

RNG = secrets.SystemRandom()
LIMITS = {'mahjong':(4,4),'landlord':(3,3),'draw':(2,8),'werewolf':(6,10),'turtle':(2,10)}
WORDS = ['雨伞','猫咪','自行车','月亮','蛋糕','机器人','热气球','冰淇淋','大熊猫','向日葵','火车','长颈鹿']
# Seconds per decision. Drawing keeps its configured 30..180 second round.
# Missing clocks in saved games receive a full new window on their first tick.
TIMEOUTS = {'mahjong':60, 'responding':20, 'bidding':60, 'landlord':60,
            'night':90, 'voting':120}


def require(ok, message):
    if not ok: raise ValueError(message)


def create(kind, host, options=None):
    require(kind in LIMITS, '未知游戏')
    options = options or {}
    s = dict(kind=kind, host=host, seats=[host], phase='lobby', log=[], revision=0)
    if kind == 'turtle':
        s.update(surface=str(options.get('surface',''))[:1000].strip(), secret=str(options.get('secret',''))[:2000].strip(), questions=[], guesses=[])
        require(s['surface'] and s['secret'], '请同时填写汤面和私密汤底')
    if kind == 'draw': s.update(rounds=max(1,min(10,int(options.get('rounds',3)))), seconds=max(30,min(180,int(options.get('seconds',60)))))
    return s


def log(s, text): s['log'] = (s['log'] + [text])[-80:]


def next_seat(s, p): return s['seats'][(s['seats'].index(p)+1)%len(s['seats'])]


def finish(s, winner):
    s['phase']='finished'; s['winner']=winner
    s.pop('deadline',None); s.pop('response_deadline',None)
    log(s,'游戏结束：'+str(winner))


def _clock(s):
    """Return (clock field, duration), or None for an untimed phase."""
    k=s['kind']; phase=s['phase']
    if k=='mahjong' and phase=='responding': return 'response_deadline', TIMEOUTS['responding']
    if k=='mahjong' and phase=='playing': return 'deadline', TIMEOUTS['mahjong']
    if k=='landlord' and phase in ('bidding','playing'):
        return 'deadline', TIMEOUTS['bidding' if phase=='bidding' else 'landlord']
    if k=='werewolf' and phase in ('night','voting'): return 'deadline', TIMEOUTS[phase]
    if k=='draw' and phase=='drawing': return 'deadline', s['seconds']
    return None


def _arm(s, now=None, reset=False):
    clock=_clock(s)
    if not clock: return False
    field,seconds=clock
    if reset or field not in s:
        s[field]=(time.time() if now is None else now)+seconds
        return True
    return False


def tick(s, now=None):
    """Advance one expired decision in-place; return whether it needs saving.

    Safe to call periodically without a player action. A delayed server never
    burns through multiple turns: each next player gets a fresh full window.
    This has no AI/model side effects and never makes a strategic target choice.
    """
    now=time.time() if now is None else now
    clock=_clock(s)
    if not clock: return False
    if _arm(s,now):
        s['revision']+=1
        return True
    if now<s[clock[0]]: return False
    k=s['kind']; phase=s['phase']
    if k=='mahjong':
        if phase=='responding':
            log(s,'响应超时，未响应座位自动过牌')
            for p in s['response_options']: s['responses'].setdefault(p,{'action':'pass'})
            mahjong_resolve(s,now)
        else:
            p=s['turn']; log(s,p+' 出牌超时，自动打出最小牌')
            act_mahjong(s,p,'discard',{'tile':min(s['hands'][p])},now)
    elif k=='landlord':
        p=s['turn']
        if phase=='bidding':
            log(s,p+' 叫分超时，自动不叫')
            # If everybody is absent, do not redeal indefinitely. A real bid
            # still wins normally; deliberately declining seats may redeal.
            timed_out=s.setdefault('timed_out_bids',[])
            if p not in timed_out: timed_out.append(p)
            if len(timed_out)==len(s['seats']) and not any(s['bids'].values()):
                finish(s,'全员叫分超时，本局结束')
            else: act_landlord(s,p,'bid',{'bid':0},now)
        elif s['last'] and s['last']['actor']!=p:
            log(s,p+' 出牌超时，自动过牌'); act_landlord(s,p,'pass',{},now)
        else:
            log(s,p+' 出牌超时，自动领出最小单牌')
            act_landlord(s,p,'play',{'cards':[min(s['hands'][p])]},now)
    elif k=='draw':
        log(s,'绘画超时，本轮答案：'+s['word']); draw_round(s,now)
    elif k=='werewolf':
        actions=s['night_actions'] if phase=='night' else s['votes']
        s['idle_phases']=s.get('idle_phases',0)+1 if not actions else 0
        if s['idle_phases']>=2:
            finish(s,'连续两个阶段全员超时，本局结束')
        elif phase=='night':
            log(s,'夜晚行动超时，未行动座位跳过本夜')
            for p in s['alive']:
                if s['roles'][p] in ('wolf','seer','guard'): actions.setdefault(p,None)
            resolve_night(s,now)
        else:
            log(s,'投票超时，未投票座位自动弃票')
            for p in s['alive']: actions.setdefault(p,'')
            resolve_votes(s,now)
    _arm(s,now,reset=True)
    s['revision']+=1
    return True


def depart(s, actor_ids, reason='成员已离开群聊'):
    """Remove lobby seats, or close an interrupted round with a visible reason.

    Active round seats remain as history; `departed` records that they no longer
    participate. Finishing avoids changing private hands/roles or inventing a
    replacement player. Both human and owner-created AI seats use this policy.
    """
    if s['phase']=='finished': return False
    leaving=set(actor_ids)
    departed=[p for p in s['seats'] if p in leaving]
    if not departed: return False
    s['departed']=list(dict.fromkeys(s.get('departed',[])+departed))
    log(s,'、'.join(departed)+'：'+reason)
    if s['phase']=='lobby':
        s['seats']=[p for p in s['seats'] if p not in leaving]
        if not s['seats']: finish(s,'全部座位已离开，本局取消')
        elif s['host'] in leaving:
            s['host']=s['seats'][0]; log(s,'房主已转交：'+s['host'])
    else: finish(s,'成员离开，本局中止')
    s['revision']+=1
    return True


def mahjong_win(hand, open_melds=0):
    if len(hand)!=14-3*open_melds: return False
    counts=Counter(hand)
    if not open_melds and len(counts)==7 and all(n==2 for n in counts.values()): return True
    def melds(c):
        if not c: return True
        t=min(c)
        if c[t]>=3:
            n=c.copy(); n[t]-=3
            if not n[t]: del n[t]
            if melds(n): return True
        if t<27 and t%9<=6 and c.get(t+1,0) and c.get(t+2,0):
            n=c.copy()
            for v in (t,t+1,t+2):
                n[v]-=1
                if not n[v]: del n[v]
            if melds(n): return True
        return False
    for tile,n in counts.items():
        if n>=2:
            c=counts.copy(); c[tile]-=2
            if not c[tile]: del c[tile]
            if melds(c): return True
    return False


def card_pattern(cards):
    """Return (shape, rank, size); ranks 3..15, jokers 16/17."""
    require(cards and len(set(cards))==len(cards) and all(isinstance(c,int) and 0<=c<54 for c in cards),'无效牌组')
    ranks=sorted(3+c//4 if c<52 else c-36 for c in cards)
    c=Counter(ranks); n=len(cards); keys=sorted(c); values=sorted(c.values())
    if keys==[16,17]: return ('rocket',17,2)
    if len(c)==1:
        return ({1:'single',2:'pair',3:'triple',4:'bomb'}[n],keys[0],n)
    triples=[k for k,v in c.items() if v==3]
    fours=[k for k,v in c.items() if v==4]
    if n in (4,5) and values in ([1,3],[2,3]): return ('triple'+str(n),triples[0],n)
    if max(keys)<15 and keys==list(range(min(keys),max(keys)+1)):
        if all(v==1 for v in c.values()) and n>=5: return ('straight',max(keys),n)
        if all(v==2 for v in c.values()) and len(c)>=3: return ('pairs',max(keys),n)
    # Airplanes use consecutive triple cores, excluding rank 2 / jokers.
    possible=sorted(k for k,v in c.items() if v>=3 and k<15)
    for start in possible:
        core=[]
        for rank in range(start,15):
            if rank not in possible: break
            core.append(rank); m=len(core)
            if m<2: continue
            rest=c.copy()
            for rank2 in core: rest[rank2]-=3
            left=[v for v in rest.values() if v]
            if n==m*3: return ('plane',max(core),n)
            if n==m*4 and sum(left)==m and all(rest[r]==0 for r in core): return ('plane_single',max(core),n)
            if n==m*5 and len(left)==m and all(v==2 for v in left): return ('plane_pair',max(core),n)
    if fours and n==6: return ('four_single',fours[0],n)
    if fours and n==8 and values==[2,2,4]: return ('four_pair',fours[0],n)
    raise ValueError('不支持的牌型：可出单、对、三带、顺子、连对、飞机、四带二、炸弹和王炸')


def beats(new, old):
    if not old: return True
    if new[0]=='rocket': return old[0]!='rocket'
    if old[0]=='rocket': return False
    if new[0]=='bomb' and old[0]!='bomb': return True
    return new[0]==old[0] and new[2]==old[2] and new[1]>old[1]


def deal_landlord(s):
    deck=list(range(54)); RNG.shuffle(deck)
    s.update(hands={p:sorted(deck[i*17:(i+1)*17]) for i,p in enumerate(s['seats'])}, bottom=deck[51:], bids={}, turn=s['seats'][0], phase='bidding', last=None, passes=0,timed_out_bids=[])


def start(s,now=None):
    k=s['kind']; seats=s['seats']
    low,high=LIMITS[k]; require(low<=len(seats)<=high,f'需要 {low} 至 {high} 个座位')
    if k=='mahjong':
        deck=[t for t in range(34) for _ in range(4)]; RNG.shuffle(deck)
        hands={p:sorted(deck[i*13:(i+1)*13]) for i,p in enumerate(seats)}
        deck=deck[len(seats)*13:]; hands[seats[0]].append(deck.pop())
        s.update(phase='playing',deck=deck,hands=hands,discards=[],turn=seats[0],melds={p:[] for p in seats})
    elif k=='landlord': deal_landlord(s)
    elif k=='draw':
        s.update(scores={p:0 for p in seats},round=0,used_words=[]); draw_round(s,now)
    elif k=='werewolf':
        wolves=2 if len(seats)<9 else 3
        roles=['wolf']*wolves+['seer','guard']+['villager']*(len(seats)-wolves-2); RNG.shuffle(roles)
        s.update(roles=dict(zip(seats,roles)),alive=list(seats),day=1,visions={},last_guard=None)
        night(s,now)
    else: s['phase']='questions'
    log(s,'游戏已开始')
    _arm(s,now,reset=True)


def draw_round(s,now=None):
    s['round']+=1
    if s['round']>s['rounds']*len(s['seats']):
        highest=max(s['scores'].values())
        winners=[p for p,score in s['scores'].items() if score==highest]
        return finish(s,winners[0] if len(winners)==1 else '平局')
    available=[w for w in WORDS if w not in s['used_words']] or WORDS
    word=RNG.choice(available); s['used_words'].append(word)
    s.update(phase='drawing',drawer=s['seats'][(s['round']-1)%len(s['seats'])],word=word,guessed=[],strokes=[],deadline=(time.time() if now is None else now)+s['seconds'])
    log(s,'新一轮画图')


def night(s,now=None):
    s.update(phase='night',night_actions={},votes={}); _arm(s,now,reset=True)


def wolf_win(s):
    wolves=sum(s['roles'][p]=='wolf' for p in s['alive'])
    if not wolves: finish(s,'村民阵营'); return True
    if wolves>=len(s['alive'])-wolves: finish(s,'狼人阵营'); return True
    return False


def resolve_night(s,now=None):
    needed=[p for p in s['alive'] if s['roles'][p] in ('wolf','seer','guard')]
    if any(p not in s['night_actions'] for p in needed): return
    actions=s['night_actions']; wolf_targets=[actions[p] for p in needed if s['roles'][p]=='wolf' and actions[p] is not None]
    victim=sorted(Counter(wolf_targets),key=lambda p:(-wolf_targets.count(p),p))[0] if wolf_targets else None
    guard=next((actions[p] for p in needed if s['roles'][p]=='guard'),None)
    s['last_guard']=guard
    if victim and victim!=guard:
        s['alive'].remove(victim); log(s,victim+' 在夜晚出局')
    else: log(s,'昨夜平安')
    if not wolf_win(s):
        s.update(phase='voting',votes={}); _arm(s,now,reset=True)


def resolve_votes(s,now=None):
    if len(s['votes'])!=len(s['alive']): return
    counts=Counter(t for t in s['votes'].values() if t)
    top=max(counts.values(),default=0); picked=[t for t,n in counts.items() if n==top]
    if len(picked)==1: s['alive'].remove(picked[0]); log(s,picked[0]+' 被投票出局')
    else: log(s,'平票或全部弃票，无人出局')
    if not wolf_win(s): s['day']+=1; night(s,now)


def apply(s,p,action,data=None,now=None):
    now=time.time() if now is None else now
    data=data or {}; require(isinstance(data,dict),'动作数据必须是对象')
    if action=='join':
        require(s['phase']=='lobby','已开始，不能入座')
        require(p not in s['seats'],'已经入座')
        require(len(s['seats'])<LIMITS[s['kind']][1],'座位已满'); s['seats'].append(p)
        if p in s.get('departed',[]): s['departed'].remove(p)
    elif action=='leave':
        require(s['phase']=='lobby' and p!=s['host'],'只能在等待时离开，房主可取消游戏')
        require(p in s['seats'],'尚未入座'); s['seats'].remove(p)
    elif action=='cancel':
        require(p==s['host'],'只有房主能取消'); require(s['phase']!='finished','游戏已经结束'); finish(s,'房主取消')
    else:
        require(p in s['seats'],'请先入座')
        if action=='start':
            require(p==s['host'] and s['phase']=='lobby','只有等待中的房主能开始'); start(s,now)
        else:
            require(s['phase'] not in ('lobby','finished'),'游戏尚未开始或已经结束')
            # Late submissions first observe the authoritative timeout, just
            # as the old draw/mahjong actions did. Legacy clocks get grace.
            _arm(s,now)
            if tick(s,now): return s
            if action=='tick': return s
            globals()['act_'+s['kind']](s,p,action,data,now)
            if (s['kind'] in ('mahjong','landlord') and s['phase']=='playing') or (s['kind']=='landlord' and s['phase']=='bidding'):
                _arm(s,now,reset=True)
    s['revision']+=1
    return s


def mahjong_draw(s,p,replacement=False,now=None):
    if not s['deck']: finish(s,'流局'); return
    s.update(phase='playing',turn=p)
    # Kong replacement draws from the back of the wall.
    tile=s['deck'].pop(0 if replacement else -1)
    s['hands'][p].append(tile); s['hands'][p].sort()
    _arm(s,now,reset=True)


def mahjong_options(s,source,tile,rob=False):
    result={}
    for p in s['seats']:
        if p==source: continue
        hand=s['hands'][p]; options={}
        if mahjong_win(hand+[tile],len(s['melds'][p])): options['win']=True
        if not rob:
            if hand.count(tile)>=2: options['pong']=True
            if hand.count(tile)>=3 and s['deck']: options['kong']=True
            if p==next_seat(s,source) and tile<27:
                pairs=[]
                for first in (tile-2,tile-1,tile):
                    if first<0 or first//9!=tile//9 or first%9>6: continue
                    pair=[v for v in range(first,first+3) if v!=tile]
                    if all(v in hand for v in pair): pairs.append(pair)
                if pairs: options['chow']=pairs
        if options: result[p]=options
    return result


def mahjong_pending(s,source,tile,rob=False,index=None,now=None):
    options=mahjong_options(s,source,tile,rob)
    if not options: return False
    s.update(phase='responding',pending={'actor':source,'tile':tile,'kind':'add_kong' if rob else 'discard','meld_index':index},response_options=options,responses={})
    s.pop('deadline',None); _arm(s,now,reset=True)
    return True


def mahjong_resolve(s,now=None):
    if any(p not in s['responses'] for p in s['response_options']): return
    pending=s['pending']; source=pending['actor']; tile=pending['tile']
    priority={'win':3,'kong':2,'pong':2,'chow':1,'pass':0}
    order=s['seats'][s['seats'].index(source)+1:]+s['seats'][:s['seats'].index(source)]
    claimed=sorted((p for p,r in s['responses'].items() if r['action']!='pass'),key=lambda p:(-priority[s['responses'][p]['action']],order.index(p)))
    response=s['responses'][claimed[0]] if claimed else None; target=claimed[0] if claimed else None
    for key in ('pending','response_options','responses','response_deadline'): s.pop(key,None)
    if not target:
        if pending['kind']=='add_kong':
            meld=s['melds'][source][pending['meld_index']]; meld['type']='kong'; meld['tiles'].append(tile)
            log(s,source+' 补杠'); mahjong_draw(s,source,True,now)
        else: mahjong_draw(s,next_seat(s,source),now=now)
        return
    action=response['action']
    if action=='win':
        s['hands'][target].append(tile); s['hands'][target].sort()
        if pending['kind']=='discard': s['discards'][-1]['claimed_by']=target
        s['win_type']='抢杠胡' if pending['kind']=='add_kong' else '点炮胡'; s['discarder']=source
        log(s,target+' '+s['win_type']); finish(s,target); return
    require(pending['kind']=='discard','补杠时只能抢胡')
    s['discards'][-1]['claimed_by']=target
    used=response['tiles'] if action=='chow' else [tile]*(3 if action=='kong' else 2)
    for t in used: s['hands'][target].remove(t)
    s['melds'][target].append({'type':action,'tiles':sorted(used+[tile]),'from':source,'concealed':False})
    s.update(phase='playing',turn=target); log(s,target+' '+{'chow':'吃','pong':'碰','kong':'明杠'}[action])
    if action=='kong': mahjong_draw(s,target,True,now)
    _arm(s,now,reset=True)


def act_mahjong(s,p,a,d,now=None):
    if s['phase']=='responding':
        require(p in s['response_options'],'没有可响应的吃碰杠胡，请等待')
        require(p not in s['responses'],'已提交响应，请等待其他玩家')
        opts=s['response_options'][p]
        require(a=='pass' or a in opts,'该响应不可用')
        response={'action':a}
        if a=='chow':
            pair=d.get('tiles'); require(isinstance(pair,list) and sorted(pair) in opts['chow'],'吃牌组合无效')
            response['tiles']=sorted(pair)
        s['responses'][p]=response; mahjong_resolve(s,now); return
    require(p==s['turn'],'还没轮到你')
    hand=s['hands'][p]; open_count=len(s['melds'][p])
    require(len(hand)==14-3*open_count,'吃碰后需先打出一张牌')
    if a=='win':
        require(mahjong_win(hand,open_count),'当前手牌尚未和牌'); s['win_type']='自摸'; finish(s,p)
    elif a=='discard':
        tile=d.get('tile'); require(type(tile)==int and tile in hand,'没有这张牌')
        hand.remove(tile); s['discards'].append({'actor':p,'tile':tile})
        if not mahjong_pending(s,p,tile,now=now): mahjong_draw(s,next_seat(s,p),now=now)
    elif a=='kong':
        tile=d.get('tile'); require(type(tile)==int and tile in hand,'没有这张牌'); require(s['deck'],'牌墙已空，不能杠')
        if hand.count(tile)==4:
            for _ in range(4): hand.remove(tile)
            s['melds'][p].append({'type':'kong','tiles':[tile]*4,'from':p,'concealed':True}); log(s,p+' 暗杠'); mahjong_draw(s,p,True,now)
        else:
            index=next((i for i,m in enumerate(s['melds'][p]) if m['type']=='pong' and m['tiles'][0]==tile),None)
            require(index is not None,'需要四张同牌或已碰牌的一张补牌')
            hand.remove(tile)
            if not mahjong_pending(s,p,tile,True,index,now):
                s['melds'][p][index]['type']='kong'; s['melds'][p][index]['tiles'].append(tile); log(s,p+' 补杠'); mahjong_draw(s,p,True,now)
    else: raise ValueError('请选择打牌、杠或胡；弃牌后有 20 秒吃碰杠胡响应窗口')


def act_landlord(s,p,a,d,now=None):
    require(p==s['turn'],'还没轮到你')
    if s['phase']=='bidding':
        require(a=='bid','请先叫地主'); bid=d.get('bid')
        require(type(bid)==int and bid in (0,1,2,3),'叫分为 0..3')
        require(bid==0 or bid>max(s['bids'].values(),default=0),'叫分必须高于上一位')
        s['bids'][p]=bid
        if bid==3 or len(s['bids'])==3:
            if not max(s['bids'].values()): deal_landlord(s); log(s,'无人叫地主，重新发牌'); return
            lord=max(s['bids'],key=s['bids'].get); s['landlord']=lord
            s['hands'][lord]=sorted(s['hands'][lord]+s['bottom']); s.update(phase='playing',turn=lord)
        else: s['turn']=next_seat(s,p)
        return
    if a=='pass':
        require(s['last'] and s['last']['actor']!=p,'领出时不能过牌')
        s['passes']+=1
        if s['passes']==2: s['turn']=s['last']['actor']; s['last']=None; s['passes']=0
        else: s['turn']=next_seat(s,p)
        return
    require(a=='play','动作应为 play 或 pass')
    cards=d.get('cards',[]); require(isinstance(cards,list),'牌组必须为数组')
    require(all(c in s['hands'][p] for c in cards),'手牌不存在')
    pattern=card_pattern(cards); old=s['last']['pattern'] if s['last'] else None
    require(beats(pattern,old),'牌型不匹配或没有大过上家')
    for c in cards: s['hands'][p].remove(c)
    s.update(last={'actor':p,'cards':cards,'pattern':pattern},passes=0,turn=next_seat(s,p))
    if not s['hands'][p]: finish(s,'地主 '+p if p==s['landlord'] else '农民阵营')


def act_draw(s,p,a,d,now=None):
    if a=='stroke':
        require(p==s['drawer'],'只有画者可画')
        points=d.get('points'); color=str(d.get('color','#222222')); width=d.get('width',3)
        require(isinstance(points,list) and 1<=len(points)<=200,'一次笔画最多 200 个点')
        require(len(s['strokes'])<500,'画布笔画已达上限，请清空')
        require(len(color)==7 and color[0]=='#' and all(c in '0123456789abcdefABCDEF' for c in color[1:]),'无效颜色')
        require(type(width) in (int,float) and 1<=width<=30,'画笔宽度无效')
        require(all(isinstance(pt,list) and len(pt)==2 and all(type(v) in (int,float) and 0<=v<=1 for v in pt) for pt in points),'坐标需归一化为 0..1')
        s['strokes'].append({'points':points,'color':color,'width':width})
    elif a=='clear': require(p==s['drawer'],'只有画者能清空'); s['strokes']=[]
    elif a=='skip':
        require(p==s['drawer'],'只有画者可跳过'); log(s,'本轮答案：'+s['word']); draw_round(s,now)
    elif a=='guess':
        require(p!=s['drawer'] and p not in s['guessed'],'画者或已猜中者不能猜')
        guess=str(d.get('text','')).strip()[:80]; require(guess,'请填写答案')
        if guess==s['word']:
            s['guessed'].append(p); s['scores'][p]+=10; s['scores'][s['drawer']]+=3; log(s,p+' 猜中了')
            if len(s['guessed'])==len(s['seats'])-1: log(s,'本轮答案：'+s['word']); draw_round(s,now)
        else: log(s,p+' 猜：'+guess)
    else: raise ValueError('未知画图动作')


def act_werewolf(s,p,a,d,now=None):
    require(p in s['alive'],'出局角色只能旁观')
    target=d.get('target')
    if s['phase']=='night':
        require(a=='night','当前为夜晚'); role=s['roles'][p]
        require(role in ('wolf','seer','guard'),'村民夜晚等待')
        require(p not in s['night_actions'],'本夜已经行动')
        require(target in s['alive'],'请选择仍存活的目标')
        if role=='wolf': require(s['roles'][target]!='wolf','狼人不能袭击狼队友')
        if role=='guard': require(target!=s['last_guard'],'守卫不能连续两夜守同一人')
        s['night_actions'][p]=target
        s['idle_phases']=0
        if role=='seer': s['visions'].setdefault(p,[]).append({'day':s['day'],'actor':target,'wolf':s['roles'][target]=='wolf'})
        resolve_night(s,now)
    else:
        require(a=='vote' and s['phase']=='voting','当前不能投票')
        require(p not in s['votes'],'本轮已投票'); require(target in s['alive'] or target=='','目标无效')
        s['votes'][p]=target
        s['idle_phases']=0
        resolve_votes(s,now)


def act_turtle(s,p,a,d,now=None):
    if a in ('question','guess'):
        require(p!=s['host'],'主持人负责回答')
        text=str(d.get('text','')).strip()[:300]; require(text,'内容不能为空')
        key='questions' if a=='question' else 'guesses'
        require(len(s[key])<200,'本局提问已达上限，请主持人揭晓')
        s[key].append({'actor':p,'text':text,'answer':None})
    elif a in ('answer','judge'):
        require(p==s['host'],'只有主持人能回答')
        key='questions' if a=='answer' else 'guesses'; i=d.get('index'); answer=d.get('answer')
        require(type(i)==int and 0<=i<len(s[key]),'问题不存在')
        require(s[key][i]['answer'] is None,'已经回答')
        require(answer in ('是','否','无关') if a=='answer' else type(answer)==bool,'回答无效')
        s[key][i]['answer']=answer
        if a=='judge' and answer: finish(s,s[key][i]['actor'])
    elif a=='reveal': require(p==s['host'],'只有主持人能揭晓'); finish(s,'汤底揭晓')
    else: raise ValueError('未知海龟汤动作')


def candidates(s,p):
    """Legal bounded choices for an owner's local AI; variable text/drawing is marked.
    These are suggestions, never a bypass around apply().
    """
    result=[]
    def add(action,data=None,flexible=False):
        item={'action':action,'data':data or {}}
        if flexible: item['flexible']=True
        if item not in result: result.append(item)
    if s['phase']=='finished': return result
    if s['phase']=='lobby':
        if p not in s['seats'] and len(s['seats'])<LIMITS[s['kind']][1]: add('join')
        elif p==s['host'] and len(s['seats'])>=LIMITS[s['kind']][0]: add('start')
        return result
    if p not in s['seats']: return result
    k=s['kind']
    if k=='mahjong':
        if s['phase']=='responding':
            opts=s['response_options'].get(p,{})
            if p in s['responses'] or not opts: return result
            for action in ('win','kong','pong'):
                if opts.get(action): add(action)
            for pair in opts.get('chow',[]): add('chow',{'tiles':pair})
            add('pass')
        elif s['turn']==p:
            hand=s['hands'][p]
            if mahjong_win(hand,len(s['melds'][p])): add('win')
            for tile in sorted(set(hand)):
                if s['deck'] and (hand.count(tile)==4 or any(m['type']=='pong' and m['tiles'][0]==tile for m in s['melds'][p])): add('kong',{'tile':tile})
                add('discard',{'tile':tile})
    elif k=='landlord' and s['turn']==p:
        if s['phase']=='bidding':
            for bid in range(4):
                if not bid or bid>max(s['bids'].values(),default=0): add('bid',{'bid':bid})
        else:
            hand=s['hands'][p]; rank_groups={}
            for c in hand: rank_groups.setdefault(3+c//4 if c<52 else c-36,[]).append(c)
            groups=[]
            for cards in rank_groups.values():
                for n in range(1,len(cards)+1): groups.append(cards[:n])
                if len(cards)>=3:
                    for other in rank_groups.values():
                        if other is cards: continue
                        groups.append(cards[:3]+other[:1])
                        if len(other)>=2: groups.append(cards[:3]+other[:2])
                if len(cards)==4:
                    other_cards=[c for c in hand if c not in cards]
                    if len(other_cards)>=2: groups.append(cards+other_cards[:2])
                    pairs=[g[:2] for g in rank_groups.values() if g is not cards and len(g)>=2]
                    if len(pairs)>=2: groups.append(cards+pairs[0]+pairs[1])
            if 52 in hand and 53 in hand: groups.append([52,53])
            for copies,minimum in ((1,5),(2,3),(3,2)):
                for first in range(3,15):
                    chain=[]
                    for rank in range(first,15):
                        group=rank_groups.get(rank,[])
                        if len(group)<copies: break
                        chain+=group[:copies]; length=rank-first+1
                        if length<minimum: continue
                        groups.append(chain.copy())
                        if copies==3:
                            extra=[c for c in hand if c not in chain]
                            if len(extra)>=length: groups.append(chain+extra[:length])
                            pairs=[g[:2] for r,g in rank_groups.items() if not first<=r<=rank and len(g)>=2]
                            if len(pairs)>=length: groups.append(chain+sum(pairs[:length],[]))
            for cards in groups:
                try: pattern=card_pattern(cards)
                except ValueError: continue
                if beats(pattern,s['last']['pattern'] if s['last'] else None): add('play',{'cards':sorted(cards)})
            if s['last'] and s['last']['actor']!=p: add('pass')
    elif k=='draw':
        if s['drawer']==p:
            add('stroke',{'points':[[0.1,0.1],[0.9,0.9]],'color':'#24574b','width':4},True)
            add('clear'); add('skip')
        elif p not in s['guessed']: add('guess',{'text':''},True)
    elif k=='werewolf' and p in s['alive']:
        role=s['roles'][p]
        if s['phase']=='night' and role in ('wolf','seer','guard') and p not in s['night_actions']:
            for target in s['alive']:
                if role=='wolf' and s['roles'][target]=='wolf': continue
                if role=='guard' and target==s['last_guard']: continue
                add('night',{'target':target})
        elif s['phase']=='voting' and p not in s['votes']:
            for target in s['alive']+['']: add('vote',{'target':target})
    elif k=='turtle':
        if p==s['host']:
            for key,action,answers in (('questions','answer',['是','否','无关']),('guesses','judge',[True,False])):
                for i,q in enumerate(s[key]):
                    if q['answer'] is None:
                        for answer in answers: add(action,{'index':i,'answer':answer})
        else:
            add('question',{'text':''},True); add('guess',{'text':''},True)
    return result[:160]


def view(state, controlled):
    s=deepcopy(state); k=s['kind']; owned=set(controlled)
    s.pop('deck',None); s.pop('used_words',None)
    if 'hands' in s:
        s['hand_counts']={p:len(h) for p,h in s['hands'].items()}
        s['hands']={p:h for p,h in s['hands'].items() if p in owned}
    if k=='mahjong':
        for p,melds in s.get('melds',{}).items():
            for meld in melds:
                if meld['concealed'] and p not in owned and s['phase']!='finished': meld['tiles']=[None]*4
        if 'response_options' in s:
            s['responded']=list(s['responses'])
            s['responses']={p:r for p,r in s['responses'].items() if p in owned}
            s['response_options']={p:r for p,r in s['response_options'].items() if p in owned}
    if k=='landlord' and s['phase'] in ('lobby','bidding'): s.pop('bottom',None)
    if k=='draw' and s.get('drawer') not in owned and s['phase']!='finished': s.pop('word',None)
    if k=='turtle' and s['host'] not in owned and s['phase']!='finished': s.pop('secret',None)
    if k=='werewolf' and s['phase'] not in ('lobby','finished'):
        roles=s.pop('roles'); s['roles']={p:r for p,r in roles.items() if p in owned}
        if any(roles.get(p)=='wolf' for p in owned): s['wolf_team']=[p for p,r in roles.items() if r=='wolf']
        s['visions']={p:v for p,v in s.get('visions',{}).items() if p in owned}
        s['acted']=list(s.get('night_actions',{})); s.pop('night_actions',None); s.pop('last_guard',None)
        s['voted']=list(s.get('votes',{})); s['votes']={p:t for p,t in s.get('votes',{}).items() if p in owned}
    s['rules']={
        'mahjong':'四人麻将：136 张牌，可吃、碰、明杠、暗杠、补杠、抢杠胡、点炮胡与自摸。每步 60 秒，出牌超时自动打最小牌；弃牌后有 20 秒响应窗，未响应自动过牌。胡优先于碰杠，碰杠优先于下家吃；同级近家优先。一家胡即结束，四面子一对将或闭门七对，无番数计分。成员离开时本局中止。',
        'landlord':'三人斗地主：依次叫分 0..3，最高分当地主；两人过牌后重新领出。叫分和出牌各 60 秒，超时自动不叫或过牌，领出时自动出最小单牌；全员叫分超时或成员离开时本局结束。支持单对、三带、顺子、连对、飞机、四带二、炸弹、王炸。',
        'draw':'轮流绘画，其他座位猜词，猜中得 10 分，画者加 3 分；超时或全员猜中换下一位。',
        'werewolf':'6–10 人：狼人、预言家、守卫、村民。夜晚 90 秒，超时未行动者跳过；白天投票 120 秒，超时未投票者弃票。全部行动完成可提前结算；平票不出局，狼数达到其他人数时狼胜。连续两个阶段全员超时或成员离开时本局中止。',
        'turtle':'主持人保管汤底；其他座位提问，主持回答是/否/无关，猜底由主持判定，也可主动揭晓。'
    }[k]
    return s
