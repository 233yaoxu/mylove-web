"""A resident's choices are durable, source-backed and local to its world store.

Models choose from legal actions; they never write relationship facts themselves.
All methods use the caller's transaction, including the public utterance.
"""
import hashlib
import json
from datetime import datetime, timedelta, timezone

from .community import pack, uid
from .npc_people import public_profile
from .npc_visibility import public_life_state
from .npc_intents import topic_history


def get_meta(db, key, default=None):
    row = db.execute('SELECT value FROM community_meta WHERE key=?', (key,)).fetchone()
    try:
        return json.loads(row[0]) if row else default
    except (ValueError, TypeError):
        return default


def put_meta(db, key, value):
    db.execute('INSERT INTO community_meta VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', (key, pack(value)))


def _strings(value):
    if isinstance(value, str):
        return [value] if value.strip() else []
    return [v for v in value if isinstance(v, str) and v.strip()] if isinstance(value, list) else []


class ResidentSociety:
    def state(self, db, actor, persona, now):
        key = 'npc-life:state:' + actor
        old = get_meta(db, key, {})
        if not isinstance(old, dict):
            old = {}
        day = datetime.fromtimestamp(now, timezone(timedelta(hours=8))).date().isoformat()
        if old.get('day') == day:
            return old
        goals = _strings(persona.get('goals')) or ['认识聊得来的邻居']
        seed = int(hashlib.sha256((actor + day).encode()).hexdigest()[:8], 16)
        state = {'day': day, 'goal': goals[seed % len(goals)],
                 'activity': str(persona.get('routine') or persona.get('occupation') or '安排自己的日常')[:240],
                 'expectation': str(persona.get('relationship_style') or '先交流，再决定要不要靠近')[:240],
                 'mood_event': old.get('mood_event', ''),
                 'recent_topics': topic_history(old, now), 'progress': 0}
        put_meta(db, key, state)
        return state

    def context(self, db, actor, persona, now, events=()):
        relations = [dict(r) for r in db.execute(
            'SELECT r.b_actor AS actor,a.name,r.type,r.intimacy,r.trust,r.romance,r.grudge '
            'FROM relationships r JOIN npcs n ON n.actor=r.b_actor JOIN actors a ON a.id=n.actor '
            'WHERE r.a_actor=? AND n.active=1 ORDER BY r.updated_at DESC LIMIT 8', (actor,))]
        # Private commitments affect decisions without exposing a player's identity.
        committed = bool(db.execute("SELECT 1 FROM couples WHERE status IN ('active','pending') AND (a_actor=? OR b_actor=?)", (actor, actor)).fetchone())
        state = self.state(db, actor, persona, now)
        return {'life': {**state, **public_life_state(state, events)}, 'relationships': relations, 'has_commitment': committed}

    @staticmethod
    def relation(db, actor, target):
        row = db.execute('SELECT * FROM relationships WHERE a_actor=? AND b_actor=?', (actor, target)).fetchone()
        return dict(row) if row else dict(type='认识', intimacy=0, trust=60, romance=0, grudge=0)

    @staticmethod
    def _compatible(a, b):
        wa, wb = a.get('worldview', {}), b.get('worldview', {})
        return bool(a.get('adult') and b.get('adult')
                    and wa.get('gender', {}).get('id') in wb.get('orientation', {}).get('attracted_genders', [])
                    and wb.get('gender', {}).get('id') in wa.get('orientation', {}).get('attracted_genders', []))

    @staticmethod
    def _pair(db, actor, target):
        return [dict(r) for r in db.execute('SELECT n.actor,n.persona_json,a.name FROM npcs n JOIN actors a ON a.id=n.actor '
                                           'WHERE n.actor IN (?,?) AND n.active=1', (actor, target))]

    def options(self, db, actor, target, now):
        choices = [dict(action='reply', meaning='就公开话题接话，不预设立场或关系', fallback=''),
                   dict(action='agree', meaning='表达赞同，熟悉度略有增加', fallback='这点我赞同，自己的安排还是提前说清楚比较好。'),
                   dict(action='disagree', meaning='表达分歧，保留不满，不造新事实', fallback='这点我不太同意。聊得来不代表每件事都得一样想。')]
        pair = self._pair(db, actor, target)
        if len(pair) != 2 or actor == target:
            return choices
        people = {r['actor']: json.loads(r['persona_json']) for r in pair}
        r, reverse = self.relation(db, actor, target), self.relation(db, target, actor)
        request = db.execute('SELECT * FROM friend_requests WHERE (source=? AND target=?) OR (source=? AND target=?) ORDER BY created DESC LIMIT 1',
                             (actor, target, target, actor)).fetchone()
        friends = db.execute('SELECT 1 FROM friendships WHERE a=? AND b=?', (actor, target)).fetchone()
        if request and request['target'] == actor and request['status'] == 'pending':
            if r['trust'] >= 45 and r['grudge'] < 40:
                choices.append(dict(action='accept_friend', meaning='同意对方的好友申请', fallback='申请看到了，通过了。以后想聊就直接找我。'))
            choices.append(dict(action='decline_friend', meaning='拒绝好友申请，不强迫和好', fallback='申请我先不通过了，暂时保持在社区聊就好。'))
        elif not request and not friends and r['intimacy'] >= 8 and r['trust'] >= 50 and r['grudge'] < 30:
            choices.append(dict(action='friend_request', meaning='提出好友申请，等对方决定', fallback='跟你聊过几次还挺投缘的，加个好友？申请发了，你自己决定就好。'))
        if r['grudge'] >= 10:
            choices.extend([
                dict(action='boundary', meaning='说明自己的边界和不满', fallback='这件事让我不舒服，我先说清楚，之后别这样跟我聊了。'),
                dict(action='apologize', meaning='只为自己的态度道歉，不替对方原谅', fallback='刚才我的语气也有问题，这个我道歉。你不用现在就说没事。')])
        if r['grudge'] >= 30:
            choices.append(dict(action='distance', meaning='选择疏远，矛盾可以继续存在', fallback='最近我们先少聊一点吧，我还没消化好这些分歧。'))
        couples = list(db.execute("SELECT * FROM couples WHERE status IN ('active','pending') AND (a_actor IN (?,?) OR b_actor IN (?,?))",
                                  (actor, target, actor, target)))
        pending = next((c for c in couples if c['a_actor'] == target and c['b_actor'] == actor and c['status'] == 'pending'), None)
        together = next((c for c in couples if {c['a_actor'], c['b_actor']} == {actor, target} and c['status'] == 'active'), None)
        compatible = self._compatible(people[actor], people[target])
        if pending:
            if (len(couples) == 1 and compatible and r['intimacy'] >= 40 and r['romance'] >= 30
                    and r['trust'] >= 65 and r['grudge'] < 20):
                choices.append(dict(action='accept_romance', meaning='明确同意此前的恋爱提议，双方成为恋人', fallback='我也想认真跟你在一起。不是试着玩玩，我们从今天开始好好谈吧。'))
            choices.append(dict(action='decline_romance', meaning='明确拒绝恋爱提议，保留个人意愿', fallback='我认真想过了，还是不能答应。谢谢你说清楚，我也不想吊着你。'))
        elif not couples and compatible and r['trust'] >= 60 and r['grudge'] < 20:
            history = db.execute('SELECT 1 FROM couples WHERE (a_actor=? AND b_actor=?) OR (a_actor=? AND b_actor=?)', (actor, target, target, actor)).fetchone()
            if not history and r['intimacy'] >= 18:
                choices.append(dict(action='flirt', meaning='只表达自己的好感，不能声称对方也喜欢', fallback='有点想多跟你聊一会儿。我好像开始期待你的消息了。'))
            if (not history and r['intimacy'] >= 40 and r['romance'] >= 28 and reverse['intimacy'] >= 25
                    and reverse['romance'] >= 12 and reverse['trust'] >= 65 and reverse['grudge'] < 20):
                choices.append(dict(action='propose_romance', meaning='认真提出恋爱，仍要等对方明确同意', fallback='我想认真问一次，你愿意跟我谈恋爱吗？不用急着回答，我等你想清楚。'))
        if together and (r['grudge'] >= 20 or r['trust'] < 45):
            choices.append(dict(action='breakup', meaning='结束当前双方的恋爱，不影响其他人的关系', fallback='我不想继续这段关系了。我们分开吧，这次不是气话。'))
        return choices

    def preferred(self, db, actor, target, choices, now):
        """Conservative offline decisions still allow actual social progression."""
        actions = {c['action']: i for i, c in enumerate(choices)}
        relation = self.relation(db, actor, target)
        for action in ('accept_friend', 'decline_friend', 'accept_romance', 'decline_romance', 'friend_request', 'propose_romance'):
            if action in actions:
                return actions[action]
        if relation['grudge'] >= 50 and 'breakup' in actions:
            return actions['breakup']
        seed = int(hashlib.sha256((actor + target + str(int(now // 86400))).encode()).hexdigest()[:8], 16)
        if 'flirt' in actions and seed % 3 == 0:
            return actions['flirt']
        return 0

    @staticmethod
    def source_exists(db, source):
        row = db.execute('SELECT p.actor_id,p.text,COALESCE(c.post_kind,\'daily\') AS kind FROM posts p '
                         'LEFT JOIN community_posts c ON c.post_id=p.id WHERE p.id=?', (source['post_id'],)).fetchone()
        if not row or row['kind'] == 'anon' or row['actor_id'] != source['post_actor'] or row['text'] != source['post_text']:
            return False
        if source['kind'] == 'comment':
            return bool(db.execute('SELECT 1 FROM comments WHERE id=? AND post_id=? AND actor_id=? AND text=?',
                                   (source['id'], source['post_id'], source['actor'], source['text'])).fetchone())
        return source['id'] == source['post_id']

    def valid(self, db, actor, source, action, now):
        if actor == source['actor'] or not self.source_exists(db, source):
            return False
        if not db.execute('SELECT 1 FROM npcs WHERE actor=? AND active=1', (actor,)).fetchone():
            return False
        target = db.execute('SELECT active FROM npcs WHERE actor=?', (source['actor'],)).fetchone()
        if target is not None and not target['active']:
            return False
        return any(c['action'] == action for c in self.options(db, actor, source['actor'], now))

    def commit(self, db, actor, source, action, output_id, now):
        if not self.valid(db, actor, source, action, now):
            return None
        token = hashlib.sha256(pack([actor, source['kind'], source['id']]).encode()).hexdigest()
        unique = 'social:' + token
        if db.execute('SELECT 1 FROM npc_public_events WHERE drama_id=? AND stage=0', (unique,)).fetchone():
            return None
        utterance = db.execute('SELECT text FROM comments WHERE id=? AND actor_id=? AND post_id=?', (output_id, actor, source['post_id'])).fetchone()
        if not utterance:
            return None
        target = source['actor']
        r = self.relation(db, actor, target)
        # Only the speaker's appraisal changes; a recipient never consents by being addressed.
        effects = {'reply': (2, 0, 0, 0), 'agree': (3, 1, 0, -1), 'disagree': (1, -3, 0, 6),
                   'boundary': (0, -4, 0, 8), 'apologize': (1, 0, 0, -3), 'distance': (-3, -2, 0, 4),
                   'flirt': (3, 1, 7, 0)}
        delta = effects.get(action, (2, 1, 0, 0))
        for field, change in zip(('intimacy', 'trust', 'romance', 'grudge'), delta):
            r[field] = max(0, min(100, r[field] + change))
        if action == 'friend_request':
            db.execute("INSERT INTO friend_requests VALUES(?,?,?,'pending',?)", (uid(), actor, target, now))
        elif action in ('accept_friend', 'decline_friend'):
            db.execute("UPDATE friend_requests SET status=? WHERE source=? AND target=? AND status='pending'",
                       ('accepted' if action == 'accept_friend' else 'rejected', target, actor))
            if action == 'accept_friend':
                db.executemany('INSERT OR IGNORE INTO friendships VALUES(?,?)', [(actor, target), (target, actor)])
        elif action == 'propose_romance':
            db.execute("INSERT INTO couples VALUES(?,?,?,?,'pending',?,0)", (uid(), actor, target, '认真相处', now))
        elif action in ('accept_romance', 'decline_romance'):
            db.execute("UPDATE couples SET status=? WHERE a_actor=? AND b_actor=? AND status='pending'",
                       ('active' if action == 'accept_romance' else 'declined', target, actor))
            if action == 'accept_romance':
                db.execute("UPDATE relationships SET type='恋人',updated_at=? WHERE a_actor=? AND b_actor=?", (now, target, actor))
                r['type'] = '恋人'
        elif action == 'breakup':
            db.execute("UPDATE couples SET status='ended' WHERE status='active' AND ((a_actor=? AND b_actor=?) OR (a_actor=? AND b_actor=?))", (actor, target, target, actor))
            db.execute("UPDATE relationships SET type='前任',updated_at=? WHERE a_actor=? AND b_actor=?", (now, target, actor))
            r['type'] = '前任'
        if action == 'distance':
            r['type'] = '疏远'
        elif action == 'accept_friend':
            r['type'] = '朋友'
            db.execute("UPDATE relationships SET type='朋友',updated_at=? WHERE a_actor=? AND b_actor=? AND type NOT IN ('恋人','前任')", (now, target, actor))
        elif action == 'flirt' and r['type'] not in ('恋人', '前任'):
            r['type'] = '有好感'
        elif r['type'] == '认识' and r['intimacy'] >= 8:
            r['type'] = '熟悉'
        db.execute('INSERT INTO relationships VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(a_actor,b_actor) DO UPDATE SET '
                   'type=excluded.type,intimacy=excluded.intimacy,trust=excluded.trust,romance=excluded.romance,grudge=excluded.grudge,updated_at=excluded.updated_at',
                   (actor, target, r['type'], r['intimacy'], r['trust'], r['romance'], r['grudge'], r.get('since', now), now))
        names = {row['id']: row['name'] for row in db.execute('SELECT id,name FROM actors WHERE id IN (?,?)', (actor, target))}
        phrases = {'reply': '回复了', 'agree': '赞同了', 'disagree': '与对方有了不同意见，回应了',
                   'friend_request': '主动向对方发出好友申请：', 'accept_friend': '通过了好友申请：',
                   'decline_friend': '拒绝了好友申请：', 'flirt': '向对方表达了自己的好感：',
                   'propose_romance': '向对方提出认真交往，等待答复：', 'accept_romance': '明确答应了恋爱提议：',
                   'decline_romance': '明确拒绝了恋爱提议：', 'breakup': '选择结束与对方的恋爱关系：',
                   'boundary': '向对方说清自己的边界：', 'apologize': '为自己的态度道歉：', 'distance': '选择暂时疏远：'}
        npc_target = bool(db.execute('SELECT 1 FROM npcs WHERE actor=?', (target,)).fetchone())
        summary = names.get(actor, '居民') + ' ' + phrases[action] + (names.get(target, '社区成员') if npc_target else '一条公开讨论')
        event = uid()
        db.execute('INSERT INTO npc_public_events VALUES(?,?,0,?,?,?,?,?,?)',
                   (event, unique, actor, target if npc_target else '', action, summary, source['post_id'], now))
        put_meta(db, 'npc-life:evidence:' + event, {'source_kind': source['kind'], 'source_id': source['id'],
                 'source_actor': target, 'source_text': source['text'], 'post_id': source['post_id'],
                 'post_actor': source['post_actor'], 'post_text': source['post_text'],
                 'output_id': output_id, 'output_text': utterance['text']})
        raw = json.loads(db.execute('SELECT persona_json FROM npcs WHERE actor=?', (actor,)).fetchone()[0])
        state = dict(self.state(db, actor, public_profile(raw), now))
        state['mood_event'] = event
        state['progress'] = min(100, state.get('progress', 0) + 5)
        put_meta(db, 'npc-life:state:' + actor, state)
        db.execute('INSERT OR IGNORE INTO moods(actor,updated_at) VALUES(?,?)', (actor, now))
        db.execute('UPDATE moods SET happy=MAX(0,MIN(100,happy+?)),angry=MAX(0,MIN(100,angry+?)),updated_at=? WHERE actor=?',
                   (2 if delta[3] <= 0 else -3, delta[3], now, actor))
        db.execute('UPDATE npc_goals SET progress=MIN(100,progress+5) WHERE actor=? AND expires_at>? AND progress<100', (actor, now))
        return event

    def record_topic(self, db, actor, persona, intent, now):
        state = dict(self.state(db, actor, persona, now))
        state['recent_topics'] = (topic_history(state, now) + [{'id': intent['id'], 'at': now}])[-128:]
        put_meta(db, 'npc-life:state:' + actor, state)
