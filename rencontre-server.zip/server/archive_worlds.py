"""Authenticated private NPC worlds alongside the existing human community.

Each world uses an independent SQL namespace in the same durable database.
Only verified root identities enter it. Resource tags preserve the destination
through existing clients; no lookup in another world is used to guess routing.
"""
import asyncio
from collections import OrderedDict
from dataclasses import dataclass
import hashlib
import json
import re
import sqlite3
import threading
import time
from urllib.parse import parse_qsl, urlencode

from fastapi import HTTPException
from starlette.concurrency import run_in_threadpool

from .community import pack
from .database import execute_batch


OWNER = 'rencontre-platform-residents'
ARCHIVE = re.compile(r'[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}\Z')
TAG = re.compile(r'w_([a-f0-9]{64})_(.+)\Z')
RAW_NPC = re.compile(r'npc-\d{2,4}\Z')
UID = re.compile(r'[a-f0-9]{24,64}\Z')
ID_FIELDS = set('id actor actor_id npc_id target_actor subject_actor source target a_actor b_actor '
                'room_id game_id post_id message_id reply_to repost_id source_id target_id '
                'avatar_id cover_id host turn drawer winner discarder landlord from claimed_by view_actor'.split())
ID_LISTS = set('actor_ids seats departed alive wolf_team acted voted responded guessed timed_out_bids ids'.split())
ACTOR_MAPS = set('hands hand_counts melds response_options responses roles visions votes night_actions scores bids'.split())
CHILD_PATHS = ('/npc/', '/residents', '/community', '/trending', '/gossips', '/couples',
               '/wallet', '/hearts', '/heart-wall', '/red-flags', '/yearbook', '/reports', '/relationships/')
LISTS = {'/actors', '/rooms', '/posts', '/friends', '/notifications', '/follows', '/topics'}
SHADOW_COLUMNS = ('id', 'owner_id', 'name', 'kind', 'bio', 'avatar_id', 'cover_id')
PUBLIC_GENDERS = frozenset(('male', 'female', 'male_dual', 'female_dual'))


def _public_gender(value):
    return value if isinstance(value, str) and value in PUBLIC_GENDERS else ''


def _shadow_fingerprint(user, created, token_hash, expires, actors):
    return hashlib.sha256(pack([user, created, token_hash, expires, sorted(actors)]).encode()).hexdigest()


@dataclass
class World:
    digest: str
    user: str
    app: object
    refs: int = 0
    running: bool = False
    last_tick: float = 0


@dataclass(frozen=True)
class VerifiedSession:
    """A capability carried only by this gateway's internal child calls."""
    root_store: object
    namespace: str
    user: str
    token_hash: str
    expires: float

    def user_for(self, store, token):
        # Shared human routes recheck the root session after world acquisition.
        if (getattr(store, 'budget_store', store) is self.root_store
                and store.namespace == self.namespace
                and self.expires > time.time()
                and hashlib.sha256(token.encode()).hexdigest() == self.token_hash):
            return self.user
        return None


class ArchiveWorlds:
    def __init__(self, root):
        self.root = root
        self.worlds = OrderedDict()
        self.lock = threading.RLock()
        self.max_cached = 16
        self.max_per_user = 20
        self.max_worlds = 2000
        snapshot=getattr(root.state.store,'schema_snapshot',None)
        if snapshot is not None and 'archive_world_registry' in snapshot['objects']:return
        with root.state.store.db() as db:
            ready = db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='archive_world_registry'").fetchone()
        if not ready:
            with root.state.store.db(write=True) as db:
                db.execute('CREATE TABLE IF NOT EXISTS archive_world_registry('
                           'user_id TEXT NOT NULL,digest TEXT PRIMARY KEY,created REAL NOT NULL)')

    def identity(self, authorization):
        if not authorization.startswith('Bearer '): raise HTTPException(401, '请先登录')
        token_hash = hashlib.sha256(authorization[7:].encode()).hexdigest()
        with self.root.state.store.db() as db:
            rows = db.execute('SELECT s.hash,s.user_id,s.expires,u.username,u.created,'
                              'a.id AS actor_id,a.name,a.kind,a.bio,a.avatar_id,a.cover_id,'
                              "COALESCE((SELECT value FROM community_meta WHERE key='profile-gender:'||a.id),'') AS gender "
                              'FROM sessions s JOIN users u ON u.id=s.user_id '
                              'LEFT JOIN actors a ON a.owner_id=u.id WHERE s.hash=? AND s.expires>?',
                              (token_hash, time.time())).fetchall()
        if not rows: raise HTTPException(401, '登录已过期，请重新登录')
        first = rows[0]
        actors = [dict(id=row['actor_id'], owner_id=first['user_id'],
                       gender=_public_gender(row['gender']),
                       **{key: row[key] for key in ('name', 'kind', 'bio', 'avatar_id', 'cover_id')})
                  for row in rows if row['actor_id'] is not None]
        return ({'id': first['user_id'], 'username': first['username'], 'created': first['created'],
                 '_actors': actors},
                {key: first[key] for key in ('hash', 'user_id', 'expires')})

    def acquire(self, archive, identity, session):
        if not ARCHIVE.fullmatch(archive): raise HTTPException(422, '存档标识格式无效或过长')
        digest = hashlib.sha256((identity['id'] + '\0' + archive).encode()).hexdigest()
        with self.lock:
            cached = digest in self.worlds
        fingerprint = None
        with self.root.state.store.db() as db:
            if cached:
                # Inspect the actual shadow rows in the registry round trip.
                # A marker can outlive a private edit or an older instance's
                # sync, so it cannot prove these rows still match the root.
                prefix = 'w_' + digest + '_'
                rows = db.execute('SELECT r.user_id,u.id AS shadow_user,u.username,u.created,'
                                  's.hash,s.expires,a.id AS actor_id,a.owner_id,a.name,a.kind,a.bio,a.avatar_id,a.cover_id,'
                                  "COALESCE(g.value,'') AS gender "
                                  'FROM archive_world_registry r '
                                  'LEFT JOIN ' + prefix + 'users u ON u.id=r.user_id '
                                  'LEFT JOIN ' + prefix + 'sessions s ON s.hash=? AND s.user_id=r.user_id '
                                  'LEFT JOIN ' + prefix + 'actors a ON a.owner_id=r.user_id '
                                  'LEFT JOIN ' + prefix + "community_meta g ON g.key='profile-gender:'||a.id WHERE r.digest=?",
                                  (session['hash'], digest)).fetchall()
                exists = rows[0] if rows else None
                if (exists and exists['shadow_user'] == identity['id']
                        and exists['username'] == 'archive-shadow-' + identity['id']
                        and exists['hash'] == session['hash']):
                    # Compare the actual metadata, not a stored sync marker or
                    # a normalized override that could hide a private edit.
                    values = [(row['actor_id'],) + tuple(row[key] for key in SHADOW_COLUMNS[1:]) + (row['gender'],)
                              for row in rows if row['actor_id'] is not None]
                    fingerprint = _shadow_fingerprint(exists['shadow_user'], exists['created'],
                                                      exists['hash'], exists['expires'], values)
            else:
                exists = db.execute('SELECT user_id FROM archive_world_registry WHERE digest=?', (digest,)).fetchone()
        if not exists:
            with self.root.state.store.db(write=True) as db:
                # Another cold instance can register the same world between
                # the read and transaction. Count only genuinely new worlds.
                exists = db.execute('SELECT user_id FROM archive_world_registry WHERE digest=?', (digest,)).fetchone()
                if not exists:
                    count = db.execute('SELECT COUNT(*) FROM archive_world_registry WHERE user_id=?', (identity['id'],)).fetchone()[0]
                    total = db.execute('SELECT COUNT(*) FROM archive_world_registry').fetchone()[0]
                    if count >= self.max_per_user or total >= self.max_worlds:
                        raise HTTPException(429, '存档社区数量已达上限，请使用已有存档')
                    db.execute('INSERT INTO archive_world_registry VALUES(?,?,?)', (identity['id'], digest, time.time()))
        if exists and exists['user_id'] != identity['id']:
            raise HTTPException(403, '这个存档不属于此账号')
        return self._acquire_world(digest, identity, session, fingerprint=fingerprint)

    def acquire_registered_digest(self, digest, identity, session):
        """Reopen a worker's registered world using an exact, live root session.

        The supplied dictionaries carry identifiers only. Reload both records
        from the root store so a stale/forged shadow session grants no access.
        No registry row or namespace is created for an unknown digest.
        """
        if not isinstance(digest, str) or not re.fullmatch(r'[a-f0-9]{64}', digest):
            raise HTTPException(403, '存档任务范围无效')
        user = identity.get('id') if isinstance(identity, dict) else None
        token_hash = session.get('hash') if isinstance(session, dict) else None
        if (not isinstance(user, str) or not user or not isinstance(token_hash, str)
                or not re.fullmatch(r'[a-f0-9]{64}', token_hash)):
            raise HTTPException(401, '登录已过期，请重新登录')
        with self.root.state.store.db() as db:
            valid = db.execute('SELECT * FROM sessions WHERE hash=? AND user_id=? AND expires>?',
                               (token_hash, user, time.time())).fetchone()
            owner = db.execute('SELECT id,username,created FROM users WHERE id=?', (user,)).fetchone()
            if not valid or not owner:
                raise HTTPException(401, '登录已过期，请重新登录')
            registered = db.execute('SELECT user_id FROM archive_world_registry WHERE digest=?', (digest,)).fetchone()
            if not registered or registered['user_id'] != user:
                raise HTTPException(403, '存档任务不属于此账号')
        return self._acquire_world(digest, dict(owner), dict(valid))

    def _acquire_world(self, digest, identity, session, *, fingerprint=None):
        with self.lock:
            world = self.worlds.get(digest)
            if world is None:
                while len(self.worlds) >= self.max_cached:
                    removable = next((key for key, value in self.worlds.items() if not value.refs and not value.running), None)
                    if removable is None: raise HTTPException(503, '其他存档正在处理，请稍后重试')
                    self.worlds.pop(removable)
                from .app import create_app
                child = create_app(self.root.state.store.path, archive_child=True, namespace='w_' + digest + '_',
                                   budget_store=self.root.state.store, root_community=self.root.state.community)
                world = World(digest, identity['id'], child)
                self.worlds[digest] = world
            if world.user != identity['id']:
                raise HTTPException(403, '这个存档不属于此账号')
            world.app.state.npc_world_digest = digest
            # The root dispatcher can be attached after this child was cached.
            world.app.state.npc_dispatcher = getattr(self.root.state, 'npc_dispatcher', None)
            self.worlds.move_to_end(digest)
            world.refs += 1
        try:
            own = self.sync(world, identity, session, actors=identity.get('_actors'), fingerprint=fingerprint)
            world.app.state.store.touch()
            return world, own
        except BaseException:
            self.release(world)
            raise

    def release(self, world):
        with self.lock: world.refs = max(0, world.refs - 1)

    def is_human_invitation(self, code):
        with self.root.state.store.db() as db:
            return bool(db.execute('SELECT 1 FROM invitations i JOIN actors a ON a.id=i.actor_id '
                                   'WHERE i.code=? AND a.owner_id<>?', (code, OWNER)).fetchone())

    def has_session(self, user):
        with self.root.state.store.db() as db:
            return bool(db.execute('SELECT 1 FROM sessions WHERE user_id=? AND expires>? LIMIT 1',
                                   (user, time.time())).fetchone())

    def sync(self, world, identity, session, *, actors=None, fingerprint=None):
        if actors is None:
            with self.root.state.store.db() as db:
                actors = [dict(row) for row in db.execute(
                    "SELECT a.*,COALESCE((SELECT value FROM community_meta WHERE key='profile-gender:'||a.id),'') AS gender "
                    'FROM actors a WHERE a.owner_id=?', (identity['id'],))]
        actor_values = sorted(tuple(actor[key] for key in SHADOW_COLUMNS) + (_public_gender(actor.get('gender')),)
                              for actor in actors)
        current = _shadow_fingerprint(identity['id'], identity['created'],
                                      session['hash'], session['expires'], actor_values)
        if fingerprint == current:
            return {actor['id'] for actor in actors}
        with world.app.state.store.db(write=True) as db:
            statements = [('INSERT INTO users(id,username,password,created) VALUES(?,?,?,?) '
                           'ON CONFLICT(id) DO UPDATE SET username=excluded.username '
                           'WHERE users.username IS NOT excluded.username',
                           (identity['id'], 'archive-shadow-' + identity['id'], '!archive-shadow-no-login', identity['created']))]
            for values in actor_values:
                statements.append(('INSERT INTO actors(id,owner_id,name,kind,bio,avatar_id,cover_id) VALUES(?,?,?,?,?,?,?) '
                           'ON CONFLICT(id) DO UPDATE SET name=excluded.name,bio=excluded.bio,kind=excluded.kind,'
                           'avatar_id=excluded.avatar_id,cover_id=excluded.cover_id '
                           'WHERE actors.name IS NOT excluded.name OR actors.bio IS NOT excluded.bio '
                           'OR actors.kind IS NOT excluded.kind OR actors.avatar_id IS NOT excluded.avatar_id '
                           'OR actors.cover_id IS NOT excluded.cover_id',
                           values[:len(SHADOW_COLUMNS)]))
                statements.append(('INSERT INTO community_meta(key,value) VALUES(?,?) '
                                   'ON CONFLICT(key) DO UPDATE SET value=excluded.value '
                                   'WHERE community_meta.value IS NOT excluded.value',
                                   ('profile-gender:' + values[0], values[-1])))
            statements.extend([
                ('INSERT INTO sessions(hash,user_id,expires) VALUES(?,?,?) '
                 'ON CONFLICT(hash) DO UPDATE SET expires=excluded.expires '
                 'WHERE sessions.expires IS NOT excluded.expires',
                 (session['hash'], identity['id'], session['expires'])),
            ])
            execute_batch(db, statements)
        return {actor['id'] for actor in actors}

    def copy_images(self, world, user, data):
        """Copy only an owner's explicitly referenced upload into their world."""
        image_id = data.get('image_id')
        if not image_id: return
        with self.root.state.store.db() as db:
            image = db.execute('SELECT * FROM images WHERE id=? AND owner_id=?', (image_id, user)).fetchone()
            variants = list(db.execute('SELECT * FROM image_variants WHERE image_id=?', (image_id,))) if image else []
        if image:
            with world.app.state.store.db(write=True) as db:
                db.execute('INSERT OR IGNORE INTO images VALUES(?,?,?,?,?)', tuple(image))
                db.executemany('INSERT OR IGNORE INTO image_variants VALUES(?,?,?,?)', [tuple(row) for row in variants])

    async def run(self):
        """One bounded worker rotates recently active worlds on a local host."""
        while True:
            with self.lock:
                current = time.monotonic()
                candidates = [world for world in self.worlds.values() if not world.running
                              and world.app.state.npc_engine.enabled
                              and world.app.state.store.last_activity > current - 120
                              and current - world.last_tick >= 30]
                world = min(candidates, key=lambda value: value.last_tick) if candidates else None
                if world:
                    world.running = True
                    world.last_tick = current
            if world:
                try:
                    # Child hubs have no root websocket clients. The active
                    # archive polls its own changes; human websocket data stays root.
                    valid = await run_in_threadpool(self.has_session, world.user)
                    if valid: await run_in_threadpool(world.app.state.npc_engine.tick, world.user)
                    world.app.state.npc_engine.last_error = False
                except Exception:
                    world.app.state.npc_engine.last_error = True
                finally:
                    with self.lock: world.running = False
            await asyncio.sleep(5)


class Resources:
    def __init__(self, world, own):
        self.world, self.own = world, own
        self.prefix = 'w_' + world.digest + '_'

    def decode_id(self, value):
        if not isinstance(value, str): return value
        match = TAG.fullmatch(value)
        if not match: return value
        if match[1] != self.world.digest: raise HTTPException(403, '这个内容属于另一个账号或存档')
        if len(match[2]) > 200 or not re.fullmatch(r'[A-Za-z0-9_.:-]+', match[2]):
            raise HTTPException(422, '内容标识无效')
        return match[2]

    def encode_id(self, value, force=False):
        if not isinstance(value, str) or value in self.own or not value: return value
        if force or RAW_NPC.fullmatch(value) or UID.fullmatch(value) or value.startswith(('legacy-', 'npc-event-')):
            return self.prefix + value
        return value

    def transform(self, value, *, output=False, field=''):
        convert = self.encode_id if output else self.decode_id
        if isinstance(value, list):
            return [convert(item) if isinstance(item, str) and field in ID_LISTS
                    else self.transform(item, output=output, field=field) for item in value]
        if isinstance(value, dict):
            result = {(convert(key) if field in ACTOR_MAPS else key):
                      convert(item) if field in ACTOR_MAPS and isinstance(item, str)
                      else self.transform(item, output=output, field=key)
                      for key, item in value.items()}
            if output and 'id' in value and 'cost' not in value:
                result['id'] = self.encode_id(value['id'], force=True)
            if output and RAW_NPC.fullmatch(str(value.get('id', ''))) and 'name' in value and 'kind' in value:
                result['is_npc'] = True
            return result
        return convert(value) if field in ID_FIELDS or field in ID_LISTS else value

    def path(self, path):
        return '/'.join(self.decode_id(part) for part in path.split('/'))

    def query(self, query):
        result = []
        for key, value in parse_qsl(query, keep_blank_values=True):
            if key == 'ids': value = ','.join(self.decode_id(item) for item in value.split(','))
            elif key in ID_FIELDS: value = self.decode_id(value)
            elif key == 'q' and TAG.fullmatch(value): value = self.decode_id(value)
            result.append((key, value))
        return urlencode(result)


@dataclass
class Captured:
    status: int
    headers: list
    body: bytes

    def json(self):
        return json.loads(self.body)


async def _call(app, scope, body, *, path=None, query=None):
    target = dict(scope)
    target['state'] = dict(scope.get('state', {}))
    if path is not None:
        target['path'] = path
        target['raw_path'] = path.encode()
    if query is not None: target['query_string'] = query.encode()
    target['headers'] = [(key, value) for key, value in scope['headers'] if key.lower() != b'content-length']
    target['headers'].append((b'content-length', str(len(body)).encode()))
    sent, result, chunks = False, {}, []
    async def receive():
        nonlocal sent
        if not sent:
            sent = True
            return {'type': 'http.request', 'body': body, 'more_body': False}
        await asyncio.Event().wait()
    async def send(message):
        if message['type'] == 'http.response.start': result.update(status=message['status'], headers=message['headers'])
        elif message['type'] == 'http.response.body': chunks.append(message.get('body', b''))
    await app(target, receive, send)
    return Captured(result['status'], result['headers'], b''.join(chunks))


def _marked(value, source):
    if isinstance(value, dict):
        value = dict(value, world_source=source)
        value.setdefault('source', source)
    return value


def _real(value):
    if isinstance(value, dict):
        if value.get('owner_id') == OWNER or value.get('is_npc'): return False
        for key in ('actor', 'source_actor', 'target_actor'):
            if isinstance(value.get(key), dict) and not _real(value[key]): return False
        if any(isinstance(item, dict) and not _real(item) for item in value.get('members', [])): return False
        if RAW_NPC.fullmatch(str(value.get('actor_id', ''))): return False
    return True


class ArchiveWorldMiddleware:
    def __init__(self, app, manager): self.app, self.manager = app, manager

    async def __call__(self, scope, receive, send):
        if scope['type'] != 'http' or not scope['path'].startswith('/api/') or scope['method'] == 'OPTIONS':
            return await self.app(scope, receive, send)
        headers = {key.lower(): value for key, value in scope['headers']}
        archive = headers.get(b'x-rencontre-archive', b'').decode('ascii', 'replace')
        path = scope['path'][4:]
        # This surface contains only root public AI identities and consent;
        # it never enters, decodes or exports a private resident instance.
        if path.startswith('/ai-social/') or path == '/actors/main-character':
            return await self.app(scope, receive, send)
        if not archive or path in ('/register', '/login', '/logout'):
            if 'w_' in path and re.search(r'w_[a-f0-9]{64}_', path):
                return await self.respond(send, 401, {'detail': '请登录并打开内容所属存档'})
            return await self.app(scope, receive, send)
        if path == '/health' and b'authorization' not in headers:
            return await self.app(scope, receive, send)
        world = None
        try:
            if not ARCHIVE.fullmatch(archive): raise HTTPException(422, '存档标识格式无效或过长')
            # Shared identity restoration must never depend on creating or
            # migrating a private NPC world. The root app verifies its live
            # session itself; no cached capability bypasses revocation.
            if scope['method'] == 'GET' and path == '/me':
                return await self.app(scope, receive, send)
            shared_post = re.fullmatch(r'/(?:public/)?posts/[a-f0-9]{24}', path)
            shared_comment = re.fullmatch(r'/posts/[a-f0-9]{24}/comments', path)
            automatic_post = path == '/posts'
            if scope['method'] == 'GET' and shared_post:
                result = await _call(self.app, scope, b'')
                if result.status < 300:
                    value = result.json()
                    self.post_sequences(value, False)
                    result = self.json_result(result, value)
                return await self.forward(send, result)
            if scope['method'] == 'POST' and (shared_comment or automatic_post):
                chunks = []
                while True:
                    message = await receive()
                    if message['type'] == 'http.disconnect': return
                    chunks.append(message.get('body', b''))
                    if not message.get('more_body'): break
                saved_body = b''.join(chunks)
                candidate = json.loads(saved_body) if saved_body else {}
                is_shared = (isinstance(candidate, dict) and UID.fullmatch(str(candidate.get('actor_id', '')))
                             and candidate.get('world_source') != 'npc')
                fast_comment = shared_comment and is_shared and set(candidate) <= {'actor_id', 'text', 'action_lease'}
                fast_post = (automatic_post and is_shared and bool(candidate.get('action_lease'))
                             and not any(TAG.fullmatch(str(candidate.get(key, ''))) for key in ('image_id','repost_id')))
                if fast_comment or fast_post:
                    result = await _call(self.app, scope, saved_body)
                    if fast_post and result.status < 300:
                        value = result.json()
                        self.post_sequences(value, False)
                        result = self.json_result(result, value)
                    return await self.forward(send, result)
                # A tagged/private actor still follows the complete world
                # checks. Replay the consumed body for the normal path.
                replayed = False
                original_receive = receive
                async def replay_receive():
                    nonlocal replayed
                    if not replayed:
                        replayed = True
                        return {'type': 'http.request', 'body': saved_body, 'more_body': False}
                    return await original_receive()
                receive = replay_receive
            identity, session = await run_in_threadpool(self.manager.identity, headers.get(b'authorization', b'').decode())
            world, own = await run_in_threadpool(self.manager.acquire, archive, identity, session)
            scope = dict(scope, _rencontre_verified_session=VerifiedSession(
                self.manager.root.state.store, world.app.state.store.namespace,
                identity['id'], session['hash'], session['expires']))
            resources = Resources(world, own)
            chunks = []
            while True:
                message = await receive()
                if message['type'] == 'http.disconnect': return
                chunks.append(message.get('body', b''))
                if not message.get('more_body'): break
            body = b''.join(chunks)
            data = json.loads(body) if body else {}
            if not isinstance(data, dict):
                return await self.forward(send, await _call(self.app, scope, body))
            decoded = resources.transform(data)
            decoded_path = resources.path(scope['path'])
            query = scope.get('query_string', b'').decode('utf-8')
            decoded_query = resources.query(query)
            result = await self.route(scope, body, data, decoded, decoded_path, query, decoded_query,
                                      resources, identity, session)
            return await self.forward(send, result)
        except HTTPException as error:
            return await self.respond(send, error.status_code, {'detail': error.detail})
        except (ValueError, UnicodeError, TypeError):
            return await self.respond(send, 422, {'detail': '请求格式无效'})
        except sqlite3.OperationalError:
            return await self.respond(send, 503, {'detail': '社区正在保存数据，请稍后重试'})
        finally:
            if world: self.manager.release(world)

    async def route(self, scope, body, data, decoded, decoded_path, query, decoded_query, resources, identity, session):
        path = scope['path'][4:]
        normalized = path.removeprefix('/public')
        method = scope['method']
        child = resources.world.app
        tagged_path = decoded_path != scope['path']
        tagged_body = decoded != data
        tagged_query = decoded_query != urlencode(parse_qsl(query, keep_blank_values=True))
        forced = normalized.startswith(CHILD_PATHS)
        npc_body = any(RAW_NPC.fullmatch(str(decoded.get(key, ''))) for key in ('actor_id', 'target_id'))
        if isinstance(decoded.get('actor_ids'), list):
            npc_body = npc_body or any(RAW_NPC.fullmatch(str(aid)) for aid in decoded['actor_ids'])
        if path.startswith('/invitations/'):
            code = path.rsplit('/', 1)[-1].upper()
            forced = not await run_in_threadpool(self.manager.is_human_invitation, code)
        if path == '/friends/requests' and data.get('invite_code'):
            code = str(data['invite_code']).strip().upper()
            forced = not await run_in_threadpool(self.manager.is_human_invitation, code)
        if method == 'POST' and path == '/notifications/read':
            return await self.read_notifications(scope, data, resources)
        if method == 'GET' and normalized in LISTS and not tagged_path and (not tagged_query or normalized == '/posts' and 'ids=' in query):
            return await self.merge(scope, body, normalized, query, resources)
        private = forced or tagged_path or tagged_body or tagged_query or npc_body or data.get('world_source') == 'npc'
        if normalized.startswith('/actors/npc-'): private = True
        if private:
            # A private room contains the archive owner, their own roles and
            # resident instances. Other humans retain their original root room.
            ids = decoded.get('actor_ids', [])
            if normalized == '/rooms' and method == 'POST':
                if any(aid not in resources.own and not RAW_NPC.fullmatch(str(aid)) for aid in ids):
                    raise HTTPException(409, '私人 NPC 会话不能加入其他真人，请另建真人群聊')
            if normalized.startswith('/rooms/') and not tagged_path and (tagged_body or npc_body):
                raise HTTPException(409, '真人会话不能加入私人存档 NPC，请另建 NPC 会话')
            if normalized.startswith('/rooms/') and normalized.endswith('/members') and method == 'POST':
                aid = decoded.get('actor_id')
                if aid not in resources.own and not RAW_NPC.fullmatch(str(aid)):
                    raise HTTPException(409, '私人 NPC 会话不能加入其他真人')
            if not tagged_path and tagged_body and re.match(r'^/(?:posts|games|messages)/[^/]+', normalized):
                raise HTTPException(409, '请在内容所属社区操作，不能跨存档引用')
            decoded = dict(decoded)
            decoded.pop('world_source', None)
            if body and method in ('POST', 'PATCH'):
                await run_in_threadpool(self.manager.copy_images, resources.world, identity['id'], decoded)
            if normalized == '/posts' and method == 'GET':
                params = dict(parse_qsl(decoded_query, keep_blank_values=True))
                before = int(params.get('before', 0))
                if before:
                    if before // 2 <= 0: return Captured(200, [(b'content-type', b'application/json')], b'[]')
                    params['before'] = str(before // 2)
                    decoded_query = urlencode(params)
            result = await _call(child, scope, pack(decoded).encode() if body else body,
                                 path=decoded_path, query=decoded_query)
            if normalized.startswith('/npc/models'):
                return result
            if path == '/health' and result.status == 200:
                value = result.json()
                value.update(archive_scoped=True, human_social_shared=True)
                value['capabilities'] = list(dict.fromkeys(value.get('capabilities', []) + ['archives.private-worlds', 'players.shared-social']))
                return self.json_result(result, value)
            if normalized.startswith('/posts') and result.status < 300:
                value = result.json()
                self.post_sequences(value, True)
                result = self.json_result(result, value)
            return self.tag_result(result, resources)
        if path == '/health':
            result = await _call(child, scope, body)
            value = result.json()
            value.update(archive_scoped=True, human_social_shared=True)
            value['capabilities'] = list(dict.fromkeys(value.get('capabilities', []) + ['archives.private-worlds', 'players.shared-social']))
            return self.json_result(result, value)
        result = await _call(self.app, scope, body)
        if normalized.startswith('/posts') and result.status < 300:
            value = result.json()
            self.post_sequences(value, False)
            result = self.json_result(result, value)
        if result.status < 300 and normalized.startswith('/actors') and method != 'GET':
            await run_in_threadpool(self.manager.sync, resources.world, identity, session)
        return result

    def json_result(self, result, value):
        headers = [(key, value) for key, value in result.headers if key.lower() not in (b'content-length', b'etag', b'cache-control')]
        headers.append((b'cache-control', b'private, no-store'))
        return Captured(result.status, headers, pack(value).encode())

    def tag_result(self, result, resources):
        if result.status >= 400: return result
        try:
            value = result.json()
        except (ValueError, UnicodeError):
            result.headers = [(key, value) for key, value in result.headers if key.lower() != b'cache-control']
            result.headers.append((b'cache-control', b'private,max-age=0,must-revalidate'))
            return result
        value = resources.transform(value, output=True)
        if isinstance(value, list): value = [_marked(item, 'npc') for item in value]
        elif isinstance(value, dict): value = _marked(value, 'npc')
        return self.json_result(result, value)

    async def merge(self, scope, body, path, query, resources):
        params = dict(parse_qsl(query, keep_blank_values=True))
        if path in ('/actors', '/rooms'):
            return await self.merge_page(scope, body, path, params, resources)
        root_params = dict(params, real_only='true')
        child_params = dict(params)
        child_params.pop('real_only', None)
        before = int(params.get('before', 0))
        if path == '/posts':
            if before:
                root_params['before'] = str((before + 1) // 2)
                child_params['before'] = str(before // 2)
            if 'ids' in params:
                identifiers = params['ids'].split(',')
                root_params['ids'] = ','.join(item for item in identifiers if not TAG.fullmatch(item))
                child_params['ids'] = ','.join(resources.decode_id(item) for item in identifiers if TAG.fullmatch(item))
        if path == '/notifications' and before:
            # Paging is independent from the composite read boundary.
            root_params['before'] = str((before + 1) // 2)
            child_params['before'] = str(before // 2)
        first = await _call(self.app, scope, body, query=urlencode(root_params))
        if first.status >= 400: return first
        second = await _call(resources.world.app, scope, body, query=urlencode(child_params))
        if second.status >= 400: return second
        real, private = first.json(), resources.transform(second.json(), output=True)
        if path == '/posts':
            if params.get('ids'):
                if not root_params['ids']: real = []
                if not child_params['ids']: private = []
            if before and before // 2 <= 0: private = []
            self.post_sequences(real, False)
            self.post_sequences(private, True)
        if path == '/friends':
            value = {key: [_marked(item, 'players') for item in real[key] if _real(item)]
                     + [_marked(item, 'npc') for item in private[key]] for key in ('requests', 'friends')}
        elif path == '/notifications':
            value = {}
            for key in ('comments', 'likes', 'followers', 'requests', 'items'):
                value[key] = [_marked(item, 'players') for item in real[key] if _real(item)] + [_marked(item, 'npc') for item in private[key]]
                for item in value[key]: item['seq'] = item['seq'] * 2 + int(item['world_source'] == 'npc')
                value[key].sort(key=lambda item: item['seq'], reverse=True)
                value[key] = value[key][:int(params.get('limit', 100))]
            value['unread_counts'] = {key: real['unread_counts'].get(key, 0) + private['unread_counts'].get(key, 0)
                                      for key in ('comments', 'likes', 'followers', 'requests')}
            value['unread_count'] = sum(value['unread_counts'].values())
            # This read boundary is a pair encoded in a JSON-safe integer.
            # Each source is limited to 2**26 notifications by its own sequence.
            if real['latest_seq'] >= 2**26 or private['latest_seq'] >= 2**26:
                raise HTTPException(409, '请按通知编号标记已读')
            value['latest_seq'] = real['latest_seq'] * 2**26 + private['latest_seq']
        elif path == '/topics':
            combined = {}
            for item in real + private:
                row = combined.setdefault(item['tag'], {'tag': item['tag'], 'posts': 0, 'participants': 0})
                row['posts'] += item['posts']; row['participants'] += item['participants']
            value = sorted(combined.values(), key=lambda item: (-item['posts'], item['tag']))[:30]
        else:
            value = [_marked(item, 'players') for item in real if _real(item)]
            value += [_marked(item, 'npc') for item in private if path != '/actors' or item['id'] not in resources.own]
            if path == '/posts':
                value.sort(key=lambda item: (item.get('heat', 0), item['seq']) if params.get('sort') == 'hot' else (item['seq'],), reverse=True)
                value = value[:40]
            seen = set()
            value = [item for item in value if not (item['id'] in seen or seen.add(item['id']))]
        return self.json_result(first, value)

    @staticmethod
    def post_sequences(value, private):
        for row in value if isinstance(value, list) else [value]:
            if isinstance(row, dict) and 'seq' in row and 'actor_id' in row:
                row['seq'] = row['seq'] * 2 + int(private)

    async def merge_page(self, scope, body, path, params, resources):
        offset, limit = int(params.get('offset', 0)), int(params.get('limit', 200))
        if offset < 0 or offset > 2000 or not 1 <= limit <= 200:
            raise HTTPException(422, '分页位置或数量无效')
        target, real, first, root_total = offset + limit, [], None, 0
        while len(real) < target:
            query = dict(params, offset=str(len(real)), limit=str(min(200, target - len(real))), real_only='true')
            page = await _call(self.app, scope, body, query=urlencode(query))
            if page.status >= 400: return page
            if first is None: first = page
            batch = page.json()
            real.extend(batch)
            root_total = int(dict(page.headers).get(b'x-total-count', len(real)))
            if not batch or len(real) >= root_total: break
        child_params = dict(params, offset='0', limit='200')
        child_params.pop('real_only', None)
        child = await _call(resources.world.app, scope, body, query=urlencode(child_params))
        if child.status >= 400: return child
        private = resources.transform(child.json(), output=True)
        if path == '/actors': private = [item for item in private if item['id'] not in resources.own]
        value = [_marked(item, 'players') for item in real if _real(item)] + [_marked(item, 'npc') for item in private]
        if path == '/actors': value.sort(key=lambda item: (item['name'], item['id']))
        else: value.sort(key=lambda item: (-item.get('created', 0), item['id']))
        total = root_total + len(private)
        value = value[offset:offset + limit]
        result = self.json_result(first, value)
        result.headers = [(key, value) for key, value in result.headers if key.lower() not in (b'x-total-count', b'x-next-offset')]
        result.headers += [(b'x-total-count', str(total).encode()),
                           (b'x-next-offset', str(offset + len(value)).encode() if offset + len(value) < total else b'')]
        return result

    async def read_notifications(self, scope, data, resources):
        ids = data.get('ids') or []
        if ids:
            private = [resources.decode_id(item) for item in ids if TAG.fullmatch(str(item))]
            real = [item for item in ids if not TAG.fullmatch(str(item))]
            requests = [(self.app, dict(data, ids=real)), (resources.world.app, dict(data, ids=private))]
            requests = [(app, value) for app, value in requests if value['ids']]
        elif data.get('through_seq') is not None:
            boundary = data['through_seq']
            if type(boundary) is not int or boundary < 0: raise HTTPException(422, '通知分页位置无效')
            real, private = divmod(boundary, 2**26)
            requests = [(self.app, dict(data, through_seq=real)), (resources.world.app, dict(data, through_seq=private))]
        else:
            return await _call(self.app, scope, pack(data).encode())
        result = None
        for app, value in requests:
            result = await _call(app, scope, pack(value).encode())
            if result.status >= 400: return result
        return result or Captured(200, [(b'content-type', b'application/json')], b'{"ok":true}')

    @staticmethod
    async def respond(send, status, value):
        await ArchiveWorldMiddleware.forward(send, Captured(status, [(b'content-type', b'application/json')], pack(value).encode()))

    @staticmethod
    async def forward(send, response):
        headers = [(key, value) for key, value in response.headers if key.lower() != b'content-length']
        headers.append((b'content-length', str(len(response.body)).encode()))
        await send({'type': 'http.response.start', 'status': response.status, 'headers': headers})
        await send({'type': 'http.response.body', 'body': response.body})
