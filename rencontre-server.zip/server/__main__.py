"""Run from the www folder: python -m server --host 0.0.0.0 --port 9891."""
import argparse
import os
import uvicorn
from .app import create_app

if __name__=='__main__':
    parser=argparse.ArgumentParser(description='Rencontre 本机、局域网或云端服务器')
    parser.add_argument('--host',default='127.0.0.1',help='同一局域网共享请显式填写 0.0.0.0')
    parser.add_argument('--port',type=int,default=int(os.environ.get('PORT','9891')))
    parser.add_argument('--db',default=None,help='SQLite 文件，默认 server/data/rencontre.sqlite3')
    args=parser.parse_args()
    mode='云端' if os.environ.get('RENCONTRE_TURSO_URL') else '本机 / 局域网'
    print(f'当前为{mode}模式。模型 API 密钥和私有角色卡不上传此服务。')
    uvicorn.run(create_app(args.db),host=args.host,port=args.port,ws_max_size=65536,access_log=False)
