"""Consent-based social actions for intentionally published player AI identities.

Only public root actors and short action references are stored here. Local role
cards, provider configuration and prompts are never accepted by these routes.
"""
import hashlib
import json
import secrets
import time
from itertools import combinations
from typing import Literal

from fastapi import BackgroundTasks, Depends, HTTPException
from pydantic import BaseModel, ConfigDict, Field, StrictBool, ValidationError


PUBLIC_COLUMNS = ('id', 'owner_id', 'name', 'kind', 'bio', 'avatar_id', 'cover_id')
POLICY_PREFIX = 'ai-social:policy:'
ACTION_PREFIX = 'ai-social:action:'
COOLDOWN_PREFIX = 'ai-social:cooldown:'
ROOM_PREFIX = 'ai-social:room:'
FRIEND_PREFIX = 'ai-social:friend:'
DELIVERY_PREFIX = 'ai-social:delivery:'
COOLDOWNS = {'comment': 600, 'post': 1800, 'visit': 1800}
LEASE_SECONDS = 180


class Strict(BaseModel):
    model_config = ConfigDict(extra='forbid')


class PolicyIn(Strict):
    enabled: StrictBool
    peer_chat: StrictBool


class PolicyPatchIn(Strict):
    enabled: StrictBool = False
    peer_chat: StrictBool = False


class ConnectIn(Strict):
    actor_id: str = Field(min_length=1, max_length=160)
    target_id: str = Field(min_length=1, max_length=160)


class ActionIn(Strict):
    actor_id: str = Field(min_length=1, max_length=160)
    action: Literal['comment', 'post', 'visit']
    source_id: str = Field(min_length=1, max_length=160, pattern=r'^\S+$')


class ActionLease(ActionIn):
    lease: str = Field(min_length=1, max_length=200)


class ActionComplete(ActionLease):
    result_id: str = Field(min_length=1, max_length=160, pattern=r'^\S+$')


def _check(value, message, status=403):
    if not value:
        raise HTTPException(status, message)


def _meta(db, key, default=None):
    row = db.execute('SELECT value FROM community_meta WHERE key=?', (key,)).fetchone()
    if row:
        try:
            return json.loads(row['value'])
        except (ValueError, TypeError):
            pass
    return default


def _put(db, key, value):
    db.execute('INSERT INTO community_meta(key,value) VALUES(?,?) '
               'ON CONFLICT(key) DO UPDATE SET value=excluded.value',
               (key, json.dumps(value, ensure_ascii=False, separators=(',', ':'))))


def _policy_value(aid, value):
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except (ValueError, TypeError):
            value = {}
    if not isinstance(value, dict):
        value = {}
    return {'actor_id': aid, 'enabled': value.get('enabled') is True,
            'peer_chat': value.get('peer_chat') is True}


def _policy(db, aid):
    return _policy_value(aid, _meta(db, POLICY_PREFIX + aid, {}))


def _actor(db, aid, user=None):
    # An unknown/tagged/resident ID is not a permission to resolve another world.
    _check(not aid.startswith(('w_', 'npc-')), '只能使用已发布的玩家 AI 身份')
    columns = ','.join('a.' + column for column in PUBLIC_COLUMNS)
    row = db.execute('SELECT ' + columns + " FROM actors a WHERE a.id=? AND a.kind='ai' "
                     'AND NOT EXISTS(SELECT 1 FROM npcs n WHERE n.actor=a.id)', (aid,)).fetchone()
    _check(row and (user is None or row['owner_id'] == user), '无权使用这个公开 AI 身份')
    return dict(row)


def _human_friends(db, owner, other):
    if owner == other:
        return False
    return bool(db.execute("SELECT 1 FROM actors own JOIN actors peer ON peer.kind='user' "
                           "WHERE own.owner_id=? AND own.kind='user' AND peer.owner_id=? "
                           'AND EXISTS(SELECT 1 FROM friendships f WHERE f.a=own.id AND f.b=peer.id) '
                           'AND EXISTS(SELECT 1 FROM friendships f WHERE f.a=peer.id AND f.b=own.id) LIMIT 1',
                           (owner, other)).fetchone())


def _consented(policy):
    return policy['enabled'] and policy['peer_chat']


def _digest(*parts):
    return hashlib.sha256(json.dumps(parts, separators=(',', ':')).encode()).hexdigest()


def _action_key(body):
    return ACTION_PREFIX + _digest(body.actor_id, body.action, body.source_id)


def _cooldown_key(body):
    return COOLDOWN_PREFIX + _digest(body.actor_id, body.action)


def _delivery_fingerprint(body):
    values = body.model_dump(exclude={'action_lease', 'delivery_id'})
    values['text'] = values['text'].strip()
    return _digest(values)


def existing_delivery(db, body):
    """Resolve an exact receipt before checking an already-consumed action lease.

    The caller first verifies actor ownership in its current write transaction.
    A deleted post retains its receipt so retrying cannot silently recreate it.
    """
    if not body.delivery_id:
        return None
    saved = _meta(db, DELIVERY_PREFIX + _digest(body.actor_id, body.delivery_id))
    if saved is None:
        return None
    _check(isinstance(saved, dict) and saved.get('fingerprint') == _delivery_fingerprint(body),
           '同一投递凭据不能修改动态内容', 409)
    row = db.execute('SELECT * FROM posts WHERE id=? AND actor_id=?',
                     (saved.get('post_id'), body.actor_id)).fetchone()
    _check(row, '这条投递对应的动态已删除', 404)
    return row


def record_delivery(db, body, post_id):
    if body.delivery_id:
        _put(db, DELIVERY_PREFIX + _digest(body.actor_id, body.delivery_id),
             {'post_id': post_id, 'fingerprint': _delivery_fingerprint(body)})


def _valid_source(db, own, body):
    if body.action == 'visit':
        _peer(db, own, body.source_id)
    elif body.action == 'post':
        _check(body.source_id == own['id'], '自主动态需使用自己的公开 AI 身份作为来源')
    else:
        # Only raw root public posts. A private archive tag must never acquire a
        # child world or expose that world's content through this root API.
        _check(not body.source_id.startswith(('w_', 'npc-')), '只能评论公开社区动态')
        row = db.execute('SELECT p.id FROM posts p JOIN actors a ON a.id=p.actor_id WHERE p.id=? '
                         'AND NOT EXISTS(SELECT 1 FROM npcs n WHERE n.actor=a.id)',
                         (body.source_id,)).fetchone()
        _check(row, '只能评论公开社区动态')


def _current_lease(db, body, user, current):
    _actor(db, body.actor_id, user)
    value = _meta(db, _action_key(body), {})
    _check(isinstance(value, dict) and value.get('status') == 'running'
           and isinstance(value.get('expires'), (int, float)) and value['expires'] > current
           and isinstance(value.get('lease_hash'), str)
           and secrets.compare_digest(value['lease_hash'], _digest(body.lease)),
           '任务凭据已失效，请勿重复提交', 409)
    return value


def _lease_input(actor_id, action, source_id, lease, result_id=None):
    values = dict(actor_id=actor_id, action=action, source_id=source_id, lease=lease)
    if result_id is not None:
        values['result_id'] = result_id
    try:
        return ActionComplete(**values) if result_id is not None else ActionLease(**values)
    except ValidationError:
        raise HTTPException(422, '任务引用格式无效') from None


def validate_action(db, user, actor_id, action, source_id, lease):
    """Check an automatic write inside the caller's existing write transaction.

    No connection is opened here. The caller must insert the post/comment and
    call complete_action before committing this same transaction.
    """
    body = _lease_input(actor_id, action, source_id, lease)
    value = _current_lease(db, body, user, time.time())
    own = _actor(db, actor_id, user)
    _check(_policy(db, actor_id)['enabled'], '这个公开 AI 的自主活动已关闭')
    _valid_source(db, own, body)
    return value


def complete_action(db, user, actor_id, action, source_id, lease, result_id):
    """Consume the lease alongside its actual post/comment insert, atomically."""
    body = _lease_input(actor_id, action, source_id, lease, result_id)
    value = validate_action(db, user, actor_id, action, source_id, lease)
    current = time.time()
    value.update(status='done', completed=current, result_id=body.result_id)
    value.pop('lease_hash', None)
    value.pop('expires', None)
    _put(db, _action_key(body), value)
    _put(db, _cooldown_key(body), {'until': current + COOLDOWNS[action]})
    return {'ok': True, 'result_id': body.result_id}


def _peer(db, own, target_id):
    other = _actor(db, target_id)
    _check(_consented(_policy(db, own['id'])) and _consented(_policy(db, target_id)),
           '双方需开启 AI 互访')
    _check(_human_friends(db, own['owner_id'], other['owner_id']), '双方玩家需互为真人好友')
    return other


def _room_pairs(value):
    if isinstance(value, list) and len(value) == 2 and all(isinstance(aid, str) for aid in value):
        return [value]
    return value if isinstance(value, list) else []


def validate_social_members(db, actor_ids):
    """Social-origin friendships retain consent when reused in normal groups."""
    keys = [FRIEND_PREFIX + _digest(*pair) for pair in combinations(sorted(set(actor_ids)), 2)]
    if not keys:
        return []
    rows = db.execute('SELECT value FROM community_meta WHERE key IN (' + ','.join('?' for _ in keys) + ')', keys)
    pairs = [json.loads(row['value']) for row in rows]
    for pair in pairs:
        _peer(db, _actor(db, pair[0]), pair[1])
    return pairs


def bind_social_room(db, rid, pairs):
    if not pairs:
        return
    saved = _room_pairs(_meta(db, ROOM_PREFIX + rid))
    _put(db, ROOM_PREFIX + rid, [list(pair) for pair in sorted({tuple(pair) for pair in saved + pairs})])


def validate_peer_room(db, rid, actor_id):
    """Recheck durable social provenance even after room membership changes."""
    for pair in _room_pairs(_meta(db, ROOM_PREFIX + rid)):
        if actor_id in pair:
            _peer(db, _actor(db, actor_id), pair[1] if pair[0] == actor_id else pair[0])


def _room_view(db, row):
    result = dict(row)
    result['ai'] = json.loads(result['ai'])
    result['ai'].pop('lease', None)
    columns = ','.join('a.' + column for column in PUBLIC_COLUMNS)
    result['members'] = [dict(actor) for actor in db.execute(
        'SELECT ' + columns + ' FROM actors a JOIN members m ON m.actor_id=a.id '
        'WHERE m.room_id=? ORDER BY a.id', (row['id'],))]
    profile = db.execute('SELECT announcement FROM room_profiles WHERE room_id=?', (row['id'],)).fetchone()
    last = db.execute('SELECT * FROM messages WHERE room_id=? ORDER BY seq DESC LIMIT 1', (row['id'],)).fetchone()
    result.update(announcement=profile['announcement'] if profile else '',
                  last_message=dict(last) if last else None, unread_count=0)
    return result


def install_routes(app, store, auth, hub):
    """Install on the root app, using its existing verified login dependency."""
    if getattr(store, 'namespace', ''):
        return

    @app.get('/api/ai-social/policies')
    def policies(user=Depends(auth)):
        with store.db() as db:
            rows = db.execute("SELECT a.id,p.value FROM actors a LEFT JOIN community_meta p ON p.key=?||a.id "
                              "WHERE a.owner_id=? AND a.kind='ai' "
                              'AND NOT EXISTS(SELECT 1 FROM npcs n WHERE n.actor=a.id) ORDER BY a.id',
                              (POLICY_PREFIX, user))
            return [_policy_value(row['id'], row['value']) for row in rows]

    @app.put('/api/ai-social/policies/{aid}')
    def put_policy(aid: str, body: PolicyIn, user=Depends(auth)):
        with store.db(write=True) as db:
            _actor(db, aid, user)
            _put(db, POLICY_PREFIX + aid, body.model_dump())
            return _policy(db, aid)

    @app.patch('/api/ai-social/policies/{aid}')
    def patch_policy(aid: str, body: PolicyPatchIn, user=Depends(auth)):
        changes = body.model_dump(exclude_unset=True)
        _check(changes, '请选择要修改的公开授权', 422)
        with store.db(write=True) as db:
            _actor(db, aid, user)
            value = _policy(db, aid)
            value.pop('actor_id')
            value.update(changes)
            _put(db, POLICY_PREFIX + aid, value)
            return _policy(db, aid)

    @app.get('/api/ai-social/peers')
    def peers(actor_id: str, user=Depends(auth)):
        with store.db() as db:
            own = _actor(db, actor_id, user)
            if not _consented(_policy(db, actor_id)):
                return []
            columns = ','.join('a.' + column for column in PUBLIC_COLUMNS)
            rows = db.execute('SELECT DISTINCT ' + columns + ',human.name AS owner_name,policy.value AS social_policy '
                "FROM actors a JOIN actors human ON human.owner_id=a.owner_id AND human.kind='user' "
                'LEFT JOIN community_meta policy ON policy.key=?||a.id '
                "WHERE a.kind='ai' AND a.owner_id<>? AND NOT EXISTS(SELECT 1 FROM npcs n WHERE n.actor=a.id) "
                "AND EXISTS(SELECT 1 FROM actors own WHERE own.owner_id=? AND own.kind='user' "
                'AND EXISTS(SELECT 1 FROM friendships f WHERE f.a=own.id AND f.b=human.id) '
                'AND EXISTS(SELECT 1 FROM friendships f WHERE f.a=human.id AND f.b=own.id)) ORDER BY a.name,a.id',
                (POLICY_PREFIX, own['owner_id'], own['owner_id']))
            result = []
            for row in rows:
                item = dict(row)
                if _consented(_policy_value(item['id'], item.pop('social_policy'))):
                    result.append(item)
            return result

    @app.post('/api/ai-social/connect')
    def connect(background: BackgroundTasks, body: ConnectIn, user=Depends(auth)):
        with store.db(write=True) as db:
            own = _actor(db, body.actor_id, user)
            other = _peer(db, own, body.target_id)
            row = db.execute("SELECT r.* FROM rooms r WHERE r.kind='direct' "
                'AND (SELECT COUNT(*) FROM members m WHERE m.room_id=r.id)=2 '
                'AND EXISTS(SELECT 1 FROM members m WHERE m.room_id=r.id AND m.actor_id=?) '
                'AND EXISTS(SELECT 1 FROM members m WHERE m.room_id=r.id AND m.actor_id=?) '
                'ORDER BY r.created,r.id LIMIT 1', (own['id'], other['id'])).fetchone()
            if not row:
                from .app import AIIn
                rid = secrets.token_hex(12)
                ai = AIIn().model_dump()
                ai.update(auto_count=0, last_ai=0, turn=0, paused=False, lease=None)
                db.execute('INSERT INTO rooms VALUES(?,?,?,?,?,?)',
                           (rid, own['name'] + ' · ' + other['name'], 'direct', user,
                            json.dumps(ai, ensure_ascii=False, separators=(',', ':')), time.time()))
                db.executemany('INSERT INTO members VALUES(?,?)', [(rid, own['id']), (rid, other['id'])])
                row = db.execute('SELECT * FROM rooms WHERE id=?', (rid,)).fetchone()
            db.executemany('INSERT OR IGNORE INTO friendships VALUES(?,?)',
                           [(own['id'], other['id']), (other['id'], own['id'])])
            pair = sorted((own['id'], other['id']))
            _put(db, FRIEND_PREFIX + _digest(*pair), pair)
            bind_social_room(db, row['id'], [pair])
            result = _room_view(db, row)
        background.add_task(hub.emit, [user, other['owner_id']], {'type': 'rooms.changed'})
        background.add_task(hub.emit, [user, other['owner_id']], {'type': 'friends.changed'})
        return result

    @app.post('/api/ai-social/actions/claim')
    def claim_action(body: ActionIn, user=Depends(auth)):
        with store.db(write=True) as db:
            own = _actor(db, body.actor_id, user)
            _check(_policy(db, own['id'])['enabled'], '请先启用这个公开 AI 的自主活动')
            _valid_source(db, own, body)
            current = time.time()
            previous = _meta(db, _action_key(body), {})
            if not isinstance(previous, dict):
                previous = {}
            _check(not (previous.get('status') == 'done' and body.action != 'post'),
                   '这个公开内容已处理，请勿重复提交', 409)
            _check(not (previous.get('status') == 'running' and previous.get('expires', 0) > current),
                   '其他设备正在处理这个任务', 409)
            cooldown = _meta(db, _cooldown_key(body), {})
            until = cooldown.get('until', 0) if isinstance(cooldown, dict) else 0
            _check(until <= current, '这个 AI 正在休息，请稍后再试', 409)
            lease = secrets.token_urlsafe(32)
            expires = current + LEASE_SECONDS
            _put(db, _action_key(body), {'actor_id': body.actor_id, 'action': body.action,
                 'source_id': body.source_id, 'status': 'running', 'claimed': current,
                 'expires': expires, 'lease_hash': _digest(lease)})
            _put(db, _cooldown_key(body), {'until': current + COOLDOWNS[body.action]})
            return {'lease': lease, 'expires': expires}

    @app.post('/api/ai-social/actions/complete')
    def complete_action_route(body: ActionComplete, user=Depends(auth)):
        with store.db(write=True) as db:
            return complete_action(db, user, body.actor_id, body.action, body.source_id, body.lease, body.result_id)

    @app.post('/api/ai-social/actions/release')
    def release_action(body: ActionLease, user=Depends(auth)):
        with store.db(write=True) as db:
            current = time.time()
            value = _current_lease(db, body, user, current)
            value.update(status='released', released=current)
            value.pop('lease_hash', None)
            value.pop('expires', None)
            _put(db, _action_key(body), value)
        return {'ok': True}
