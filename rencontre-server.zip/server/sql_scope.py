"""Namespace trusted application SQL without rewriting data or SQL strings.

An archive's tables, indices and foreign keys share a deterministic prefix in
the same persistent database. Only known schema identifiers are transformed;
values always remain parameters. This is not a general purpose SQL sandbox.
"""
import re


OBJECTS=set('''actors actors_owner coin_ledger comments comments_post community_meta
community_posts community_posts_channel community_preferences couple_daily
couple_members couple_memories couples dramas follows friend_requests friendships
games heart_wall hearts image_variants images invitations likes likes_post members
members_actor memories memories_actor message_details messages messages_room
model_usage moods notifications notifications_owner npc_actions npc_actions_time
npc_goals npcs poll_votes post_tags post_tags_tag posts posts_actor reactions
recruit_members red_flags relationships reports reputations requests_target
room_profiles room_reads rooms schema_migrations sessions subscriptions users
wallets npc_memory_sources npc_memory_vectors npc_jobs npc_public_events
npc_public_events_actor npc_jobs_due npc_memory_scope npc_memory_source
npc_event_time npc_memory_source_room npc_memory_source_subject'''.split())

TOKENS=re.compile(r"--[^\r\n]*|/\*[\s\S]*?\*/|'(?:''|[^'])*'|\"(?:\"\"|[^\"])*\"|`(?:``|[^`])*`|\[[^\]]*\]|[A-Za-z_][A-Za-z_0-9]*",re.M)
DEFINITION=re.compile(r'\b(?:CREATE\s+(?:UNIQUE\s+)?(?:TABLE|INDEX)\s+(?:IF\s+NOT\s+EXISTS\s+)?|DROP\s+(?:TABLE|INDEX)\s+(?:IF\s+EXISTS\s+)?)([A-Za-z_]\w*)',re.I)
QUERY_TOKENS=re.compile(TOKENS.pattern+r'|[();]',re.M)


def _result_alias_references(sql):
    # Trusted application SQL uses explicit AS result aliases. Track SELECT
    # scopes, not a global alias set: FROM posts and posts.seq are still objects
    # even when this SELECT (or a nested one) has a result named posts.
    scope=None
    stack=[]
    previous=''
    references=set()
    for match in QUERY_TOKENS.finditer(sql):
        value=match.group(0)
        if value.startswith(('--','/*')):continue
        word=value.upper()
        if value=='(':
            stack.append(scope)
        elif value==')':
            scope=stack.pop() if stack else None
        elif value==';':
            scope=None
            stack=[]
        elif value.startswith("'"):
            pass
        elif word=='SELECT':
            outputs=scope['outputs'] if scope and scope['depth']==len(stack) and scope.get('compound') else set()
            scope={'depth':len(stack),'clause':'SELECT','aliases':set(),'outputs':outputs}
        elif scope:
            name=(value[1:-1] if value[0] in ('"','`','[') else value).lower()
            if len(stack)==scope['depth']:
                if word in ('FROM','WHERE','GROUP','HAVING','ORDER','LIMIT','WINDOW'):
                    scope['clause']=word
                elif word in ('UNION','INTERSECT','EXCEPT'):
                    scope['compound']=True
                elif previous=='AS' and scope['clause']=='SELECT':
                    scope['aliases'].add(name)
                    scope['outputs'].add(name)
            aliases=scope['outputs'] if scope['clause']=='ORDER' else scope['aliases']
            if scope['clause'] in ('GROUP','HAVING','ORDER') and name in aliases and not sql[match.end():].lstrip().startswith('.'):
                references.add(match.start())
        previous=word
    return references


class ScopedCursor:
    def __init__(self,owner,cursor):self.owner,self.raw=owner,cursor
    def __getattr__(self,name):return getattr(self.raw,name)
    def execute(self,sql,parameters=()):
        self.raw.execute(self.owner.rewrite(sql),parameters)
        return self
    def executemany(self,sql,parameters):
        self.raw.executemany(self.owner.rewrite(sql),parameters)
        return self
    def executescript(self,sql):
        self.raw.executescript(self.owner.rewrite(sql))
        return self
    def __iter__(self):return iter(self.raw)
    def __next__(self):return next(self.raw)


class ScopedConnection:
    def __init__(self,connection,prefix):
        if not re.fullmatch(r'w_[a-f0-9]{16,64}_',prefix):raise ValueError('Invalid archive namespace')
        self.raw,self.prefix=connection,prefix
        self.objects=set(OBJECTS)

    def __getattr__(self,name):return getattr(self.raw,name)

    @property
    def row_factory(self):return self.raw.row_factory
    @row_factory.setter
    def row_factory(self,value):self.raw.row_factory=value

    def rewrite(self,sql):
        # Definitions are authored by this application, never by an API caller.
        # Register future migration indices/tables so they cannot share names.
        self.objects.update(name.lower() for name in DEFINITION.findall(sql))
        metadata=bool(re.search(r'\bsqlite_master\b|\bsqlite_schema\b',sql,re.I))
        alias_references=_result_alias_references(sql)
        previous=''
        def token(match):
            nonlocal previous
            value=match.group(0)
            if value.startswith(('--','/*')):return value
            before=previous
            previous=value.upper()
            if value.startswith("'"):
                inner=value[1:-1]
                return "'"+self.prefix+inner+"'" if metadata and inner.lower() in self.objects else value
            if match.start() in alias_references:return value
            if value[0] in ('"','`','['):
                inner=value[1:-1]
                return value[0]+self.prefix+inner+value[-1] if inner.lower() in self.objects and before!='AS' and not sql[:match.start()].rstrip().endswith('.') else value
            return self.prefix+value if value.lower() in self.objects and before!='AS' and not sql[:match.start()].rstrip().endswith('.') else value
        return TOKENS.sub(token,sql)

    def cursor(self):return ScopedCursor(self,self.raw.cursor())
    def execute(self,sql,parameters=()):return self.raw.execute(self.rewrite(sql),parameters)
    def executemany(self,sql,parameters):return self.raw.executemany(self.rewrite(sql),parameters)
    def executescript(self,sql):return self.raw.executescript(self.rewrite(sql))
    def execute_batch(self,statements):
        statements=[(self.rewrite(sql),parameters) for sql,parameters in statements]
        batch=getattr(self.raw,'execute_batch',None)
        if batch:return batch(statements)
        for sql,parameters in statements:self.raw.execute(sql,parameters)
    def query_batch(self,statements):
        statements=[(self.rewrite(sql),parameters) for sql,parameters in statements]
        batch=getattr(self.raw,'query_batch',None)
        if batch:return batch(statements)
        return [self.raw.execute(sql,parameters).fetchall() for sql,parameters in statements]
    def __enter__(self):
        self.raw.__enter__()
        return self
    def __exit__(self,*args):return self.raw.__exit__(*args)
