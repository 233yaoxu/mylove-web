"""Durable, signed NPC wake-ups; platform I/O always happens after commit."""
import hashlib
import hmac
import json
import logging
import os
import re
import secrets
import time
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass

from fastapi import HTTPException


log = logging.getLogger('rencontre.dispatch')
_HEX64 = re.compile(r'[a-f0-9]{64}\Z')
_HEX32 = re.compile(r'[a-f0-9]{32}\Z')
_FIELDS = {'version', 'job_id', 'nonce', 'issued_at', 'expires_at', 'signature'}
COOLDOWN = 30
RETRY_DELAY = 5
ENVELOPE_LIFETIME = 300
ACTIVITY_LEASE = 180
_execution = ContextVar('rencontre_npc_execution', default=None)


class DispatchCancelled(BaseException):
    """Stop a revoked worker through provider fallback handlers.

    This deliberately bypasses broad ``except Exception`` fallbacks. Store.db
    must roll back BaseException too; a cancellation never permits a commit.
    """


@dataclass(frozen=True)
class _Authorization:
    store: object
    job_id: str
    lease_token: str
    user: str
    session_hash: str
    digest: str


@contextmanager
def _fenced_tick(store, job, lease_token):
    authorization = _Authorization(store, job['id'], lease_token, job['user_id'],
                                   job['session_hash'], job['world_digest'])
    token = _execution.set(authorization)
    try:
        yield
    finally:
        _execution.reset(token)


def _assert_authorized(db, authorization):
    """Read root authority on the *same connection* as a business transaction."""
    stamp = time.time()
    try:
        valid = db.execute('''SELECT 1 FROM npc_dispatch_jobs j
 JOIN sessions s ON s.hash=j.session_hash AND s.user_id=j.user_id
 JOIN users u ON u.id=j.user_id
 WHERE j.id=? AND j.lease_token=? AND j.state='running' AND j.lease_until>?
 AND j.user_id=? AND j.session_hash=? AND j.world_digest=? AND s.expires>?
 AND (j.world_digest='' OR EXISTS(SELECT 1 FROM archive_world_registry r
     WHERE r.digest=j.world_digest AND r.user_id=j.user_id))''',
                           (authorization.job_id, authorization.lease_token, stamp,
                            authorization.user, authorization.session_hash, authorization.digest,
                            stamp)).fetchone()
    except Exception:
        # Failure to verify authority is closed; raw database diagnostics may
        # contain connection details and do not belong in cancellation output.
        raise DispatchCancelled() from None
    if not valid:
        raise DispatchCancelled()


def guard_write(raw_connection, namespace):
    """Fence a worker after BEGIN IMMEDIATE and again immediately before commit.

    The raw connection sees the root authority tables even when the caller's
    business queries use ScopedConnection. The write lock makes the check and
    business commit atomic against a replacement worker's claim or a logout.
    """
    authorization = _execution.get()
    if authorization is None:
        return
    expected = 'w_' + authorization.digest + '_' if authorization.digest else ''
    # A private tick also legitimately writes the root global model budget.
    if namespace not in ('', expected):
        raise DispatchCancelled()
    _assert_authorized(raw_connection, authorization)


def checkpoint():
    """Stop revoked workers between stages and before additional model I/O.

    Called outside write transactions only. Commit authority is independently
    checked by guard_write in each business transaction, not by this read.
    """
    authorization = _execution.get()
    if authorization is None:
        return
    with authorization.store.db() as db:
        _assert_authorized(db, authorization)


def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True,
                      allow_nan=False).encode()


class Dispatcher:
    """Root-only outbox shared by all cold instances and archive children.

    submit(envelope, request_key) must perform its bounded platform call without
    retaining the request key, and return an execution ID or its {$id: ...} dict.
    """

    def __init__(self, root, submit):
        self.root, self.store, self.submit = root, root.state.store, submit
        if self.store.namespace:
            raise ValueError('Dispatcher requires the root store')
        self.secret = os.environ.get('RENCONTRE_APPWRITE_SIGNING_KEY', '')
        if len(self.secret.encode()) < 32:
            raise ValueError('RENCONTRE_APPWRITE_SIGNING_KEY must contain at least 32 bytes')
        snapshot=getattr(self.store,'schema_snapshot',None)
        if snapshot is not None and 'npc_dispatch_jobs' in snapshot['objects']:return
        with self.store.db(write=True) as db:
            db.execute('''CREATE TABLE IF NOT EXISTS npc_dispatch_jobs(
 id TEXT PRIMARY KEY,scope_key TEXT NOT NULL UNIQUE,user_id TEXT NOT NULL,
 world_digest TEXT NOT NULL,session_hash TEXT NOT NULL,nonce TEXT NOT NULL,
 state TEXT NOT NULL,created REAL NOT NULL,not_before REAL NOT NULL,
 submitted_at REAL NOT NULL DEFAULT 0,last_started REAL NOT NULL DEFAULT 0,
 lease_token TEXT NOT NULL DEFAULT '',lease_until REAL NOT NULL DEFAULT 0,
 attempts INTEGER NOT NULL DEFAULT 0,execution_id TEXT NOT NULL DEFAULT '')''')

    def _signature(self, body):
        return hmac.new(self.secret.encode(), _canonical(body), hashlib.sha256).hexdigest()

    def _envelope(self, job_id, nonce, stamp):
        body = {'version': 1, 'job_id': job_id, 'nonce': nonce, 'issued_at': int(stamp),
                'expires_at': int(stamp) + ENVELOPE_LIFETIME}
        return dict(body, signature=self._signature(body))

    def _verify(self, envelope):
        try:
            if not isinstance(envelope, dict) or set(envelope) != _FIELDS:
                raise ValueError()
            if len(_canonical(envelope)) > 2048:
                raise ValueError()
            body = {key: value for key, value in envelope.items() if key != 'signature'}
            if type(body['version']) is not int or body['version'] != 1:
                raise ValueError()
            for key in ('job_id', 'nonce'):
                if not isinstance(body[key], str) or not _HEX32.fullmatch(body[key]):
                    raise ValueError()
            issued, expires = body['issued_at'], body['expires_at']
            stamp = time.time()
            if (type(issued) is not int or type(expires) is not int or issued > stamp + 30
                    or not issued < expires or expires - issued > ENVELOPE_LIFETIME or expires <= stamp):
                raise ValueError()
            signature = envelope['signature']
            if (not isinstance(signature, str) or not _HEX64.fullmatch(signature)
                    or not hmac.compare_digest(signature, self._signature(body))):
                raise ValueError()
            return body
        except (ValueError, TypeError, OverflowError, RecursionError):
            raise HTTPException(403, '内部任务签名无效或已过期') from None

    @staticmethod
    def _identity(db, user, session_hash, digest, stamp):
        if (not isinstance(user, str) or not user or not isinstance(session_hash, str)
                or not _HEX64.fullmatch(session_hash)):
            raise HTTPException(401, '登录已过期，请重新登录')
        session = db.execute('SELECT * FROM sessions WHERE hash=? AND user_id=? AND expires>?',
                             (session_hash, user, stamp)).fetchone()
        identity = db.execute('SELECT id,username,created FROM users WHERE id=?', (user,)).fetchone()
        if not session or not identity:
            raise HTTPException(401, '登录已过期，请重新登录')
        if digest:
            if not isinstance(digest, str) or not _HEX64.fullmatch(digest):
                raise HTTPException(403, '存档任务范围无效')
            registered = db.execute('SELECT 1 FROM archive_world_registry WHERE digest=? AND user_id=?',
                                    (digest, user)).fetchone()
            if not registered:
                raise HTTPException(403, '存档任务不属于此账号')
        elif digest != '':
            raise HTTPException(403, '存档任务范围无效')
        return dict(identity), dict(session)

    @staticmethod
    def _response(*, scheduled=False, queued=False, enabled=True):
        return {'ok': True, 'scheduled': scheduled, 'queued': queued,
                'mode': 'on-demand', 'enabled': enabled}

    def schedule(self, user, session_hash, digest, request_key):
        stamp = time.time()
        enabled = bool(self.root.state.npc_engine.enabled)
        envelope = None
        with self.store.db(write=True) as db:
            self._identity(db, user, session_hash, digest, stamp)
            if not enabled:
                return self._response(enabled=False)
            scope = 'world:' + digest if digest else 'root'
            previous = db.execute('SELECT * FROM npc_dispatch_jobs WHERE scope_key=?', (scope,)).fetchone()
            if previous:
                prior = dict(previous)
                if prior['state'] == 'running' and prior['lease_until'] > stamp:
                    return self._response(queued=True)
                if prior['state'] in ('queued', 'submitted', 'running'):
                    try:
                        self._identity(db, prior['user_id'], prior['session_hash'], prior['world_digest'], stamp)
                    except HTTPException:
                        db.execute("UPDATE npc_dispatch_jobs SET state='cancelled' WHERE id=?", (prior['id'],))
                        prior['state'] = 'cancelled'
                if prior['state'] in ('queued', 'submitted', 'running'):
                    # A submit reservation prevents concurrent HTTP callers from
                    # duplicating platform I/O. Accepted requests wait for expiry.
                    delay = ENVELOPE_LIFETIME if prior['state'] == 'submitted' else RETRY_DELAY
                    if prior['state'] != 'running' and stamp - prior['submitted_at'] < delay:
                        return self._response(queued=True)
                    job_id = prior['id']
                else:
                    if stamp < max(prior['not_before'], prior['last_started'] + COOLDOWN):
                        return self._response()
                    job_id = secrets.token_hex(16)
            else:
                job_id = secrets.token_hex(16)
            nonce = secrets.token_hex(16)
            if not previous or job_id != previous['id']:
                db.execute('''INSERT INTO npc_dispatch_jobs
 (id,scope_key,user_id,world_digest,session_hash,nonce,state,created,not_before,submitted_at)
 VALUES(?,?,?,?,?,?,'queued',?,?,?)
 ON CONFLICT(scope_key) DO UPDATE SET id=excluded.id,user_id=excluded.user_id,
 world_digest=excluded.world_digest,session_hash=excluded.session_hash,nonce=excluded.nonce,
 state='queued',created=excluded.created,not_before=excluded.not_before,
 submitted_at=excluded.submitted_at,last_started=0,lease_token='',lease_until=0,
 attempts=0,execution_id='' ''',
                           (job_id, scope, user, digest, session_hash, nonce, stamp, stamp + COOLDOWN, stamp))
            else:
                db.execute("UPDATE npc_dispatch_jobs SET state='queued',nonce=?,submitted_at=?,"
                           "lease_token='',lease_until=0,execution_id='' WHERE id=?",
                           (nonce, stamp, job_id))
            envelope = self._envelope(job_id, nonce, stamp)
        if not request_key:
            return self._response(queued=True)
        # Never hold a Turso/SQLite transaction during the platform request.
        try:
            execution = self.submit(envelope, request_key)
            if isinstance(execution, dict):
                execution = execution.get('$id', '')
            if not isinstance(execution, str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,63}', execution):
                raise ValueError('Invalid execution identifier')
        except Exception:
            log.warning('NPC dispatch submission failed; retrying on a later activity request')
            return self._response(queued=True)
        with self.store.db(write=True) as db:
            # The worker can claim or finish before the REST response returns.
            db.execute("UPDATE npc_dispatch_jobs SET state='submitted',execution_id=? "
                       "WHERE id=? AND nonce=? AND state='queued'",
                       (execution, envelope['job_id'], envelope['nonce']))
        return self._response(scheduled=True, queued=True)

    def handle_worker(self, envelope):
        body = self._verify(envelope)
        stamp = time.time()
        token = secrets.token_hex(16)
        with self.store.db(write=True) as db:
            row = db.execute('SELECT * FROM npc_dispatch_jobs WHERE id=?', (body['job_id'],)).fetchone()
            if not row or row['nonce'] != body['nonce']:
                return {'ok': True, 'status': 'duplicate'}
            job = dict(row)
            if job['state'] not in ('queued', 'submitted'):
                return {'ok': True, 'status': 'duplicate'}
            try:
                identity, session = self._identity(db, job['user_id'], job['session_hash'],
                                                   job['world_digest'], stamp)
            except HTTPException:
                db.execute("UPDATE npc_dispatch_jobs SET state='cancelled' WHERE id=?", (job['id'],))
                return {'ok': True, 'status': 'cancelled'}
            changed = db.execute("UPDATE npc_dispatch_jobs SET state='running',lease_token=?,lease_until=?,"
                                 "last_started=?,attempts=attempts+1 WHERE id=? AND nonce=? "
                                 "AND state IN ('queued','submitted')",
                                 (token, stamp + ACTIVITY_LEASE, stamp, job['id'], job['nonce'])).rowcount
            if not changed:
                return {'ok': True, 'status': 'duplicate'}
        world = None
        engine = self.root.state.npc_engine
        state = 'completed'
        try:
            if job['world_digest']:
                acquired = self.root.state.archive_worlds.acquire_registered_digest(
                    job['world_digest'], identity, session)
                world = acquired[0] if isinstance(acquired, tuple) else acquired
                engine = world.app.state.npc_engine
            # Recheck exact session immediately before model work, after any
            # child initialization/network round trips.
            with self.store.db() as db:
                self._identity(db, job['user_id'], job['session_hash'], job['world_digest'], time.time())
            if engine.enabled:
                # A platform coroutine timeout cannot kill its Python thread.
                # All business writes and model stages retain this lease fence.
                with _fenced_tick(self.store, job, token):
                    checkpoint()
                    engine.tick(job['user_id'])
            engine.last_error = False
        except DispatchCancelled:
            state = 'cancelled'
        except HTTPException:
            state = 'cancelled'
        except Exception:
            state = 'failed'
            engine.last_error = True
            log.warning('NPC dispatch activity failed; retrying on a later activity request')
        finally:
            if world is not None:
                self.root.state.archive_worlds.release(world)
            with self.store.db(write=True) as db:
                changed = db.execute("UPDATE npc_dispatch_jobs SET state=?,lease_token='',lease_until=0 "
                                     "WHERE id=? AND lease_token=? AND state='running'",
                                     (state, job['id'], token)).rowcount
        return {'ok': True, 'status': state if changed else 'superseded'}
