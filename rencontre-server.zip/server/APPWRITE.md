# Appwrite Functions

The HTTP adapter uses the existing Turso database and account sessions. NPC
activity is submitted to an asynchronous execution of the same function. Local
hosting continues to use the existing background runner.

Deploy a source-only tar.gz with a root `main.py` containing:

```python
from .rencontre_backend.appwrite_entry import main
```

Copy the source `server/` modules into a package named `rencontre_backend/` in
the archive, keeping its `__init__.py`. Appwrite loads the entrypoint as
`function.main`, so its sibling package must use this relative import. The
runtime also owns a top-level module named `server`.
The root `requirements.txt` can contain
`-r rencontre_backend/requirements-cloud.txt`. Select Python
3.12, entrypoint `main.py`, build command `pip install -r requirements.txt`, and
the available Free compute specification. Use the automatic HTTPS domain.

Set the function execution timeout to **90 seconds**. The durable worker lease
is 180 seconds, but a runtime timeout can cancel only its waiting coroutine:
Python model/database work in a thread may continue. Safety comes from a
cooperative database fence, rather than assuming that the timeout kills a
thread. HTTP domain requests remain subject to Appwrite's separate
30-second limit. Do not enable scheduled execution or email triggers. Grant only
the `executions.write` scope to its ephemeral key. Public execute access is
needed for app clients; business API routes still verify Rencontre sessions.

Create secret environment variables through the console:

- `RENCONTRE_TURSO_URL` and `RENCONTRE_TURSO_AUTH_TOKEN`: the community database.
- `RENCONTRE_NPC_API_URL` and `RENCONTRE_NPC_API_KEY`: the private model provider.
- `RENCONTRE_APPWRITE_SIGNING_KEY`: an independent random value of at least 32
  bytes, used only to sign short-lived worker envelopes.

Set `RENCONTRE_NPC_ENABLED=1` and `RENCONTRE_SERVERLESS=1`. Keep daily token
budgets bounded. The adapter also forces serverless mode so missing remote
storage fails closed. Do not put credentials in a tar.gz, repository, APK, static
site, URL, execution body, or log. Appwrite injects its API endpoint, project ID,
function ID, and per-execution key; no persistent Appwrite API key is needed.

Every dispatched tick carries its own job and lease token in a private execution
context. Each business write transaction checks the current root job, lease
deadline, exact root session, and archive ownership on the same database
connection immediately after acquiring the write lock and again before commit.
A revoked or replaced worker rolls back; it cannot finish model accounting,
insert a reply, or apply life/game effects. The private namespace is checked too;
the root namespace is permitted for the shared model budget. Model requests and
tick stages recheck authority outside write transactions, and cancellation
bypasses provider fallback handlers. Local hosting without this context is
unchanged. The platform execution key is not part of a worker's context.

Before changing the app's default address, verify on the real host:

1. An independent probe reaches the provider and completes an async callback.
2. `/api/health` returns the cloud/polling capabilities without credentials.
3. Registration/login, model catalog, and a real NPC reply work with a disposable
   verification account; the HTTP activity call returns before model generation.
4. Human friends stay shared while NPC identities/preferences differ between two
   saves; a revoked session cannot execute a queued worker. Local regressions also
   cover a live old thread resuming after lease replacement and expiry between
   a business write and its commit, including the actual Hrana HTTP driver.

Keep the previous production address until verification passes. Appwrite Free
may pause a project after a week without activity and has usage quotas; it is
not a permanent background process. The on-demand queue advances a logged-in
player's residents while their community client is active.
