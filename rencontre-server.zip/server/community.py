"""Shared community features for both Rencontre appearances.

All mutations use the authenticated owner and the same SQLite transaction as
the original API. Private character prompts and model credentials stay local.
"""
import hashlib
import json
import secrets
import time
from datetime import datetime, timezone, timedelta

from fastapi import BackgroundTasks, Depends, HTTPException, Request
from pydantic import BaseModel, ConfigDict, Field


def uid(): return secrets.token_hex(12)
def pack(value): return json.dumps(value, ensure_ascii=False, separators=(',', ':'))
def check(value, message, status=400):
    if not value: raise HTTPException(status, message)
def today(): return datetime.now(timezone(timedelta(hours=8))).strftime('%Y-%m-%d')


class Strict(BaseModel): model_config = ConfigDict(extra='forbid')
class Choice(Strict): choice: int = Field(ge=0, le=3)
class Reaction(Strict): reaction: str = Field(max_length=20)
class CoupleIn(Strict):
    actor_id: str
    target_id: str
    cp_name: str = Field(min_length=1, max_length=24)
class Accept(Strict): accept: bool
class Daily(Strict): task: str = Field(max_length=30)
class Gift(Strict):
    target_id: str
    gift: str = Field(max_length=20)
class Heart(Strict): target_id: str
class PostShare(Strict): post_id: str
class WallIn(Strict):
    text: str = Field(min_length=1, max_length=300)
    anonymous: bool = True
class ResponseIn(Strict): text: str = Field(min_length=1, max_length=500)
class Report(Strict):
    target_kind: str
    target_id: str = Field(max_length=100)
    reason: str = Field(max_length=30)
    description: str = Field(default='', max_length=500)
class Preferences(Strict):
    quiet: bool = False
    drama: bool = True
    mood: str = Field(default='今天也想遇见有趣的人', max_length=60)
class Moderation(Strict): status: str


class Community:
    KINDS = ('daily', 'poll', 'anon', 'gossip', 'redflag', 'recruit', 'essay', 'bulletin', 'official', 'fishing')
    CHANNELS = ('daily', 'gossip', 'love', 'dating', 'buddies', 'gaming', 'vent', 'treehole', 'poll', 'emo', 'redflag', 'cp')
    GIFTS = {'flower': ('一朵小花', 3), 'tea': ('温热奶茶', 10), 'firework': ('心动烟花', 30)}
    TASKS = {'question': '每日一问', 'greeting': '互道早晚安', 'share': '分享今天的小事'}
    REACTIONS = ('🍉', '❤️', '😂', '😱', '🤔', '抱抱', '警惕')

    def __init__(self, app, context):
        self.app = app
        for key, value in context.items(): setattr(self, key, value)
        with self.store.db(write=True) as db:
            db.executescript('''
CREATE TABLE IF NOT EXISTS community_meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS community_posts(post_id TEXT PRIMARY KEY,post_kind TEXT NOT NULL,channel TEXT NOT NULL,poll_json TEXT NOT NULL DEFAULT '[]',capacity INTEGER NOT NULL DEFAULT 4,recruit_type TEXT NOT NULL DEFAULT '',closed INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS poll_votes(post_id TEXT,user_id TEXT,choice INTEGER,PRIMARY KEY(post_id,user_id));
CREATE TABLE IF NOT EXISTS reactions(post_id TEXT,user_id TEXT,reaction TEXT,PRIMARY KEY(post_id,user_id));
CREATE TABLE IF NOT EXISTS subscriptions(post_id TEXT,user_id TEXT,PRIMARY KEY(post_id,user_id));
CREATE TABLE IF NOT EXISTS recruit_members(post_id TEXT,user_id TEXT,created REAL,PRIMARY KEY(post_id,user_id));
CREATE TABLE IF NOT EXISTS couples(id TEXT PRIMARY KEY,a_actor TEXT,b_actor TEXT,cp_name TEXT,status TEXT,since REAL,intimacy INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS couple_daily(couple_id TEXT,user_id TEXT,day TEXT,task TEXT,PRIMARY KEY(couple_id,user_id,day,task));
CREATE TABLE IF NOT EXISTS couple_memories(id TEXT PRIMARY KEY,couple_id TEXT,text TEXT,created REAL);
CREATE TABLE IF NOT EXISTS hearts(source TEXT,target TEXT,created REAL,PRIMARY KEY(source,target));
CREATE TABLE IF NOT EXISTS heart_wall(id TEXT PRIMARY KEY,actor_id TEXT,text TEXT,anonymous INTEGER,created REAL);
CREATE TABLE IF NOT EXISTS wallets(actor TEXT PRIMARY KEY,coins INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS coin_ledger(id TEXT PRIMARY KEY,actor TEXT,delta INTEGER,reason TEXT,ref TEXT,created REAL,UNIQUE(actor,reason,ref));
CREATE TABLE IF NOT EXISTS red_flags(id TEXT PRIMARY KEY,target_actor TEXT,category TEXT,description TEXT,evidence_kind TEXT,post_id TEXT,response TEXT NOT NULL DEFAULT '',status TEXT,created REAL);
CREATE TABLE IF NOT EXISTS reputations(actor TEXT PRIMARY KEY,score INTEGER NOT NULL DEFAULT 60);
CREATE TABLE IF NOT EXISTS relationships(a_actor TEXT,b_actor TEXT,type TEXT,intimacy REAL DEFAULT 0,trust REAL DEFAULT 60,romance REAL DEFAULT 0,grudge REAL DEFAULT 0,since REAL,updated_at REAL,PRIMARY KEY(a_actor,b_actor));
CREATE TABLE IF NOT EXISTS moods(actor TEXT PRIMARY KEY,happy REAL DEFAULT 60,angry REAL DEFAULT 0,hurt REAL DEFAULT 0,jealous REAL DEFAULT 0,excited REAL DEFAULT 30,down REAL DEFAULT 0,bored REAL DEFAULT 10,love_brain REAL DEFAULT 0,updated_at REAL);
CREATE TABLE IF NOT EXISTS memories(id TEXT PRIMARY KEY,actor TEXT,kind TEXT,subject_actor TEXT,summary TEXT,importance INTEGER,created_at REAL,expires_at REAL);
CREATE TABLE IF NOT EXISTS npcs(actor TEXT PRIMARY KEY,tier TEXT,persona_json TEXT,schedule_json TEXT,heartbeat_at REAL,active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS npc_actions(id TEXT PRIMARY KEY,actor TEXT,action TEXT,created REAL);
CREATE TABLE IF NOT EXISTS npc_goals(id TEXT PRIMARY KEY,actor TEXT,goal_type TEXT,target_actor TEXT,progress REAL,expires_at REAL);
CREATE TABLE IF NOT EXISTS dramas(id TEXT PRIMARY KEY,script_kind TEXT,cast_json TEXT,stage INTEGER,next_beat_at REAL,params_json TEXT,status TEXT);
CREATE TABLE IF NOT EXISTS model_usage(id TEXT PRIMARY KEY,provider TEXT,task TEXT,tokens INTEGER,fallback INTEGER,created REAL);
CREATE TABLE IF NOT EXISTS community_preferences(user_id TEXT PRIMARY KEY,quiet INTEGER DEFAULT 0,drama INTEGER DEFAULT 1,mood TEXT DEFAULT '今天也想遇见有趣的人');
CREATE TABLE IF NOT EXISTS reports(id TEXT PRIMARY KEY,user_id TEXT,target_kind TEXT,target_id TEXT,reason TEXT,description TEXT,status TEXT,created REAL);
CREATE TABLE IF NOT EXISTS message_details(message_id TEXT PRIMARY KEY,kind TEXT DEFAULT '',reply_to TEXT DEFAULT '',post_id TEXT DEFAULT '');
CREATE INDEX IF NOT EXISTS npc_actions_time ON npc_actions(actor,created);
CREATE INDEX IF NOT EXISTS community_posts_channel ON community_posts(channel,post_kind);
CREATE INDEX IF NOT EXISTS memories_actor ON memories(actor,created_at);
CREATE INDEX IF NOT EXISTS couple_members ON couples(a_actor,b_actor,status);
''')
            db.execute("INSERT OR IGNORE INTO community_meta VALUES('schema','1.5')")
        self.routes()

    @staticmethod
    def heat_sql(alias='p'):
        return (f'(1+2*(SELECT COUNT(*) FROM comments c WHERE c.post_id={alias}.id)'
                f'+(SELECT COUNT(*) FROM likes l WHERE l.post_id={alias}.id)'
                f'+3*(SELECT COUNT(*) FROM posts r WHERE r.repost_id={alias}.id)'
                f'+1.5*(SELECT COUNT(*) FROM reactions x WHERE x.post_id={alias}.id))')

    def person(self, db, aid):
        a = self.actor(db, aid)
        npc = db.execute('SELECT tier FROM npcs WHERE actor=?', (aid,)).fetchone()
        if npc: a.update(is_npc=True, tier=npc['tier'])
        return a

    def human(self, db, user):
        a = db.execute("SELECT * FROM actors WHERE owner_id=? AND kind='user'", (user,)).fetchone()
        check(a, '请先创建玩家身份', 409)
        return dict(a)

    def admin(self, db, user):
        first = db.execute("SELECT id FROM users WHERE username<>'__rencontre_residents__' ORDER BY created,id LIMIT 1").fetchone()
        return bool(first and first['id'] == user)

    def create_post(self, db, pid, body):
        check(body.post_kind in self.KINDS and body.channel in self.CHANNELS, '请选择有效的帖子类型和频道')
        options = [x.strip() for x in body.poll_options]
        if body.post_kind == 'poll':
            check(2 <= len(options) <= 4 and all(0 < len(x) <= 60 for x in options) and len(set(options)) == len(options), '投票需要 2–4 个不同选项，每项最多 60 字')
        if body.post_kind == 'redflag':
            raise HTTPException(400, '请通过避雷墙的模板提交，审核后公开')
        check(body.post_kind not in ('bulletin', 'official', 'fishing'), '这个类型由社区剧情自动发布')
        db.execute('INSERT INTO community_posts(post_id,post_kind,channel,poll_json,capacity,recruit_type) VALUES(?,?,?,?,?,?)',
                   (pid, body.post_kind, body.channel, pack(options if body.post_kind == 'poll' else []), body.recruit_capacity, body.recruit_type.strip()))

    def decorate(self, db, post, user):
        return self.decorate_posts(db, [post], user)[0]

    def decorate_posts(self, db, posts, user):
        """Fetch public details once per page, rather than once per feed row.

        These maps belong only to the current transaction and requesting user;
        reactions, votes and subscriptions never enter a shared account cache.
        """
        posts = list(posts)
        if not posts: return []
        ids = list(dict.fromkeys(p['id'] for p in posts))
        related_ids = list(dict.fromkeys(ids + [p['original']['id'] for p in posts if p.get('original')]))
        marks = ','.join('?' for _ in ids)
        related_marks = ','.join('?' for _ in related_ids)
        extensions = {r['id']: dict(r) for r in db.execute(
            'SELECT p.id,cp.*,' + self.heat_sql('p') + ' AS heat FROM posts p '
            'LEFT JOIN community_posts cp ON cp.post_id=p.id WHERE p.id IN (' + related_marks + ')', related_ids)}

        official_actors = list(dict.fromkeys(p['actor_id'] for p in posts
            if extensions[p['id']]['post_kind'] == 'official'))
        couples = {}
        if official_actors:
            actor_marks = ','.join('?' for _ in official_actors)
            for record in db.execute("SELECT * FROM couples WHERE status='active' AND (a_actor IN (" + actor_marks +
                                     ') OR b_actor IN (' + actor_marks + ')) ORDER BY since DESC', official_actors * 2):
                for aid in (record['a_actor'], record['b_actor']): couples.setdefault(aid, dict(record))
        aids = list(dict.fromkeys([p['actor_id'] for p in posts] +
            [cp[column] for cp in couples.values() for column in ('a_actor', 'b_actor')]))
        actor_marks = ','.join('?' for _ in aids)
        people = {}
        for record in db.execute('SELECT a.*,n.tier AS resident_tier FROM actors a '
                                 'LEFT JOIN npcs n ON n.actor=a.id WHERE a.id IN (' + actor_marks + ')', aids):
            person = dict(record)
            tier = person.pop('resident_tier')
            if tier is not None: person.update(is_npc=True, tier=tier)
            people[person['id']] = person

        reactions = {pid: [] for pid in ids}
        own_reactions = {}
        for record in db.execute('SELECT post_id,reaction,COUNT(*) AS count,'
                                 'MAX(CASE WHEN user_id=? THEN 1 ELSE 0 END) AS mine FROM reactions '
                                 'WHERE post_id IN (' + marks + ') GROUP BY post_id,reaction ORDER BY post_id,reaction', [user] + ids):
            reactions[record['post_id']].append({'reaction': record['reaction'], 'count': record['count']})
            if user and record['mine']: own_reactions[record['post_id']] = record['reaction']
        subscribed = {r[0] for r in db.execute('SELECT post_id FROM subscriptions WHERE user_id=? AND '
                      'post_id IN (' + marks + ')', [user] + ids)} if user else set()

        polls = [pid for pid in ids if extensions[pid]['post_kind'] == 'poll']
        poll_counts, own_votes = {}, {}
        if polls:
            poll_marks = ','.join('?' for _ in polls)
            for record in db.execute('SELECT post_id,choice,COUNT(*) AS count,'
                                     'MAX(CASE WHEN user_id=? THEN 1 ELSE 0 END) AS mine FROM poll_votes '
                                     'WHERE post_id IN (' + poll_marks + ') GROUP BY post_id,choice', [user] + polls):
                poll_counts.setdefault(record['post_id'], {})[record['choice']] = record['count']
                if user and record['mine']: own_votes[record['post_id']] = record['choice']
        recruits = [pid for pid in ids if extensions[pid]['post_kind'] == 'recruit']
        recruitment = {}
        if recruits:
            recruit_marks = ','.join('?' for _ in recruits)
            recruitment = {r['post_id']: dict(r) for r in db.execute(
                'SELECT post_id,COUNT(*) AS count,MAX(CASE WHEN user_id=? THEN 1 ELSE 0 END) AS joined '
                'FROM recruit_members WHERE post_id IN (' + recruit_marks + ') GROUP BY post_id', [user] + recruits)}
        flag_ids = [pid for pid in ids if extensions[pid]['post_kind'] == 'redflag']
        flags = {}
        if flag_ids:
            flag_marks = ','.join('?' for _ in flag_ids)
            flags = {r['post_id']: {'response': r['response'], 'status': r['status']} for r in db.execute(
                'SELECT post_id,response,status FROM red_flags WHERE post_id IN (' + flag_marks + ')', flag_ids)}

        result = []
        for post in posts:
            p = dict(post)
            pid = p['id']; ext = extensions[pid]
            p.update(post_kind=ext['post_kind'] or 'daily', channel=ext['channel'] or 'daily')
            p['actor'] = dict(people[p['actor_id']])
            p['is_mine'] = bool(user and p['actor']['owner_id'] == user)
            p['heat'] = ext['heat']
            p['heat_label'] = '名场面' if p['heat'] >= 80 else '爆' if p['heat'] >= 30 else '小热' if p['heat'] >= 10 else ''
            p['reactions'] = reactions[pid]
            p['my_reaction'] = own_reactions.get(pid, '')
            p['subscribed'] = pid in subscribed
            if p['post_kind'] == 'poll':
                options = json.loads(ext['poll_json']); counts = poll_counts.get(pid, {})
                p['poll'] = {'options': options, 'counts': [counts.get(i, 0) for i in range(len(options))],
                             'total': sum(counts.values()), 'my_choice': own_votes.get(pid)}
            if p['post_kind'] == 'recruit':
                recruit = recruitment.get(pid, {}); count = recruit.get('count', 0)
                p['recruit'] = {'capacity': ext['capacity'], 'count': count, 'type': ext['recruit_type'],
                                'closed': bool(ext['closed'] or count >= ext['capacity']), 'joined': bool(user and recruit.get('joined'))}
            if p['post_kind'] == 'official' and p['actor_id'] in couples:
                cp = dict(couples[p['actor_id']])
                cp.update(a=dict(people[cp['a_actor']]), b=dict(people[cp['b_actor']]),
                          days=max(0, int((time.time()-cp['since'])/86400)), level=min(10, 1+cp['intimacy']//30))
                p['couple'] = cp
            if p['post_kind'] == 'redflag' and pid in flags: p['red_flag'] = flags[pid]
            if p.get('original'):
                original = dict(p['original'])
                if extensions[original['id']]['post_kind'] == 'anon':
                    original['author_name'] = self.anon_name(original['id'])
                    original.pop('actor_id', None)
                p['original'] = original
            if p['post_kind'] == 'anon':
                real_id = p['actor_id']; pseudonym = self.anon_name(pid)
                p['actor_id'] = 'anon-' + pid
                p['actor'] = {'id': p['actor_id'], 'name': pseudonym, 'kind': 'anon', 'bio': '', 'avatar_id': '', 'owner_id': ''}
                if 'comments' in p: p['comments'] = [dict(comment) for comment in p['comments']]
                for comment in p.get('comments', []):
                    if comment['actor_id'] == real_id:
                        comment['actor_id'], comment['name'] = p['actor_id'], pseudonym + ' · 楼主'
            result.append(p)
        return result

    @staticmethod
    def anon_name(pid): return ['匿名小西瓜', '匿名小柠檬', '匿名小茄子'][int(hashlib.sha256(pid.encode()).hexdigest()[:6], 16) % 3]

    def notification_view(self, db, item):
        if item.get('post_id'):
            post = db.execute("SELECT p.actor_id FROM posts p JOIN community_posts cp ON cp.post_id=p.id WHERE p.id=? AND cp.post_kind='anon'", (item['post_id'],)).fetchone()
            if post and post['actor_id'] == item['actor_id']:
                item['actor_id'] = 'anon-'+item['post_id']
                item['actor'] = {'id': item['actor_id'], 'name': self.anon_name(item['post_id']), 'kind': 'anon', 'avatar_id': '', 'owner_id': ''}
        return item

    def comment_followups(self, db, pid, aid, user, cid, text, owner_id):
        recipients = [r[0] for r in db.execute('SELECT user_id FROM subscriptions WHERE post_id=? AND user_id NOT IN (?,?)', (pid, user, owner_id))]
        for target in recipients: self.notify(db, target, 'comments', aid, post_id=pid, source_id=cid, text='你蹲的后续有新回复：'+text[:100])
        return recipients

    def delete_post(self, db, pid):
        for table in ('community_posts', 'poll_votes', 'reactions', 'subscriptions', 'recruit_members'):
            db.execute(f'DELETE FROM {table} WHERE post_id=?', (pid,))
        db.execute('DELETE FROM red_flags WHERE post_id=?', (pid,))

    def couple_view(self, db, record):
        r = dict(record)
        r['a'], r['b'] = self.person(db, r['a_actor']), self.person(db, r['b_actor'])
        r['days'] = max(0, int((time.time()-r['since'])/86400))
        r['level'] = min(10, 1+r['intimacy']//30)
        return r

    def create_message(self, db, message, reply_to=''):
        if reply_to:
            check(db.execute('SELECT 1 FROM messages WHERE id=? AND room_id=?', (reply_to, message['room_id'])).fetchone(), '引用消息不在当前聊天', 400)
            db.execute("INSERT INTO message_details(message_id,reply_to) VALUES(?,?)", (message['id'], reply_to))

    def message_view(self, db, message, user):
        return self.message_views(db, [message], user)[0]

    def message_views(self, db, messages, user):
        """Decorate a room's history with bounded database round trips.

        The caller checks room membership. Quotes also join on the same room;
        read receipts count accounts which still own a seat, excluding senders.
        """
        messages = [dict(message) for message in messages]
        if not messages: return []
        ids = list(dict.fromkeys(message['id'] for message in messages))
        marks = ','.join('?' for _ in ids)
        details = {r['id']: dict(r) for r in db.execute(
            'SELECT m.id,d.message_id,d.kind,d.reply_to,d.post_id,'
            '(SELECT COUNT(DISTINCT r.user_id) FROM room_reads r '
            'WHERE r.room_id=m.room_id AND r.seq>=m.seq AND r.user_id<>sender.owner_id '
            'AND EXISTS(SELECT 1 FROM members member JOIN actors a ON a.id=member.actor_id '
            'WHERE member.room_id=r.room_id AND a.owner_id=r.user_id)) AS read_count '
            'FROM messages m JOIN actors sender ON sender.id=m.actor_id '
            'LEFT JOIN message_details d ON d.message_id=m.id WHERE m.id IN (' + marks + ')', ids)}
        quotes = {}
        if any(d['reply_to'] and d['kind'] != 'recalled' for d in details.values()):
            for r in db.execute('SELECT d.message_id,reply.id,reply.text,a.name FROM message_details d '
                                 'JOIN messages current ON current.id=d.message_id '
                                 'JOIN messages reply ON reply.id=d.reply_to AND reply.room_id=current.room_id '
                                 "JOIN actors a ON a.id=reply.actor_id WHERE d.kind<>'recalled' AND d.message_id IN (" + marks + ')', ids):
                quotes[r['message_id']] = {'id': r['id'], 'text': r['text'], 'name': r['name']}
        shared_ids = list(dict.fromkeys(d['post_id'] for d in details.values() if d['post_id'] and d['kind'] != 'recalled'))
        shared_posts = {}
        if shared_ids:
            post_marks = ','.join('?' for _ in shared_ids)
            for preview in self.post_views(db, db.execute('SELECT * FROM posts WHERE id IN (' + post_marks + ')', shared_ids), user):
                shared_posts[preview['id']] = {'id': preview['id'], 'text': preview['text'][:160],
                                              'name': preview['actor']['name'], 'post_kind': preview['post_kind']}
        for message in messages:
            detail = details[message['id']]
            message['read_count'] = detail['read_count']
            if detail['message_id'] is None: continue
            message['kind'] = detail['kind']
            if detail['kind'] == 'recalled': continue
            if message['id'] in quotes: message['reply'] = quotes[message['id']]
            if detail['post_id'] in shared_posts: message['post'] = shared_posts[detail['post_id']]
        return messages

    def credit(self, db, aid, delta, reason, ref):
        db.execute('INSERT OR IGNORE INTO wallets(actor,coins) VALUES(?,0)', (aid,))
        coins = db.execute('SELECT coins FROM wallets WHERE actor=?', (aid,)).fetchone()[0]
        check(coins+delta >= 0, '心动币不足，签到后再来吧', 409)
        db.execute('INSERT INTO coin_ledger VALUES(?,?,?,?,?,?)', (uid(), aid, delta, reason, ref, time.time()))
        db.execute('UPDATE wallets SET coins=coins+? WHERE actor=?', (delta, aid))

    def emit_posts(self, background, pid, action='updated'):
        self.posts_changed(background, pid, action)

    def routes(self):
        app, auth = self.app, self.auth

        def trending(db, limit=10, query=''):
            rows = db.execute('SELECT p.* FROM posts p WHERE instr(lower(p.text),lower(?))>0 ORDER BY '+self.heat_sql('p')+' DESC,p.seq DESC LIMIT ?', (query, limit)).fetchall()
            return self.post_views(db, rows, None)

        @app.get('/api/public/community')
        @app.get('/api/community')
        def summary():
            with self.store.db() as db:
                cps = [self.couple_view(db, r) for r in db.execute("SELECT * FROM couples WHERE status='active' ORDER BY intimacy DESC LIMIT 5")]
                flags = [dict(r) for r in db.execute("SELECT r.*,a.name AS target_name FROM red_flags r JOIN actors a ON a.id=r.target_actor WHERE status='published' ORDER BY created DESC LIMIT 3")]
                melons = self.post_views(db, db.execute("SELECT p.* FROM posts p JOIN community_posts cp ON cp.post_id=p.id WHERE cp.post_kind IN ('gossip','fishing') ORDER BY p.seq DESC LIMIT 3"), None)
                return {'trending': trending(db, 5), 'gossips': melons, 'couples': cps, 'red_flags': flags,
                        'stats': {'residents': db.execute('SELECT COUNT(*) FROM npcs WHERE active=1').fetchone()[0], 'posts': db.execute('SELECT COUNT(*) FROM posts').fetchone()[0], 'couples': len(cps)},
                        'announcement': '这里有玩家和 AI 居民。剧情由虚构角色演出，心动币仅为社区游戏积分。'}

        @app.get('/api/public/trending')
        @app.get('/api/trending')
        def hot(q: str = ''):
            check(len(q) <= 100, '搜索词太长')
            with self.store.db() as db: return trending(db, 10, q)

        @app.get('/api/public/gossips')
        @app.get('/api/gossips')
        def gossips(q: str = ''):
            check(len(q) <= 100, '搜索词太长')
            with self.store.db() as db:
                return self.post_views(db, db.execute("SELECT p.* FROM posts p JOIN community_posts c ON c.post_id=p.id WHERE c.post_kind IN ('gossip','fishing','bulletin') AND instr(lower(p.text),lower(?))>0 ORDER BY p.seq DESC LIMIT 40", (q,)), None)

        @app.post('/api/posts/{pid}/poll')
        def vote(pid: str, body: Choice, background: BackgroundTasks, user=Depends(auth)):
            with self.store.db(write=True) as db:
                ext = db.execute("SELECT poll_json FROM community_posts WHERE post_id=? AND post_kind='poll'", (pid,)).fetchone()
                check(ext, '投票不存在', 404)
                check(body.choice < len(json.loads(ext[0])), '选项不存在')
                check(not db.execute('SELECT 1 FROM poll_votes WHERE post_id=? AND user_id=?', (pid, user)).fetchone(), '你已经投过票了', 409)
                db.execute('INSERT INTO poll_votes VALUES(?,?,?)', (pid, user, body.choice))
                result = self.post_view(db, db.execute('SELECT * FROM posts WHERE id=?', (pid,)).fetchone(), user)
            self.emit_posts(background, pid, 'voted')
            return result

        @app.post('/api/posts/{pid}/react')
        def react(pid: str, body: Reaction, background: BackgroundTasks, user=Depends(auth)):
            check(body.reaction in self.REACTIONS, '表情不存在')
            with self.store.db(write=True) as db:
                post = db.execute('SELECT * FROM posts WHERE id=?', (pid,)).fetchone()
                check(post, '帖子不存在', 404)
                old = db.execute('SELECT reaction FROM reactions WHERE post_id=? AND user_id=?', (pid, user)).fetchone()
                db.execute('DELETE FROM reactions WHERE post_id=? AND user_id=?', (pid, user))
                if not old or old[0] != body.reaction: db.execute('INSERT INTO reactions VALUES(?,?,?)', (pid, user, body.reaction))
                result = self.post_view(db, post, user)
            self.emit_posts(background, pid, 'reacted')
            return result

        @app.post('/api/posts/{pid}/subscribe')
        def subscribe(pid: str, user=Depends(auth)):
            with self.store.db(write=True) as db:
                check(db.execute('SELECT 1 FROM posts WHERE id=?', (pid,)).fetchone(), '帖子不存在', 404)
                exists = db.execute('SELECT 1 FROM subscriptions WHERE post_id=? AND user_id=?', (pid, user)).fetchone()
                if exists: db.execute('DELETE FROM subscriptions WHERE post_id=? AND user_id=?', (pid, user))
                else: db.execute('INSERT INTO subscriptions VALUES(?,?)', (pid, user))
                return {'subscribed': not bool(exists)}

        @app.post('/api/posts/{pid}/recruit')
        def recruit(pid: str, background: BackgroundTasks, user=Depends(auth)):
            with self.store.db(write=True) as db:
                ext = db.execute("SELECT * FROM community_posts WHERE post_id=? AND post_kind='recruit'", (pid,)).fetchone()
                check(ext, '招募不存在', 404)
                joined = db.execute('SELECT 1 FROM recruit_members WHERE post_id=? AND user_id=?', (pid, user)).fetchone()
                if joined: db.execute('DELETE FROM recruit_members WHERE post_id=? AND user_id=?', (pid, user))
                else:
                    count = db.execute('SELECT COUNT(*) FROM recruit_members WHERE post_id=?', (pid,)).fetchone()[0]
                    check(not ext['closed'] and count < ext['capacity'], '这个小队已成团', 409)
                    db.execute('INSERT INTO recruit_members VALUES(?,?,?)', (pid, user, time.time()))
                result = self.post_view(db, db.execute('SELECT * FROM posts WHERE id=?', (pid,)).fetchone(), user)
            self.emit_posts(background, pid, 'recruited')
            return result

        @app.get('/api/public/couples')
        @app.get('/api/couples')
        def couples(q: str = ''):
            check(len(q) <= 100, '搜索词太长')
            with self.store.db() as db:
                return [self.couple_view(db, r) for r in db.execute("SELECT * FROM couples WHERE status='active' AND instr(lower(cp_name),lower(?))>0 ORDER BY intimacy DESC,since DESC LIMIT 40", (q,))]

        @app.get('/api/couples/me')
        def my_couples(user=Depends(auth)):
            with self.store.db() as db:
                rows = db.execute("SELECT c.* FROM couples c JOIN actors a ON a.id=c.a_actor JOIN actors b ON b.id=c.b_actor WHERE (a.owner_id=? OR b.owner_id=?) AND c.status IN ('pending','active') ORDER BY since DESC", (user, user))
                result = []
                for r in rows:
                    item = self.couple_view(db, r)
                    item['can_respond'] = item['b']['owner_id'] == user
                    item['daily'] = [r[0] for r in db.execute('SELECT task FROM couple_daily WHERE couple_id=? AND user_id=? AND day=?', (item['id'], user, today()))]
                    item['memories'] = [dict(r) for r in db.execute('SELECT text,created FROM couple_memories WHERE couple_id=? ORDER BY created DESC LIMIT 20', (item['id'],))]
                    result.append(item)
                return result

        @app.post('/api/couples')
        def request_cp(body: CoupleIn, background: BackgroundTasks, user=Depends(auth)):
            check(body.actor_id != body.target_id, '请选择另一位伙伴')
            check(body.cp_name.strip(), '请为你们的 CP 起个名字')
            with self.store.db(write=True) as db:
                source = self.owned(db, body.actor_id, user)
                target = self.actor(db, body.target_id)
                check(not db.execute("SELECT 1 FROM couples WHERE status IN ('active','pending') AND (a_actor IN (?,?) OR b_actor IN (?,?))", (source['id'], target['id'], source['id'], target['id'])).fetchone(), '其中一方已有 CP 或待处理的心意', 409)
                cid = uid()
                db.execute("INSERT INTO couples VALUES(?,?,?,?,'pending',?,0)", (cid, source['id'], target['id'], body.cp_name.strip(), time.time()))
                self.notify(db, target['owner_id'], 'requests', source['id'], target_id=cid, text='向你发来了 CP 心意：'+body.cp_name.strip())
            self.notification_changed(background, [target['owner_id']])
            return {'id': cid, 'status': 'pending'}

        @app.post('/api/couples/{cid}/respond')
        def accept_cp(cid: str, body: Accept, background: BackgroundTasks, user=Depends(auth)):
            with self.store.db(write=True) as db:
                r = db.execute('SELECT * FROM couples WHERE id=?', (cid,)).fetchone()
                check(r, 'CP 申请不存在', 404)
                self.owned(db, r['b_actor'], user)
                check(r['status'] == 'pending', '这份心意已处理', 409)
                check(not body.accept or not db.execute("SELECT 1 FROM couples WHERE id<>? AND status='active' AND (a_actor IN (?,?) OR b_actor IN (?,?))", (cid, r['a_actor'], r['b_actor'], r['a_actor'], r['b_actor'])).fetchone(), '已有其他 CP，请先处理', 409)
                if body.accept: pid = self.activate_couple(db, r)
                else:
                    db.execute("UPDATE couples SET status='declined' WHERE id=?", (cid,))
                    pid = ''
                sender = self.actor(db, r['a_actor'])
                self.notify(db, sender['owner_id'], 'requests', r['b_actor'], target_id=cid, text='接受了你的 CP 心意' if body.accept else '温柔地婉拒了这份心意')
            if pid: self.emit_posts(background, pid, 'created')
            self.notification_changed(background, [sender['owner_id'], user])
            return {'ok': True}

        @app.post('/api/couples/{cid}/daily')
        def daily(cid: str, body: Daily, user=Depends(auth)):
            check(body.task in self.TASKS, '任务不存在')
            with self.store.db(write=True) as db:
                cp = db.execute("SELECT * FROM couples WHERE id=? AND status='active'", (cid,)).fetchone()
                check(cp, 'CP 不存在', 404)
                check(any(self.actor(db, cp[k])['owner_id'] == user for k in ('a_actor', 'b_actor')), '只有 CP 本人可以打卡', 403)
                check(not db.execute('SELECT 1 FROM couple_daily WHERE couple_id=? AND user_id=? AND day=? AND task=?', (cid, user, today(), body.task)).fetchone(), '今天已经完成啦', 409)
                db.execute('INSERT INTO couple_daily VALUES(?,?,?,?)', (cid, user, today(), body.task))
                db.execute('UPDATE couples SET intimacy=intimacy+5 WHERE id=?', (cid,))
                db.execute('INSERT INTO couple_memories VALUES(?,?,?,?)', (uid(), cid, self.TASKS[body.task]+' · 又靠近了一点', time.time()))
                return {'ok': True, 'intimacy': cp['intimacy']+5}

        @app.delete('/api/couples/{cid}')
        def end_cp(cid: str, user=Depends(auth)):
            with self.store.db(write=True) as db:
                cp = db.execute('SELECT * FROM couples WHERE id=?', (cid,)).fetchone()
                check(cp, 'CP 不存在', 404)
                check(any(self.actor(db, cp[k])['owner_id'] == user for k in ('a_actor', 'b_actor')), '只有 CP 本人可以解除', 403)
                db.execute("UPDATE couples SET status='ended' WHERE id=?", (cid,))
                db.execute('INSERT INTO couple_memories VALUES(?,?,?,?)', (uid(), cid, '谢谢这一段同行，祝各自安好。', time.time()))
                db.execute("UPDATE relationships SET type='前任',updated_at=? WHERE (a_actor=? AND b_actor=?) OR (a_actor=? AND b_actor=?)", (time.time(), cp['a_actor'], cp['b_actor'], cp['b_actor'], cp['a_actor']))
                return {'ok': True}

        @app.post('/api/heartbeats')
        def send_heart(body: Heart, background: BackgroundTasks, user=Depends(auth)):
            with self.store.db(write=True) as db:
                a = self.human(db, user)
                b = self.actor(db, body.target_id)
                check(a['id'] != b['id'], '把心动留给另一位伙伴吧')
                db.execute('INSERT OR IGNORE INTO hearts VALUES(?,?,?)', (a['id'], b['id'], time.time()))
                matched = bool(db.execute('SELECT 1 FROM hearts WHERE source=? AND target=?', (b['id'], a['id'])).fetchone())
                if matched:
                    for source, target in ((a, b), (b, a)):
                        if not db.execute("SELECT 1 FROM notifications WHERE user_id=? AND source_id=? AND text='你们的匿名心动双向奔赴了'", (target['owner_id'], 'heart-'+source['id'])).fetchone():
                            self.notify(db, target['owner_id'], 'followers', source['id'], source_id='heart-'+source['id'], text='你们的匿名心动双向奔赴了')
            if matched: self.notification_changed(background, [a['owner_id'], b['owner_id']])
            return {'matched': matched}

        @app.get('/api/heartbeats/me')
        def hearts_me(user=Depends(auth)):
            with self.store.db() as db:
                a = self.human(db, user)
                rows = db.execute('SELECT h.target FROM hearts h WHERE h.source=? AND EXISTS(SELECT 1 FROM hearts b WHERE b.source=h.target AND b.target=h.source)', (a['id'],))
                return [self.person(db, r[0]) for r in rows]

        @app.get('/api/public/heart-wall')
        @app.get('/api/heart-wall')
        def heart_wall():
            with self.store.db() as db:
                result = []
                for r in db.execute('SELECT * FROM heart_wall ORDER BY created DESC LIMIT 50'):
                    item = dict(r)
                    item['author'] = '匿名的小心意' if item['anonymous'] else self.actor(db, item['actor_id'])['name']
                    item.pop('actor_id')
                    result.append(item)
                return result

        @app.post('/api/heart-wall')
        def add_heart_wall(body: WallIn, user=Depends(auth)):
            check(body.text.strip(), '写下一点心意吧')
            with self.store.db(write=True) as db:
                a = self.human(db, user)
                check(db.execute('SELECT COUNT(*) FROM heart_wall WHERE actor_id=? AND created>?', (a['id'], time.time()-86400)).fetchone()[0] < 5, '每天最多留下 5 张心意便签', 429)
                wid = uid()
                db.execute('INSERT INTO heart_wall VALUES(?,?,?,?,?,?)', (wid, a['id'], body.text.strip(), int(body.anonymous), time.time()))
                return {'id': wid}

        @app.get('/api/wallet')
        def wallet(user=Depends(auth)):
            with self.store.db() as db:
                aid = self.human(db, user)['id']
                coins = db.execute('SELECT coins FROM wallets WHERE actor=?', (aid,)).fetchone()
                return {'coins': coins[0] if coins else 0, 'checked_in': bool(db.execute("SELECT 1 FROM coin_ledger WHERE actor=? AND reason='checkin' AND ref=?", (aid, today())).fetchone()), 'ledger': [dict(r) for r in db.execute('SELECT delta,reason,ref,created FROM coin_ledger WHERE actor=? ORDER BY created DESC LIMIT 50', (aid,))], 'gifts': [{'id': k, 'name': v[0], 'cost': v[1]} for k, v in self.GIFTS.items()]}

        @app.post('/api/wallet/checkin')
        def checkin(user=Depends(auth)):
            with self.store.db(write=True) as db:
                aid = self.human(db, user)['id']
                check(not db.execute("SELECT 1 FROM coin_ledger WHERE actor=? AND reason='checkin' AND ref=?", (aid, today())).fetchone(), '今天已经签过到啦', 409)
                self.credit(db, aid, 5, 'checkin', today())
                return {'ok': True, 'earned': 5}

        @app.post('/api/wallet/gift')
        def gift(body: Gift, background: BackgroundTasks, user=Depends(auth)):
            check(body.gift in self.GIFTS, '礼物不存在')
            with self.store.db(write=True) as db:
                a = self.human(db, user)
                b = self.actor(db, body.target_id)
                check(a['id'] != b['id'], '请选择另一位伙伴')
                label, cost = self.GIFTS[body.gift]
                ref = uid()
                self.credit(db, a['id'], -cost, 'gift:'+label, ref)
                self.credit(db, b['id'], cost, 'received:'+label, ref)
                self.notify(db, b['owner_id'], 'likes', a['id'], target_id=b['id'], text='送给你'+label)
            self.notification_changed(background, [b['owner_id']])
            return {'ok': True}

        @app.get('/api/public/red-flags')
        @app.get('/api/red-flags')
        def red_flags(q: str = ''):
            check(len(q) <= 100, '搜索词太长')
            with self.store.db() as db:
                return [dict(r) for r in db.execute("SELECT r.*,a.name AS target_name FROM red_flags r JOIN actors a ON a.id=r.target_actor WHERE status='published' AND (instr(description,?)>0 OR instr(a.name,?)>0) ORDER BY created DESC LIMIT 40", (q, q))]

        @app.post('/api/red-flags')
        def add_red_flag(body: Report, user=Depends(auth)):
            check(body.reason in ('情感失信', '不友善', '游戏行为', '放鸽子', '剧情提醒'), '请选择避雷分类')
            check(len(body.description.strip()) >= 10, '请客观描述至少 10 字的经过')
            with self.store.db(write=True) as db:
                self.actor(db, body.target_id)
                check(db.execute('SELECT 1 FROM npcs WHERE actor=?', (body.target_id,)).fetchone(), '公开避雷仅限剧情居民；涉及玩家请使用私密举报', 400)
                check(db.execute("SELECT COUNT(*) FROM reports WHERE user_id=? AND target_kind='redflag' AND created>?", (user, time.time()-86400)).fetchone()[0] < 3, '今天已经提交过多条，请等待审核', 429)
                rid = uid()
                db.execute("INSERT INTO reports VALUES(?,?,'redflag',?,?,?,'pending',?)", (rid, user, body.target_id, body.reason, body.description.strip(), time.time()))
                return {'id': rid, 'status': 'pending'}

        @app.post('/api/red-flags/{rid}/response')
        def respond_flag(rid: str, body: ResponseIn, user=Depends(auth)):
            with self.store.db(write=True) as db:
                r = db.execute('SELECT * FROM red_flags WHERE id=?', (rid,)).fetchone()
                check(r, '记录不存在', 404)
                self.owned(db, r['target_actor'], user)
                check(time.time()-r['created'] <= 72*3600 and not r['response'], '回应窗口已结束或已经回应', 409)
                db.execute('UPDATE red_flags SET response=? WHERE id=?', (body.text.strip(), rid))
                return {'ok': True}

        @app.get('/api/public/actors/{aid}/community')
        @app.get('/api/actors/{aid}/community')
        def actor_community(aid: str):
            with self.store.db() as db:
                a = self.person(db, aid)
                score = db.execute('SELECT score FROM reputations WHERE actor=?', (aid,)).fetchone()
                mood = db.execute('SELECT mood FROM community_preferences WHERE user_id=?', (a['owner_id'],)).fetchone()
                npc = db.execute('SELECT persona_json FROM npcs WHERE actor=?', (aid,)).fetchone()
                return {'actor': a, 'score': score[0] if score else 60, 'mood': json.loads(npc[0]).get('mood', '今天也想遇见有趣的人') if npc else mood[0] if mood else '今天也想遇见有趣的人', 'couples': [self.couple_view(db, r) for r in db.execute("SELECT * FROM couples WHERE status='active' AND (a_actor=? OR b_actor=?)", (aid, aid))]}

        @app.get('/api/relationships/me')
        def relationships(user=Depends(auth)):
            with self.store.db() as db:
                rows = db.execute('SELECT r.* FROM relationships r JOIN actors a ON a.id=r.a_actor JOIN actors b ON b.id=r.b_actor WHERE a.owner_id=? OR b.owner_id=?', (user, user))
                return [dict(r) for r in rows]

        @app.get('/api/public/residents')
        @app.get('/api/residents')
        def residents():
            with self.store.db() as db:
                return [{**self.person(db, r['actor']), 'mood': json.loads(r['persona_json']).get('mood', ''), 'interests': json.loads(r['persona_json']).get('interests', []), 'active': bool(r['active'])} for r in db.execute('SELECT * FROM npcs ORDER BY rowid LIMIT 100')]

        @app.get('/api/community/preferences')
        def preferences(user=Depends(auth)):
            with self.store.db() as db:
                r = db.execute('SELECT quiet,drama,mood FROM community_preferences WHERE user_id=?', (user,)).fetchone()
                return {**(dict(r) if r else {'quiet': False, 'drama': True, 'mood': '今天也想遇见有趣的人'}), 'admin': self.admin(db, user)}

        @app.patch('/api/community/preferences')
        def set_preferences(body: Preferences, user=Depends(auth)):
            with self.store.db(write=True) as db:
                db.execute('INSERT INTO community_preferences VALUES(?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET quiet=excluded.quiet,drama=excluded.drama,mood=excluded.mood', (user, int(body.quiet), int(body.drama), body.mood.strip()))
                return {'ok': True}

        @app.get('/api/community/usage')
        def usage(user=Depends(auth)):
            with self.store.db() as db:
                check(self.admin(db, user), '仅社区管理员可查看用量', 403)
                return {'usage': [dict(r) for r in db.execute('SELECT provider,task,COUNT(*) AS calls,SUM(tokens) AS tokens,SUM(fallback) AS fallbacks FROM model_usage WHERE created>? GROUP BY provider,task', (time.time()-86400,))], 'actions': db.execute('SELECT COUNT(*) FROM npc_actions WHERE created>?', (time.time()-86400,)).fetchone()[0], 'residents': db.execute('SELECT COUNT(*) FROM npcs WHERE active=1').fetchone()[0]}

        @app.get('/api/public/yearbook')
        @app.get('/api/yearbook')
        def yearbook():
            with self.store.db() as db:
                return self.post_views(db, db.execute('SELECT p.* FROM posts p WHERE '+self.heat_sql('p')+' >= 30 ORDER BY p.created DESC LIMIT 40'), None)

        @app.post('/api/reports')
        def report(body: Report, user=Depends(auth)):
            check(body.target_kind in ('post', 'actor', 'message'), '举报对象类型无效')
            check(body.reason in ('不友善', '隐私信息', '诈骗引导', '刷屏', '其他'), '请选择举报理由')
            with self.store.db(write=True) as db:
                table = {'post': 'posts', 'actor': 'actors', 'message': 'messages'}[body.target_kind]
                check(db.execute(f'SELECT 1 FROM {table} WHERE id=?', (body.target_id,)).fetchone(), '举报对象不存在', 404)
                if body.target_kind == 'message':
                    check(db.execute('SELECT 1 FROM messages x JOIN members m ON m.room_id=x.room_id JOIN actors a ON a.id=m.actor_id WHERE x.id=? AND a.owner_id=?', (body.target_id, user)).fetchone(), '无权举报这个会话的消息', 403)
                check(db.execute('SELECT COUNT(*) FROM reports WHERE user_id=? AND created>?', (user, time.time()-3600)).fetchone()[0] < 10, '提交过于频繁，请稍后再试', 429)
                rid = uid()
                db.execute("INSERT INTO reports VALUES(?,?,?,?,?,?,'pending',?)", (rid, user, body.target_kind, body.target_id, body.reason, body.description, time.time()))
                return {'id': rid, 'status': 'pending'}

        @app.post('/api/messages/{mid}/recall')
        def recall(mid: str, background: BackgroundTasks, user=Depends(auth)):
            with self.store.db(write=True) as db:
                m = db.execute('SELECT * FROM messages WHERE id=?', (mid,)).fetchone()
                check(m, '消息不存在', 404)
                a = self.owned(db, m['actor_id'], user)
                self.member(db, m['room_id'], user)
                check(time.time()-m['created'] <= 120, '只能撤回两分钟内发送的消息', 409)
                check(not db.execute("SELECT 1 FROM message_details WHERE message_id=? AND kind='recalled'", (mid,)).fetchone(), '消息已撤回', 409)
                db.execute('UPDATE messages SET text=? WHERE id=?', (a['name']+' 撤回了一条消息', mid))
                db.execute("INSERT INTO message_details(message_id,kind) VALUES(?,'recalled') ON CONFLICT(message_id) DO UPDATE SET kind='recalled',reply_to='',post_id=''", (mid,))
                updated = self.message_view(db, db.execute('SELECT * FROM messages WHERE id=?', (mid,)).fetchone(), user)
                users = self.room_users(db, m['room_id'])
            background.add_task(self.hub.emit, users, {'type': 'room.message.updated', 'room_id': m['room_id'], 'message': updated})
            return updated

        @app.post('/api/rooms/{rid}/poke')
        def poke(rid: str, body: Heart, background: BackgroundTasks, user=Depends(auth)):
            with self.store.db(write=True) as db:
                self.member(db, rid, user)
                a = self.human(db, user)
                check(db.execute('SELECT 1 FROM members WHERE room_id=? AND actor_id=?', (rid, a['id'])).fetchone(), '你的玩家身份不在这个聊天中', 403)
                target = self.actor(db, body.target_id)
                check(db.execute('SELECT 1 FROM members WHERE room_id=? AND actor_id=?', (rid, target['id'])).fetchone(), '对方不在当前聊天', 403)
                check(not db.execute("SELECT 1 FROM messages m JOIN message_details d ON d.message_id=m.id WHERE m.room_id=? AND m.actor_id=? AND d.kind='poke' AND m.created>?", (rid, a['id'], time.time()-10)).fetchone(), '轻轻拍一下就好，稍后再试', 429)
                mid = uid()
                db.execute('INSERT INTO messages(id,room_id,actor_id,text,created) VALUES(?,?,?,?,?)', (mid, rid, a['id'], a['name']+' 拍了拍 '+target['name']+' 🌷', time.time()))
                db.execute("INSERT INTO message_details(message_id,kind) VALUES(?,'poke')", (mid,))
                msg = self.message_view(db, db.execute('SELECT * FROM messages WHERE id=?', (mid,)).fetchone(), user)
                users = self.room_users(db, rid)
            background.add_task(self.hub.emit, users, {'type': 'room.message', 'room_id': rid, 'message': msg})
            return msg

        @app.post('/api/rooms/{rid}/share')
        def share(rid: str, body: PostShare, background: BackgroundTasks, user=Depends(auth)):
            with self.store.db(write=True) as db:
                self.member(db, rid, user)
                a = self.human(db, user)
                check(db.execute('SELECT 1 FROM members WHERE room_id=? AND actor_id=?', (rid, a['id'])).fetchone(), '你的玩家身份不在这个聊天中', 403)
                p = db.execute('SELECT * FROM posts WHERE id=?', (body.post_id,)).fetchone()
                check(p, '帖子不存在', 404)
                preview = self.post_view(db, p, user)
                mid = uid()
                db.execute('INSERT INTO messages(id,room_id,actor_id,text,created) VALUES(?,?,?,?,?)', (mid, rid, a['id'], '分享帖子：'+preview['text'][:100], time.time()))
                db.execute("INSERT INTO message_details(message_id,kind,post_id) VALUES(?,'post',?)", (mid, body.post_id))
                msg = self.message_view(db, db.execute('SELECT * FROM messages WHERE id=?', (mid,)).fetchone(), user)
                users = self.room_users(db, rid)
            background.add_task(self.hub.emit, users, {'type': 'room.message', 'room_id': rid, 'message': msg})
            return msg

        @app.get('/api/community/reports')
        def reports(user=Depends(auth)):
            with self.store.db() as db:
                check(self.admin(db, user), '仅社区管理员可查看举报', 403)
                return [dict(r) for r in db.execute("SELECT * FROM reports WHERE status='pending' ORDER BY created LIMIT 100")]

        @app.post('/api/community/reports/{rid}')
        def moderate(rid: str, body: Moderation, background: BackgroundTasks, user=Depends(auth)):
            check(body.status in ('approved', 'dismissed'), '审核操作无效')
            pid = ''
            with self.store.db(write=True) as db:
                check(self.admin(db, user), '仅社区管理员可审核', 403)
                r = db.execute("SELECT * FROM reports WHERE id=? AND status='pending'", (rid,)).fetchone()
                check(r, '记录不存在或已处理', 404)
                db.execute('UPDATE reports SET status=? WHERE id=?', (body.status, rid))
                if body.status == 'approved' and r['target_kind'] == 'redflag':
                    check(db.execute("SELECT COUNT(*) FROM red_flags WHERE created>?", (time.time()-86400,)).fetchone()[0] < 5, '今日避雷公开额度已满', 429)
                    a = self.human(db, r['user_id'])
                    pid = uid()
                    db.execute("INSERT INTO posts(id,actor_id,text,created) VALUES(?,?,?,?)", (pid, a['id'], '【剧情居民记录】'+r['description'], time.time()))
                    db.execute("INSERT INTO community_posts(post_id,post_kind,channel) VALUES(?,'redflag','redflag')", (pid,))
                    db.execute("INSERT INTO red_flags VALUES(?,?,?,?,?,?,'','published',?)", (uid(), r['target_id'], r['reason'], r['description'], '经过描述', pid, time.time()))
            if pid: self.emit_posts(background, pid, 'created')
            return {'ok': True}

    def activate_couple(self, db, cp):
        db.execute("UPDATE couples SET status='active',since=? WHERE id=?", (time.time(), cp['id']))
        a, b = self.actor(db, cp['a_actor']), self.actor(db, cp['b_actor'])
        pid = uid()
        db.execute('INSERT INTO posts(id,actor_id,text,created) VALUES(?,?,?,?)', (pid, a['id'], '把喜欢写进日常。\n'+a['name']+' × '+b['name']+'，我们的 CP 叫「'+cp['cp_name']+'」。以后的小事，都想一起分享。', time.time()))
        db.execute("INSERT INTO community_posts(post_id,post_kind,channel) VALUES(?,'official','cp')", (pid,))
        db.execute('INSERT INTO couple_memories VALUES(?,?,?,?)', (uid(), cp['id'], '相遇之后，我们决定一起走一段。', time.time()))
        for source, target in ((a, b), (b, a)):
            db.execute("INSERT INTO relationships VALUES(?,?,'恋人',60,70,65,0,?,?) ON CONFLICT(a_actor,b_actor) DO UPDATE SET type='恋人',intimacy=60,romance=65,updated_at=excluded.updated_at", (source['id'], target['id'], time.time(), time.time()))
        return pid
