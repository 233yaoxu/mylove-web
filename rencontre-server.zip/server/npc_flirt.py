"""Conservative dialogue cues; a cue offers a choice, not relationship consent."""
import re


_QUOTED = re.compile(r'“[^”\n]*”|‘[^’\n]*’|「[^」\n]*」|『[^』\n]*』|"[^"\n]*"')
_STOP = re.compile(
    # “不要” in “要不要跟我聊骚” starts a question, not a refusal.
    r'(?:别|(?<!要)不要|不想|不用|不许|不可以)(?:再|继续|试着|这么|这样|跟[我你]|和[我你]|对我|\s){0,5}'
    r'(?:撩|调情|聊(?:个)?骚(?!扰)|搞?暧昧|说这种话|开这种玩笑)|(?:只想|只|就)(?:和你|跟你)?(?:做|当)(?:普通)?朋友'
    r'|(?:只是|就是)(?:普通)?朋友(?=$|而已|吧|[\s，。！？,!.?])'
    r'|不(?:想听|喜欢|接受)(?:被|你|这种){0,3}(?:撩|调情|聊骚(?!扰)|暧昧|这样的玩笑|这种话)'
    r'|(?:这么聊|这样聊|这种玩笑)(?:让我|我觉得)?(?:有点|很|挺|太)?不舒服'
    r'|(?:别|(?<!要)不要|不想)(?:再)?继续了|不(?:再)?聊骚了|别再聊这个|可以别这样吗'
    r'|(?:^|[\s，。！？；,!.?;])(?:现在|今天)?(?:先)?(?:停|停一下|停一停|暂停一下|到此为止|打住|不要了)(?=$|[\s，。！？；,!.?;])')
_CHANGE = re.compile(r'换(?:个|一个)?话题|(?<!别)说正事(?:吧|了)?|先不聊这个')
_INVITE = re.compile(
    r'撩(?:撩我|我(?:一下|两句|吧))|(?:可以|能不能|要不要|敢不敢|继续|再)撩(?:撩)?我|我想撩你'
    r'|(?:要不要|想|可以|能不能)(?:继续)?(?:和你|跟你|跟我|和我)?(?:继续|再)?(?:聊(?:个)?骚(?!扰)|调情)'
    r'|聊(?:个)?骚[吗嘛]|想(?:和|跟)你(?:暧昧|约会)'
    r'|你(?:也太|真|还挺|好)会撩|你再这样[^。！？!?]{0,8}我(?:可)?就(?:要)?当真'
    r'|(?:我|你这样说我)(?:也|真的|挺|很|有点|都要|开始){0,3}'
    r'(?:喜欢你|想你|对你(?:有点)?心动|心动)(?:了)?(?=$|[\s，。！…？、,!.?])')


def flirt_cue(text):
    # Quoted dialogue and broad topic keywords are not invitations. A clearly
    # expressed boundary takes precedence over a joke in the same message.
    text = _QUOTED.sub(' ', text).strip()
    if _STOP.search(text): return 'stop'
    if _CHANGE.search(text): return 'change'
    if _INVITE.search(text): return 'invite'
    return ''
