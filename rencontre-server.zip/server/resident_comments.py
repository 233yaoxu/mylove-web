"""Comment publication boundaries, scoped to the caller's current world store."""
import re
import unicodedata

from .community_voice import natural_speech


LEGACY_COMMENT = '我想慢慢听完，再说说自己的想法。'
_MENTION = re.compile(r'^\s*@[^\s@]+\s+')


def comment_key(text, names=()):
    """Compare the spoken body; changing its addressee is not a new opinion."""
    text = unicodedata.normalize('NFKC', natural_speech(text)).strip()
    known = sorted({unicodedata.normalize('NFKC', name).strip().casefold()
                    for name in names if isinstance(name, str) and name.strip()}, key=len, reverse=True)
    while True:
        name = next((name for name in known if text.casefold().startswith('@' + name)), None)
        body = text[len(name) + 1:].lstrip(' \t\r\n,:：，') if name else _MENTION.sub('', text, count=1)
        if body == text:
            break
        text = body
    text = ''.join(text.casefold().split()).replace('−', '-')
    # Numeric punctuation carries meaning: 1.5 hours is not 15 hours, and a
    # negative balance is not a positive one. Sentence punctuation still drops.
    result = []
    for index, char in enumerate(text):
        before = index > 0 and text[index - 1].isdecimal()
        after = index + 1 < len(text) and text[index + 1].isdecimal()
        numeric_mark = ((char in '+-.' and after) or (char in '*/:=⁄' and before and after)
                        or (char == '%' and before))
        if char.isalnum() or numeric_mark:
            result.append(char)
    return ''.join(result)


def new_comment(text, previous=(), names=()):
    key = comment_key(text, names)
    return bool(key and key != comment_key(LEGACY_COMMENT)
                and all(key != comment_key(other, names) for other in previous))


def comment_visibility(alias='c'):
    """Hide only the identified platform fallback; retain all original records.

    Players, their own AI actors and sentences quoting the old template stay
    visible. Aliases are internal SQL constants, never request values.
    """
    return ("NOT EXISTS(SELECT 1 FROM npcs template_resident WHERE template_resident.actor=" +
            alias + ".actor_id AND trim(" + alias + ".text)='" + LEGACY_COMMENT + "')")
