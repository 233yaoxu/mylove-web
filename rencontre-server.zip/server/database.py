"""SQLite-compatible access to a local file or a persistent Turso database.

Cloud connections use the standard Hrana v3 HTTP protocol. They never keep an
authoritative SQLite file on the hosting service's temporary filesystem.
"""
from collections.abc import Sequence
from contextlib import contextmanager
from contextvars import ContextVar
import base64
import http.client
import json
import sqlite3
import threading
import time
import urllib.error
import urllib.request
from urllib.parse import unquote, urlsplit


class _RequestHttpTransports:
    """Bounded, short-lived HTTP sockets; never retain database stream state."""
    def __init__(self):
        self.idle = []
        self.lock = threading.Lock()
        self.closed = False

    def take(self, key):
        with self.lock:
            now = time.monotonic()
            for index in range(len(self.idle) - 1, -1, -1):
                origin, connection, released = self.idle[index]
                if self.closed or now - released > 2:
                    self.idle.pop(index)
                    connection.close()
                elif origin == key:
                    self.idle.pop(index)
                    return connection
        return None

    def release(self, key, connection):
        with self.lock:
            if self.closed or len(self.idle) >= 4:
                connection.close()
            else:
                self.idle.append((key, connection, time.monotonic()))

    def close(self):
        with self.lock:
            self.closed = True
            for _, connection, _ in self.idle:
                connection.close()
            self.idle.clear()


_request_http_pool = ContextVar('rencontre_request_http_pool', default=None)


@contextmanager
def request_http_transports():
    """Share only idle HTTP transports across one request's independent streams."""
    if _request_http_pool.get() is not None:
        yield
        return
    pool = _RequestHttpTransports()
    token = _request_http_pool.set(pool)
    try:
        yield
    finally:
        _request_http_pool.reset(token)
        pool.close()


class RequestHttpTransportMiddleware:
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope['type'] != 'http':
            return await self.app(scope, receive, send)
        # ContextVar copies into Starlette worker threads; the locked pool
        # outlives all root/child calls and is closed even on cancellation.
        with request_http_transports():
            return await self.app(scope, receive, send)


def operational_error_details(error):
    """Do not report every SQL or transport failure as a busy write."""
    message = str(error).lower()
    if 'locked' in message or 'busy' in message:
        return 503, '社区正在保存数据，请稍后重试'
    if any(value in message for value in ('timed out', 'timeout', 'connection failed',
                                           'connection reset', 'connection refused',
                                           'database request failed', 'database http status 5')):
        return 503, '社区数据库连接暂时中断，请稍后重试'
    return 500, '社区数据读取异常，请稍后重试'


class Row(Sequence):
    """The subset of sqlite3.Row used by the API, including dict(row)."""

    def __init__(self, cursor, values):
        self._values = tuple(values)
        self._keys = tuple(column[0] for column in cursor.description)
        self._indexes = {}
        for index, name in enumerate(self._keys):
            self._indexes.setdefault(name.casefold(), index)

    def keys(self):
        return list(self._keys)

    def __getitem__(self, key):
        if isinstance(key, str):
            try:
                key = self._indexes[key.casefold()]
            except KeyError:
                raise IndexError("No item with that key") from None
        return self._values[key]

    def __len__(self):
        return len(self._values)


@contextmanager
def _sqlite_errors(driver):
    try:
        yield
    except driver.IntegrityError as error:
        raise sqlite3.IntegrityError(str(error)) from error
    except driver.Error as error:
        raise sqlite3.OperationalError(str(error)) from error


def _http_session(url, token, timeout):
    from turso_serverless.protocol import ProtocolError
    from turso_serverless.session import Session

    class TimedSession(Session):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._http = None
            self._http_origin = None
            self._http_pool = None

        def _close_http(self):
            if self._http is not None:
                self._http.close()
            self._http = self._http_origin = None
            self._http_pool = None

        def _release_http(self):
            if self._http is not None and self._http_pool is not None:
                self._http_pool.release((self._http_origin, timeout), self._http)
                self._http = self._http_origin = self._http_pool = None
            else:
                self._close_http()

        def _post(self, path, body):
            target = urlsplit(self._base_url)
            proxy = urllib.request.getproxies().get(target.scheme)
            if proxy and urllib.request.proxy_bypass(target.netloc):
                proxy = None
            proxy_target = urlsplit(proxy if '://' in proxy else 'http://' + proxy) if proxy else None
            # Reuse CONNECT/TLS on hosting services that require an HTTP proxy.
            # In-use transports belong to this stream exclusively. Completed
            # streams can return HTTP to this request only, without their baton.
            if target.scheme in ('https', 'http') and (not proxy_target or proxy_target.scheme == 'http'):
                origin = (target.scheme, target.hostname, target.port, proxy)
                proxy_headers = {}
                if proxy_target and proxy_target.username is not None:
                    credentials = unquote(proxy_target.username) + ':' + unquote(proxy_target.password or '')
                    proxy_headers['Proxy-Authorization'] = 'Basic ' + base64.b64encode(
                        credentials.encode('utf-8')).decode('ascii')
                if self._http_origin != origin:
                    self._close_http()
                    self._http_pool = _request_http_pool.get()
                    self._http = self._http_pool.take((origin, timeout)) if self._http_pool else None
                    connection = http.client.HTTPSConnection if target.scheme == 'https' else http.client.HTTPConnection
                    if self._http is None:
                        self._http = connection(proxy_target.hostname if proxy_target else target.hostname,
                                            (proxy_target.port or 80) if proxy_target else target.port,
                                            timeout=timeout)
                        if proxy_target and target.scheme == 'https':
                            self._http.set_tunnel(target.hostname, target.port or 443, headers=proxy_headers)
                    self._http_origin = origin
                headers = self._headers()
                request_path = target.path.rstrip('/') + path
                if proxy_target and target.scheme == 'http':
                    request_path = self._base_url + path
                    headers.update(proxy_headers)
                try:
                    self._http.request('POST', request_path,
                                       body=json.dumps(body, allow_nan=False).encode('utf-8'),
                                       headers=headers)
                    response = self._http.getresponse()
                    raw = response.read()
                    if response.status != 200:
                        self._close_http()
                        self._reset_stream()
                        raise ProtocolError(f'Database HTTP status {response.status}')
                    return raw
                except (http.client.HTTPException, OSError):
                    # Never replay an interrupted request: a write may have committed.
                    self._close_http()
                    self._reset_stream()
                    raise ProtocolError('Database connection failed or timed out') from None
            self._close_http()
            request = urllib.request.Request(
                self._base_url + path,
                data=json.dumps(body, allow_nan=False).encode("utf-8"),
                headers=self._headers(),
                method="POST",
            )
            try:
                with urllib.request.urlopen(request, timeout=timeout) as response:
                    return response.read()
            except urllib.error.HTTPError as error:
                self._reset_stream()
                # Do not echo arbitrary remote response bodies or credentials.
                raise ProtocolError(f"Database HTTP status {error.code}") from None
            except (urllib.error.URLError, http.client.HTTPException, OSError):
                self._reset_stream()
                raise ProtocolError("Database connection failed or timed out") from None

        def close(self):
            try:
                super().close()
            finally:
                self._release_http()

    return TimedSession(url, auth_token=token)


class RemoteCursor:
    def __init__(self, connection, cursor):
        self.connection = connection
        self._cursor = cursor
        self.row_factory = connection.row_factory

    @property
    def description(self):
        return self._cursor.description

    @property
    def rowcount(self):
        return self._cursor.rowcount

    @property
    def lastrowid(self):
        return self._cursor.lastrowid

    def execute(self, sql, parameters=()):
        with _sqlite_errors(self.connection._driver):
            self._cursor.execute(sql, parameters)
        return self

    def executemany(self, sql, parameters):
        with _sqlite_errors(self.connection._driver):
            self._cursor.executemany(sql, parameters)
        return self

    def executescript(self, script):
        with _sqlite_errors(self.connection._driver):
            self._cursor.executescript(script)
        return self

    def _row(self, values):
        if values is None or self.row_factory is None:
            return values
        if self.row_factory is sqlite3.Row or self.row_factory is Row:
            return Row(self, values)
        return self.row_factory(self, values)

    def fetchone(self):
        with _sqlite_errors(self.connection._driver):
            return self._row(self._cursor.fetchone())

    def fetchall(self):
        with _sqlite_errors(self.connection._driver):
            return [self._row(row) for row in self._cursor.fetchall()]

    def fetchmany(self, size=None):
        with _sqlite_errors(self.connection._driver):
            rows = self._cursor.fetchmany(size) if size is not None else self._cursor.fetchmany()
            return [self._row(row) for row in rows]

    def close(self):
        with _sqlite_errors(self.connection._driver):
            self._cursor.close()

    def __iter__(self):
        return self

    def __next__(self):
        row = self.fetchone()
        if row is None:
            raise StopIteration
        return row


class RemoteConnection:
    def __init__(self, connection, driver):
        self._connection = connection
        self._driver = driver
        self.row_factory = None

    @property
    def in_transaction(self):
        return self._connection.in_transaction

    def cursor(self):
        with _sqlite_errors(self._driver):
            return RemoteCursor(self, self._connection.cursor())

    def execute(self, sql, parameters=()):
        return self.cursor().execute(sql, parameters)

    def executemany(self, sql, parameters):
        return self.cursor().executemany(sql, parameters)

    def executescript(self, script):
        return self.cursor().executescript(script)

    def begin_transaction(self, write=False):
        """Prepare one Store transaction with a single bounded HTTP request."""
        self.execute_batch([('PRAGMA foreign_keys=ON', ()),
                            ('BEGIN IMMEDIATE' if write else 'BEGIN', ())])

    def finish_transaction(self, commit=True):
        """Finish and release a Store stream together; never retry a commit."""
        from turso_serverless.connection import _classify_error
        from turso_serverless.protocol import build_batch_step
        from turso_serverless.session import _server_error

        if self._connection._closed:
            return
        transaction = self.in_transaction
        requests = []
        if transaction:
            requests.append({'type': 'batch', 'batch': {'steps': [
                build_batch_step('COMMIT' if commit else 'ROLLBACK', want_rows=False)]}})
        requests.append({'type': 'close'})
        with _sqlite_errors(self._driver):
            try:
                results = self._connection._session.execute_pipeline(requests, track_autocommit=False)
                for index, result in enumerate(results):
                    if result.get('type') == 'error':
                        raise _server_error(result.get('error'))
                    response = result.get('response') or {}
                    expected = 'batch' if transaction and index == 0 else 'close'
                    if response.get('type') != expected:
                        raise RuntimeError('Invalid database transaction response')
                    if expected == 'batch':
                        errors = response.get('result', {}).get('step_errors', [])
                        if len(errors) != 1:
                            raise RuntimeError('Invalid database transaction response')
                        if errors[0] is not None:
                            raise _server_error(errors[0])
            except RuntimeError as error:
                raise _classify_error(error) from None
            finally:
                self._connection._session._reset_stream()
                self._connection._session.close()
                self._connection._closed = True

    def execute_batch(self, statements):
        """Run seed writes in bounded Hrana batches inside the current transaction."""
        from turso_serverless.connection import _classify_error
        from turso_serverless.protocol import build_batch_step
        from turso_serverless.session import _server_error

        statements=list(statements)
        if not statements:return
        with _sqlite_errors(self._driver):
            self._connection._maybe_implicit_begin(statements[0][0])
            for start in range(0,len(statements),64):
                steps=[]
                for index,(sql,parameters) in enumerate(statements[start:start+64]):
                    args,named=self._driver.Cursor._convert_params(parameters)
                    steps.append(build_batch_step(sql,args=args,named_args=named,want_rows=False,
                                                  condition={'type':'ok','step':index-1} if index else None))
                try:
                    results=self._connection._session.execute_pipeline([{'type':'batch','batch':{'steps':steps}}])
                    result=results[0]
                    if result.get('type')=='error':raise _server_error(result.get('error'))
                    response=result.get('response',{})
                    errors=response.get('result',{}).get('step_errors',[])
                    if response.get('type')!='batch' or len(errors)!=len(steps):
                        raise RuntimeError('Invalid database batch response')
                    for error in errors:
                        if error is not None:raise _server_error(error)
                except RuntimeError as error:
                    raise _classify_error(error) from None

    def query_batch(self, statements, *, snapshot=False):
        """Read independent metadata in one Hrana round trip per bounded batch."""
        from turso_serverless.connection import _classify_error
        from turso_serverless.protocol import build_batch_step, decode_value
        from turso_serverless.session import _server_error

        statements=list(statements)
        output=[]
        if not statements:return output
        if snapshot:
            from .sql_scope import QUERY_TOKENS
            # This API batches trusted application SELECTs. Check the whole
            # snapshot before opening a stream: remote gateways do not all
            # support PRAGMA query_only, and a later batch must not commit or
            # modify an earlier one. SQL values remain bound parameters.
            for sql,_ in statements:
                tokens=[match.group(0) for match in QUERY_TOKENS.finditer(sql)
                        if not match.group(0).startswith(('--','/*'))]
                if not tokens or tokens[0].upper()!='SELECT' or ';' in tokens[:-1]:
                    raise sqlite3.OperationalError('Snapshot reads require a single SELECT statement')
        with _sqlite_errors(self._driver):
            for start in range(0,len(statements),64):
                steps=[]
                if snapshot and start == 0:
                    steps=[build_batch_step('BEGIN',want_rows=False)]
                offset=len(steps)
                chunk=statements[start:start+64]
                for sql,parameters in chunk:
                    index=len(steps)
                    args,named=self._driver.Cursor._convert_params(parameters)
                    steps.append(build_batch_step(sql,args=args,named_args=named,want_rows=True,
                                                  condition={'type':'ok','step':index-1} if index else None))
                final=snapshot and start+len(chunk)==len(statements)
                if final:
                    # Always discard the validated read transaction, including
                    # when one statement failed.
                    steps.append(build_batch_step('ROLLBACK',want_rows=False))
                requests=[{'type':'batch','batch':{'steps':steps}}]
                if final:requests.append({'type':'close'})
                try:
                    results=self._connection._session.execute_pipeline(requests,track_autocommit=not final)
                    result=results[0]
                    if result.get('type')=='error':raise _server_error(result.get('error'))
                    response=result.get('response',{})
                    values=response.get('result',{})
                    errors=values.get('step_errors',[])
                    rows=values.get('step_results',[])
                    if response.get('type')!='batch' or len(errors)!=len(steps) or len(rows)!=len(steps):
                        raise RuntimeError('Invalid database query batch response')
                    if final and (len(results)!=2 or results[1].get('type')!='ok'
                                  or results[1].get('response',{}).get('type')!='close'):
                        raise RuntimeError('Invalid database snapshot close response')
                    for index,error in enumerate(errors):
                        if error is not None:raise _server_error(error)
                        if index<offset or index>=offset+len(chunk):continue
                        item=rows[index]
                        if not isinstance(item,dict):raise RuntimeError('Invalid database query batch response')
                        # Reuse the normal row-factory conversion without another SQL request.
                        raw=self._connection.cursor()
                        raw._description=tuple((column['name'],None,None,None,None,None,None)
                                               for column in item.get('cols',[]))
                        cursor=RemoteCursor(self,raw)
                        try:
                            output.append([cursor._row(tuple(decode_value(value) for value in row))
                                           for row in item.get('rows',[])])
                        finally:cursor.close()
                except RuntimeError as error:
                    raise _classify_error(error) from None
                finally:
                    if final:
                        self._connection._session._reset_stream()
                        self._connection._session.close()
                        self._connection._closed=True
        return output

    def commit(self):
        with _sqlite_errors(self._driver):
            self._connection.commit()

    def rollback(self):
        with _sqlite_errors(self._driver):
            self._connection.rollback()

    def close(self):
        with _sqlite_errors(self._driver):
            self._connection.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        if exc_type is None:
            self.commit()
        else:
            self.rollback()
        return False


def connect_remote(url, token, *, timeout=15):
    """Open a remote libSQL/Turso connection with SQLite transactions.

    Schema errors and unique constraint errors retain sqlite3's exception
    classes so the existing API can handle them. Network writes are never
    retried automatically because an interrupted commit may have succeeded.
    """
    try:
        import turso_serverless as driver
    except ImportError:
        raise RuntimeError("Install server/requirements-cloud.txt for cloud database access") from None
    connection = driver.Connection(_http_session(url, token, timeout), isolation_level="DEFERRED")
    return RemoteConnection(connection, driver)


def connect(path, *, remote_url=None, auth_token=None):
    """Select cloud storage explicitly; local development still uses sqlite3."""
    if remote_url:
        if not auth_token:
            raise ValueError("TURSO_AUTH_TOKEN is required for cloud database access")
        return connect_remote(remote_url, auth_token)
    return sqlite3.connect(path, timeout=3)


def execute_batch(connection, statements):
    """Keep local seed behavior while removing remote round trips per row."""
    batch = getattr(connection, 'execute_batch', None)
    if callable(batch):
        return batch(statements)
    for sql,parameters in statements:
        connection.execute(sql,parameters)


def query_batch(connection, statements):
    """Preserve local rows while batching only independent remote reads."""
    statements=list(statements)
    batch=getattr(connection,'query_batch',None)
    if callable(batch):return batch(statements)
    return [connection.execute(sql,parameters).fetchall() for sql,parameters in statements]
