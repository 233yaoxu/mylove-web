"""SQLite-compatible access to a local file or a persistent Turso database.

Cloud connections use the standard Hrana v3 HTTP protocol. They never keep an
authoritative SQLite file on the hosting service's temporary filesystem.
"""
from collections.abc import Sequence
from contextlib import contextmanager
import http.client
import json
import sqlite3
import urllib.error
import urllib.request


class Row(Sequence):
    """The subset of sqlite3.Row used by the API, including dict(row)."""

    def __init__(self, cursor, values):
        self._values = tuple(values)
        self._keys = tuple(column[0] for column in cursor.description)
        self._indexes = {}
        for index, name in enumerate(self._keys):
            self._indexes.setdefault(name.casefold(), index)

    def keys(self):
        return list(self._keys)

    def __getitem__(self, key):
        if isinstance(key, str):
            try:
                key = self._indexes[key.casefold()]
            except KeyError:
                raise IndexError("No item with that key") from None
        return self._values[key]

    def __len__(self):
        return len(self._values)


@contextmanager
def _sqlite_errors(driver):
    try:
        yield
    except driver.IntegrityError as error:
        raise sqlite3.IntegrityError(str(error)) from error
    except driver.Error as error:
        raise sqlite3.OperationalError(str(error)) from error


def _http_session(url, token, timeout):
    from turso_serverless.protocol import ProtocolError
    from turso_serverless.session import Session

    class TimedSession(Session):
        def _post(self, path, body):
            request = urllib.request.Request(
                self._base_url + path,
                data=json.dumps(body, allow_nan=False).encode("utf-8"),
                headers=self._headers(),
                method="POST",
            )
            try:
                with urllib.request.urlopen(request, timeout=timeout) as response:
                    return response.read()
            except urllib.error.HTTPError as error:
                self._reset_stream()
                # Do not echo arbitrary remote response bodies or credentials.
                raise ProtocolError(f"Database HTTP status {error.code}") from None
            except (urllib.error.URLError, http.client.HTTPException, OSError):
                self._reset_stream()
                raise ProtocolError("Database connection failed or timed out") from None

    return TimedSession(url, auth_token=token)


class RemoteCursor:
    def __init__(self, connection, cursor):
        self.connection = connection
        self._cursor = cursor
        self.row_factory = connection.row_factory

    @property
    def description(self):
        return self._cursor.description

    @property
    def rowcount(self):
        return self._cursor.rowcount

    @property
    def lastrowid(self):
        return self._cursor.lastrowid

    def execute(self, sql, parameters=()):
        with _sqlite_errors(self.connection._driver):
            self._cursor.execute(sql, parameters)
        return self

    def executemany(self, sql, parameters):
        with _sqlite_errors(self.connection._driver):
            self._cursor.executemany(sql, parameters)
        return self

    def executescript(self, script):
        with _sqlite_errors(self.connection._driver):
            self._cursor.executescript(script)
        return self

    def _row(self, values):
        if values is None or self.row_factory is None:
            return values
        if self.row_factory is sqlite3.Row or self.row_factory is Row:
            return Row(self, values)
        return self.row_factory(self, values)

    def fetchone(self):
        with _sqlite_errors(self.connection._driver):
            return self._row(self._cursor.fetchone())

    def fetchall(self):
        with _sqlite_errors(self.connection._driver):
            return [self._row(row) for row in self._cursor.fetchall()]

    def fetchmany(self, size=None):
        with _sqlite_errors(self.connection._driver):
            rows = self._cursor.fetchmany(size) if size is not None else self._cursor.fetchmany()
            return [self._row(row) for row in rows]

    def close(self):
        with _sqlite_errors(self.connection._driver):
            self._cursor.close()

    def __iter__(self):
        return self

    def __next__(self):
        row = self.fetchone()
        if row is None:
            raise StopIteration
        return row


class RemoteConnection:
    def __init__(self, connection, driver):
        self._connection = connection
        self._driver = driver
        self.row_factory = None

    @property
    def in_transaction(self):
        return self._connection.in_transaction

    def cursor(self):
        with _sqlite_errors(self._driver):
            return RemoteCursor(self, self._connection.cursor())

    def execute(self, sql, parameters=()):
        return self.cursor().execute(sql, parameters)

    def executemany(self, sql, parameters):
        return self.cursor().executemany(sql, parameters)

    def executescript(self, script):
        return self.cursor().executescript(script)

    def execute_batch(self, statements):
        """Run seed writes in bounded Hrana batches inside the current transaction."""
        from turso_serverless.connection import _classify_error
        from turso_serverless.protocol import build_batch_step
        from turso_serverless.session import _server_error

        statements=list(statements)
        if not statements:return
        with _sqlite_errors(self._driver):
            self._connection._maybe_implicit_begin(statements[0][0])
            for start in range(0,len(statements),64):
                steps=[]
                for index,(sql,parameters) in enumerate(statements[start:start+64]):
                    args,named=self._driver.Cursor._convert_params(parameters)
                    steps.append(build_batch_step(sql,args=args,named_args=named,want_rows=False,
                                                  condition={'type':'ok','step':index-1} if index else None))
                try:
                    results=self._connection._session.execute_pipeline([{'type':'batch','batch':{'steps':steps}}])
                    result=results[0]
                    if result.get('type')=='error':raise _server_error(result.get('error'))
                    response=result.get('response',{})
                    errors=response.get('result',{}).get('step_errors',[])
                    if response.get('type')!='batch' or len(errors)!=len(steps):
                        raise RuntimeError('Invalid database batch response')
                    for error in errors:
                        if error is not None:raise _server_error(error)
                except RuntimeError as error:
                    raise _classify_error(error) from None

    def commit(self):
        with _sqlite_errors(self._driver):
            self._connection.commit()

    def rollback(self):
        with _sqlite_errors(self._driver):
            self._connection.rollback()

    def close(self):
        with _sqlite_errors(self._driver):
            self._connection.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        if exc_type is None:
            self.commit()
        else:
            self.rollback()
        return False


def connect_remote(url, token, *, timeout=15):
    """Open a remote libSQL/Turso connection with SQLite transactions.

    Schema errors and unique constraint errors retain sqlite3's exception
    classes so the existing API can handle them. Network writes are never
    retried automatically because an interrupted commit may have succeeded.
    """
    try:
        import turso_serverless as driver
    except ImportError:
        raise RuntimeError("Install server/requirements-cloud.txt for cloud database access") from None
    connection = driver.Connection(_http_session(url, token, timeout), isolation_level="DEFERRED")
    return RemoteConnection(connection, driver)


def connect(path, *, remote_url=None, auth_token=None):
    """Select cloud storage explicitly; local development still uses sqlite3."""
    if remote_url:
        if not auth_token:
            raise ValueError("TURSO_AUTH_TOKEN is required for cloud database access")
        return connect_remote(remote_url, auth_token)
    return sqlite3.connect(path, timeout=3)


def execute_batch(connection, statements):
    """Keep local seed behavior while removing remote round trips per row."""
    if isinstance(connection,RemoteConnection):
        return connection.execute_batch(statements)
    for sql,parameters in statements:
        connection.execute(sql,parameters)
