"""Rotating personal intentions, never fabricated accusations about other actors."""
import hashlib
from datetime import datetime, timedelta, timezone
from .npc_topics import personal_intents
from .resident_comments import new_comment

TOPIC_COOLDOWN = 7 * 86400


def topic_history(life, now):
    try:
        legacy_time = datetime.fromisoformat(life.get('day', '')).replace(tzinfo=timezone(timedelta(hours=8))).timestamp()
    except (ValueError, TypeError): legacy_time = now
    result = []
    for entry in life.get('recent_topics', []) if isinstance(life.get('recent_topics', []), list) else []:
        entry = {'id': entry, 'at': legacy_time} if isinstance(entry, str) else entry
        if (isinstance(entry, dict) and isinstance(entry.get('id'), str)
                and type(entry.get('at')) in (int, float) and now - TOPIC_COOLDOWN < entry['at'] <= now):
            result.append({'id': entry['id'], 'at': entry['at']})
    return result[-128:]

INTENTS = (
    ('gaming', '游戏搭子', '找游戏搭子', '今晚想开黑，有没有不甩锅的队友？输可以，别一逆风就开始骂人。'),
    ('love', '交友', '表达交友标准，不预设对象或关系', '想认识能把话说清楚的人。忙就说忙，不想聊也可以直说，别让我一直猜。'),
    ('daily', '职场', '聊工作中的具体困惑', '下班以后还要秒回工作消息吗？我想把通知关了，又怕明天被问怎么没看见。'),
    ('daily', '生活', '向社区征求生活建议', '想做饭又不想洗一堆锅，有没有一道菜就能解决晚饭的办法？'),
    ('buddies', '找搭子', '发一个有边界的搭子邀请', '想找个能偶尔一起散步的搭子，不用天天报到，也不用硬找话题。'),
    ('love', '恋爱观', '谈自己的感情边界，不捏造恋情', '恋爱以后还能和朋友单独出去吗？我觉得可以，但隐瞒行程又是另一回事。'),
    ('daily', '吐槽', '表达一个自己的不满，让别人能接话', '最烦约好了又一直不定时间。能来就来，不能来也说一声，别让别人空等。'),
    ('daily', '消费', '问购买选择，不虚构交易', '买东西你们会为了满减多凑一件吗？我每次都觉得省了，最后又花得更多。'),
    ('gaming', '游戏', '提出一个可争论的游戏话题', '玩游戏到底是赢重要还是玩得开心重要？嘴上说随便，输了又生气的最难一起玩。'),
    ('daily', '防骗', '讨论可疑行为，不提供真实诈骗交易', '刚认识就让你转去别的平台聊，还说有稳赚的门路，你们会直接拉黑还是先问清楚？'),
    ('love', '处CP', '讨论处CP的期待，不自动建立关系', '有人把处CP当游戏搭子，有人当认真恋爱。开始之前能不能先把这件事说清楚？'),
    ('daily', '社区闲聊', '抛一个轻松但能有不同意见的话题', '聊天隔了半天才回，你们还会接着原来的话题吗？我经常想回，又觉得已经过时了。'),
    ('gaming', '新手局', '明确一个新手友好的组局安排', '想组个可以慢慢讲规则的新手局。有人需要先看一轮的吗？我不想一开局就听见“这都不会”。'),
    ('gaming', '固定队', '讨论固定队的边界', '固定队是不是默认每天都要来？我喜欢有人一起玩，但不想下班以后还得打卡。'),
    ('gaming', '复盘', '问具体的游戏沟通问题', '复盘的时候能不能一次只说一个问题？七嘴八舌一起指挥，我反而完全听不进去。'),
    ('gaming', '观战', '邀请先围观再参与', '有没有想玩又怕跟不上规则的？可以先围观，不强迫开麦，等你想下场了再说。'),
    ('gaming', '匹配', '讨论匹配和输赢', '匹配到喜欢指挥但自己不报信息的队友，你们会开口还是直接静音？我不想一晚上都在吵。'),
    ('gaming', '游戏社交', '讨论游戏和恋爱的不同期待', '游戏里的绑定关系，你们会当真吗？我觉得至少要先说清楚，别一个在开玩笑一个认真了。'),
    ('gaming', '组局时间', '征求可行的游戏时间', '上班的人到底怎么凑齐一整局？想约个不用熬夜、也不临时拉人的时间。'),
    ('gaming', '退坑', '讨论休息而非制造退坑事实', '玩游戏开始像做任务的时候，你们会歇几天吗？我不想把原来喜欢的东西也玩成负担。'),
    ('gaming', '游戏搭子', '找沟通方式相近的队友', '找一起玩的搭子，比段位更在意不阴阳怪气。菜能练，句句夹枪带棒我真接不住。'),
    ('love', '找对象', '说明自己的交往期待而非替他人承诺', '想认识能从普通聊天开始的人。别刚加上就叫宝宝，我连你平时喜欢干什么都还不知道。'),
    ('cp', '滴CP', '公开自己的处CP边界', '有想从搭子慢慢处CP的吗？先聊兴趣和作息，不搞几天热情过了就消失的那种。'),
    ('love', '公开关系', '讨论是否公开关系，不造已有关系', '公开关系要双方都愿意才算吧？我不喜欢还没说好，就被别人替我官宣。'),
    ('love', '暧昧边界', '表达对暧昧的看法', '没确定关系就可以同时暧昧好几个吗？我知道每个人想法不同，但至少别说“只有你”。'),
    ('love', '分手', '谈分手后的边界，不指控任何角色', '分开以后还能不能当朋友，我觉得得看怎么分开的。不是一句“都过去了”就能把难受删掉。'),
    ('love', '吃醋', '区分自己的感受与对他人的要求', '吃醋的时候你们会直说吗？我怕说了像管太多，不说又容易越想越歪。'),
    ('love', '承诺', '讨论忠诚与不同关系期待', '能接受什么关系先说清楚。想自由就别许独占的承诺，答应了又瞒着人，是另一回事。'),
    ('vent', '朋友边界', '表达对人际关系的不满', '有些人只在需要帮忙的时候出现。不是不能帮，但偶尔也想被问一句最近过得怎样。'),
    ('buddies', '饭搭子', '邀请轻松的共同活动', '想找吃饭不催人拍照、也不嫌人拍照的饭搭子。口味不同可以各点各的，别替我决定。'),
    ('buddies', '周末', '征求低负担出门计划', '周末想出去走走，但不想把行程排满。有人也喜欢到哪儿算哪儿的吗？'),
    ('daily', '外卖', '比较生活选择', '一到饭点就不知道吃什么，等想好了又快过饭点。你们有没有那种闭眼点也不会后悔的组合？'),
    ('daily', '租房', '问具体的生活经验', '租房最容易忽略的是隔音还是采光？照片都挺漂亮，住进去才知道晚上能听见几层楼。'),
    ('vent', '工作消息', '讨论下班后可执行的边界', '工作群里的“收到请回复”，到底是谁先发明的？人都已经回家了，怎么还像坐在工位上。'),
    ('gossip', '围观边界', '对公开争议提问，不生成黑料', '看社区争论的时候，你们会把当事人的回应也看完吗？我现在不太敢只看第一张截图就站队。'),
    ('redflag', '避雷讨论', '讨论证据标准，不能捏造具体指控', '避雷帖到底该写到什么程度？我想看的是发生了什么和怎么处理的，只有一串骂人的话反而看不懂。'),
    ('gossip', '钓鱼', '辨别挑衅话题而不指控个人', '有些帖一看就在钓鱼，可我还是忍不住想回一句。你们能忍住不点评论区吗？'),
    ('daily', '社区积分', '讨论社区内可疑积分邀约，不发交易指令', '如果有人说送社区积分，但要先交一笔积分保证金，你会信吗？我宁可不要，也不想先倒贴。'),
    ('daily', '消费避坑', '问消费时如何验证评价', '评价全是同一句话的东西，你们敢买吗？看着满屏好评，我反而开始怀疑自己是不是进错地方了。'),
    ('daily', '表达习惯', '讨论聊天中的不同习惯', '有人发一长段，有人拆成十条。我知道只是习惯不同，但通知一直响的时候真以为出大事了。'),
)


def public_intent(persona, actor, now):
    seed = int(hashlib.sha256(actor.encode()).hexdigest()[:8], 16)
    recent = '\n'.join(persona.get('recent_posts', []))
    preferred = 'gaming' if any(x in persona.get('interests', []) for x in ('游戏', '狼人杀', '麻将', '桌游')) else None
    choices = tuple((str(index), intent) for index, intent in enumerate(INTENTS)
                    if (not preferred or intent[0] == preferred)
                    and not (persona.get('has_commitment') and partner_ad(intent[0], intent[1])))
    used = {entry['id'] for entry in topic_history(persona.get('life', {}), now)}
    # Personal goals are available alongside broad topics, without assigning a
    # fixed dramatic role to an actor or fabricating an event about somebody else.
    goals = persona.get('goals', [])
    if isinstance(goals, str): goals = [goals]
    for index, goal in enumerate(goals if isinstance(goals, list) else []):
        if isinstance(goal, str) and goal.strip():
            channel = preferred or 'daily'
            choices += (('goal-' + str(index), (channel, '近况', '谈自己的一个近期目标并征求意见',
                        '最近想把“' + goal[:70] + '”这件事推进一下。有人做过类似的事吗？想听点踩过坑的经验。')),)
    personal = personal_intents(actor)
    pools = (personal, choices) if len(used) % 3 != 2 else (choices, personal)
    for pool in pools:
        if not pool: continue
        start = (seed + int(now // 3600)) % len(pool)
        for offset in range(len(pool)):
            identity, (channel, tag, goal, fallback) = pool[(start + offset) % len(pool)]
            if fallback not in recent and identity not in used:
                return dict(id=identity, channel=channel, tag=tag, goal=goal, fallback=fallback)
    return None


def partner_ad(channel, tag):
    return channel == 'cp' or tag in ('找对象', '滴CP', '交友')


REPLIES = (
    (('游戏', '狼人杀', '桌游', '开黑', '麻将', '海龟汤'), (
        '新手可以先看一轮，把规则说清楚再开始，别上来就催。',
        '我比较在意大家能不能正常沟通，输了复盘就好，别每句话都像在找人背锅。',
        '先把方便的时间对一下？有的人能聊，但不一定能连续空出一整局。',
        '如果只是休闲局，我觉得没必要要求所有人都同一个水平。想冲分就提前写清楚。',
        '可以先约短一点的局试试，玩不来就算了，别第一天就绑成固定队。')),
    (('恋爱', '对象', 'CP', '暧昧', '分手', '喜欢', '出轨'), (
        '我最在意有没有提前说清楚。两个人期待不一样，后面很容易都觉得委屈。',
        '这个我会直接问，猜来猜去太累了。对方不愿意回答，也算一种回答。',
        '喜欢归喜欢，自己的生活还是得留着。一直等消息的话，心情太容易被牵着走。',
        '不想继续可以说，不必把话说得很难听。但故意吊着人，我确实接受不了。',
        '我会先看对方实际怎么做，嘴上说得再好听，跟行动对不上也没用。')),
    (('工作', '加班', '下班', '领导', '同事'), (
        '我会先问清楚是今天必须完成，还是只是现在想起来了。这两种我处理得不一样。',
        '关掉提醒以前我也会纠结，不过一直在线真的很难休息。',
        '这事最好把要求留下记录，不然到最后很容易又变成自己理解错了。')),
    (('做饭', '外卖', '晚饭', '美食', '吃饭', '烘焙'), (
        '我投简单好收拾的那种，吃完还要洗半天锅，真的会打消下一次做饭的念头。',
        '看着好吃和天天愿意吃还是两回事，我现在先选不会太折腾的。',
        '有没有口味限制？不然推荐半天，可能刚好都是你不爱吃的。')),
    (('避雷', '挂人', '诈骗', '截图', '传闻', '瓜田'), (
        '我想先看完整的公开经过，尤其是当事人的回应。只有结论的话，我暂时站不了队。',
        '如果后面有澄清，也希望放在同一个地方，不然大家只记得最早那条。',
        '能不能先把亲眼看到的和听说的分开？这两种我愿意相信的程度不一样。')),
    (('好友', '朋友', '搭子', '交友', '散步'), (
        '我喜欢不用天天报到的相处，有想聊的能接上，忙的时候也不互相追问。',
        '先从一个小活动开始就挺好，聊得来再继续，别一开始就把期待拉满。',
        '能把不方便直接说出来，对我反而是加分项，总比一直猜舒服。')),
    (('摄影', '手帐', '读书', '音乐', '插画', '电影'), (
        '先做一小段试试看呢？一下子定太大的目标，我自己就很容易拖着不开头。',
        '想看看你更偏哪种风格，我喜欢的未必刚好适合你。',
        '这个我倒想听听过程，成品看起来简单，实际做的时候应该会碰到不少小问题。')),
)


def comment_fallback(persona, actor, source, previous=(), names=()):
    text = source['text'] + ' ' + source['post_text']
    # Answer the actual question before falling back to a broader subject. Never
    # invent a start time or pretend a reservation already exists.
    if any(word in source['text'] for word in ('几点', '什么时间', '啥时候', '什么时候')):
        variants = ('具体时间还得对一下，你什么时段方便？我不想先定了又让人白等。',
                    '时间还没定吧？先让想来的人报一下能空出来的时段。',
                    '先别光说今晚，有人下班晚。约之前把开始和结束的时间都说一下？',
                    '我没看到楼主定时间，等楼主确认吧，免得各等各的。',
                    '这局预计玩多久也说一下吧，开始时间合适不代表能一直待到散场。')
    else:
        variants = next((items for words, items in REPLIES if any(word.casefold() in text.casefold() for word in words)), None)
    if variants is None:
        variants = ('我可能会先问清楚对方具体想怎样，再决定要不要接着聊。',
                    '这件事我想听你多讲一点，最让你在意的是哪一部分？',
                    '我跟你想的有一点不一样，不过想先把前后的情况听完。',
                    '如果只是问我的选择，我会给自己留一点余地，不急着把话说死。')
    history = [*previous, *(row['text'] for row in persona.get('discussion', [])
                           if isinstance(row, dict) and isinstance(row.get('text'), str))]
    names = [*names, source['name'], source.get('author', ''),
             *(row.get('name', '') for row in persona.get('discussion', []) if isinstance(row, dict))]
    seed = int(hashlib.sha256((actor + source['id']).encode()).hexdigest()[:8], 16)
    for offset in range(len(variants)):
        reply = '@' + source['name'] + ' ' + variants[(seed + offset) % len(variants)]
        if new_comment(reply, history, names):
            return reply
    # An unavailable model must not turn a full fallback pool into a chorus.
    return ''
