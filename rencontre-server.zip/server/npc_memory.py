"""Durable NPC recollections that retain and recheck their original sources."""
import re
import secrets


def schema_ready(db, key, version, objects, snapshot=None):
    """Check a component marker and its trusted schema names without a write.

    Names are module constants, included as SQL literals so ScopedConnection
    can apply the current archive namespace during schema introspection.
    """
    if snapshot is not None:
        return snapshot['markers'].get(key)==str(version) and set(objects)<=snapshot['objects']
    names=','.join("'"+name+"'" for name in objects)
    return bool(db.execute('SELECT EXISTS(SELECT 1 FROM community_meta WHERE key=? AND value=?) '
                           'AND (SELECT COUNT(*) FROM sqlite_master WHERE name IN ('+names+'))=?',
                           (key,str(version),len(objects))).fetchone()[0])


MEMORY_SCHEMA_VERSION = 1
MEMORY_SCHEMA_OBJECTS = ('npc_memory_sources','npc_memory_source_room','npc_memory_source_subject')


def _terms(text):
    """Match Latin words and Chinese characters without a remote tokenizer."""
    return set(re.findall(r'[^\W_]+', re.sub(r'([\u3400-\u9fff])', r' \1 ', text.casefold()), re.UNICODE))


class ResidentMemory:
    def __init__(self, community):
        self.c = community
        self.store = community.store
        if self.store.schema_ready:
            snapshot=getattr(self.store,'schema_snapshot',None)
            if snapshot is not None and schema_ready(None,'npc-memory-schema',MEMORY_SCHEMA_VERSION,
                                                     MEMORY_SCHEMA_OBJECTS,snapshot):return
            with self.store.db() as db:
                if schema_ready(db,'npc-memory-schema',MEMORY_SCHEMA_VERSION,MEMORY_SCHEMA_OBJECTS):return
        with self.store.db(write=True) as db:
            if self.store.schema_ready and schema_ready(db,'npc-memory-schema',MEMORY_SCHEMA_VERSION,MEMORY_SCHEMA_OBJECTS):return
            db.executescript('''
CREATE TABLE IF NOT EXISTS npc_memory_sources(
    id TEXT PRIMARY KEY,actor TEXT,source_kind TEXT,source_id TEXT,
    room_id TEXT,subject_actor TEXT,summary TEXT,created REAL,
    UNIQUE(actor,source_kind,source_id,subject_actor));
CREATE INDEX IF NOT EXISTS npc_memory_source_room
    ON npc_memory_sources(actor,room_id,subject_actor,source_kind,created);
CREATE INDEX IF NOT EXISTS npc_memory_source_subject
    ON npc_memory_sources(actor,source_kind,subject_actor,created);
''')
            db.execute("INSERT INTO community_meta(key,value) VALUES('npc-memory-schema',?) "
                       'ON CONFLICT(key) DO UPDATE SET value=excluded.value',(str(MEMORY_SCHEMA_VERSION),))

    @staticmethod
    def _remember(db, actor, kind, source_id, room_id, subject_actor, summary, created):
        if not summary or not summary.strip():
            return False
        db.execute('INSERT OR IGNORE INTO npc_memory_sources '
                   '(id,actor,source_kind,source_id,room_id,subject_actor,summary,created) '
                   'VALUES(?,?,?,?,?,?,?,?)',
                   (secrets.token_hex(12), actor, kind, source_id, room_id, subject_actor, summary[:800], created))
        return True

    def remember_message(self, npc_actor, message_id):
        with self.store.db(write=True) as db:
            source = db.execute('''
SELECT m.room_id,m.actor_id,m.text,m.created FROM messages m
JOIN npcs n ON n.actor=?
JOIN members observer ON observer.room_id=m.room_id AND observer.actor_id=n.actor
JOIN members sender ON sender.room_id=m.room_id AND sender.actor_id=m.actor_id
LEFT JOIN message_details d ON d.message_id=m.id
WHERE m.id=? AND COALESCE(d.kind,'') NOT IN ('recalled','poke')
''', (npc_actor, message_id)).fetchone()
            if source is None:
                return False
            return self._remember(db, npc_actor, 'message', message_id, source['room_id'],
                                  source['actor_id'], source['text'], source['created'])

    def remember_event(self, npc_actor, event_id):
        with self.store.db(write=True) as db:
            source = db.execute('''
SELECT e.actor,e.target_actor,e.summary,e.created FROM npc_public_events e
JOIN npcs observer ON observer.actor=?
JOIN npcs author ON author.actor=e.actor
WHERE e.id=? AND (COALESCE(e.target_actor,'')='' OR
    EXISTS(SELECT 1 FROM npcs target WHERE target.actor=e.target_actor))
''', (npc_actor, event_id)).fetchone()
            if source is None:
                return False
            return self._remember(db, npc_actor, 'public_event', event_id, '',
                                  source['target_actor'] or source['actor'], source['summary'], source['created'])

    def recall(self, npc_actor, query, *, room_id='', subject_actor='', public=False, limit=8):
        limit = max(0, min(8, int(limit)))
        if not limit or not public and (not room_id or not subject_actor):
            return []
        with self.store.db() as db:
            if public:
                sources = db.execute('''
SELECT s.source_id,s.room_id,s.subject_actor,e.summary,e.created
FROM npc_memory_sources s
JOIN npcs observer ON observer.actor=s.actor
JOIN npc_public_events e ON e.id=s.source_id
JOIN npcs author ON author.actor=e.actor
WHERE s.actor=? AND s.source_kind='public_event' AND s.room_id=''
    AND s.subject_actor=COALESCE(NULLIF(e.target_actor,''),e.actor)
    AND (COALESCE(e.target_actor,'')='' OR
        EXISTS(SELECT 1 FROM npcs target WHERE target.actor=e.target_actor))
''', (npc_actor,)).fetchall()
            else:
                sources = db.execute('''
SELECT s.source_id,s.room_id,s.subject_actor,m.text AS summary,m.created
FROM npc_memory_sources s
JOIN npcs n ON n.actor=s.actor
JOIN messages m ON m.id=s.source_id AND m.room_id=s.room_id AND m.actor_id=s.subject_actor
JOIN members observer ON observer.room_id=m.room_id AND observer.actor_id=s.actor
JOIN members sender ON sender.room_id=m.room_id AND sender.actor_id=m.actor_id
LEFT JOIN message_details d ON d.message_id=m.id
WHERE s.actor=? AND s.source_kind='message' AND s.room_id=? AND s.subject_actor=?
    AND COALESCE(d.kind,'') NOT IN ('recalled','poke')
''', (npc_actor, room_id, subject_actor)).fetchall()
        terms = _terms(query or '')
        ranked = sorted(sources, key=lambda row: (
            len(terms & _terms(row['summary'] or '')), row['created'] or 0, row['source_id']), reverse=True)
        return [{'summary': row['summary'][:800], 'source_id': row['source_id'],
                 'room_id': row['room_id'], 'subject_actor': row['subject_actor']}
                for row in ranked[:limit] if row['summary'] and row['summary'].strip()]
