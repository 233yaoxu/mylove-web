"""Source-bound room AI leases; callers retain the existing write transaction."""
import secrets

from fastapi import HTTPException


def _check(value, message):
    if not value:
        raise HTTPException(409, message)


def _same_token(left, right):
    return (isinstance(left, str) and isinstance(right, str)
            and secrets.compare_digest(left.encode('utf-8'), right.encode('utf-8')))


def _context(db, rid):
    # One database round trip, even on the cloud store. All source sequence
    # numbers come from this room's authoritative message rows.
    row = db.execute('''SELECT
        COALESCE((SELECT MAX(seq) FROM messages WHERE room_id=?),0) AS context_seq,
        (SELECT actor_id FROM messages WHERE room_id=? ORDER BY seq DESC LIMIT 1) AS last_actor,
        COALESCE((SELECT MAX(m.seq) FROM messages m JOIN actors a ON a.id=m.actor_id
                  WHERE m.room_id=? AND a.kind='user'),0) AS latest_human_seq,
        (SELECT m.created FROM messages m JOIN actors a ON a.id=m.actor_id
         WHERE m.room_id=? AND a.kind='user' ORDER BY m.seq DESC LIMIT 1) AS human_created''',
        (rid, rid, rid, rid)).fetchone()
    return dict(row)


def _context_lease(lease):
    return (isinstance(lease, dict) and type(lease.get('context_seq')) is int
            and type(lease.get('latest_human_seq')) is int
            and type(lease.get('context_revision')) is int
            and lease['context_seq'] >= 0 and lease['latest_human_seq'] >= 0
            and lease['context_revision'] >= 0)


def _processed(ai, actor_id):
    values = ai.get('processed_context')
    value = values.get(actor_id) if isinstance(values, dict) else None
    return value if type(value) is int else -1


def claim_turn(db, rid, actor_id, ai, current, lease_id, room_kind='group', lease_seconds=90):
    """Reserve one generation source; the caller persists rooms.ai atomically.

    Existing max_auto, cooldown, membership and owner checks remain the caller's
    responsibility. An active generation keeps its lease until exact release or
    expiration, even when new human messages make its future result obsolete.
    """
    active = ai.get('lease')
    _check(not isinstance(active, dict) or active.get('expires', 0) <= current,
           '回合已被其他客户端领取')
    context = _context(db, rid)
    _check(context['last_actor'] != actor_id, '请等待其他身份回应后再继续')
    if room_kind == 'group' and context['human_created'] is not None:
        _check(current - context['human_created'] >= 2, '正在合并连续消息，请稍后再回复')
    _check(context['context_seq'] > _processed(ai, actor_id), '这个消息上下文已回复，请等待新消息')
    lease = {'id': lease_id, 'actor': actor_id, 'expires': current + lease_seconds,
             'context_seq': context['context_seq'], 'latest_human_seq': context['latest_human_seq'],
             'context_revision': ai.get('context_revision', 0)}
    ai['lease'] = lease
    return lease


def validate_turn(db, rid, actor_id, ai, lease_id, current):
    """Reject obsolete generated text before its INSERT or reply counter update."""
    lease = ai.get('lease')
    _check(isinstance(lease, dict) and lease.get('actor') == actor_id
           and _same_token(lease.get('id'), lease_id)
           and lease.get('expires', 0) > current, 'AI 租约无效或已过期')
    _check(_context_lease(lease), 'AI 回合缺少消息来源，请重新领取')
    _check(lease['context_revision'] == ai.get('context_revision', 0),
           '消息内容已更新，请读取最新上下文后重试')
    context = _context(db, rid)
    _check(context['latest_human_seq'] == lease['latest_human_seq']
           and context['context_seq'] >= lease['context_seq'],
           '新消息已到达，请合并最新上下文后重试')
    _check(lease['context_seq'] > _processed(ai, actor_id), '这个消息上下文已回复')
    return lease


def complete_turn(ai, lease):
    """Mark only this completed source, never the entire human-message burst."""
    active = ai.get('lease')
    _check(isinstance(active, dict) and isinstance(lease, dict)
           and active.get('id') == lease.get('id') and active.get('actor') == lease.get('actor'),
           'AI 回合已更新，请勿重复发送')
    if _context_lease(lease):
        values = ai.get('processed_context')
        values = dict(values) if isinstance(values, dict) else {}
        values[lease['actor']] = max(_processed(ai, lease['actor']), lease['context_seq'])
        ai['processed_context'] = values
    ai['lease'] = None


def release_turn(ai, actor_id, lease_id=''):
    """An old request cannot cancel another generation, including the same AI."""
    lease = ai.get('lease')
    if not isinstance(lease, dict) or lease.get('actor') != actor_id:
        return False
    if not lease_id or not _same_token(lease.get('id'), lease_id):
        return False
    ai['lease'] = None
    return True
