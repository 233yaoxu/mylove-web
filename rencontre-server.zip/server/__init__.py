"""Rencontre LAN service. Importing this package never creates a database."""
