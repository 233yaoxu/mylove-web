﻿param([switch]$Lan,[ValidateRange(1,65535)][int]$Port=9891,[string]$Python,[string]$Database)
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
$OutputEncoding=[Console]::OutputEncoding
$env:PYTHONIOENCODING='utf-8'
$serviceDir=$PSScriptRoot
$projectDir=Split-Path -Parent $serviceDir
$runtime=Join-Path $serviceDir '.venv/Scripts/python.exe'
if(-not (Test-Path -LiteralPath $runtime)) {
    $candidates=@()
    if($Python){$candidates+=@([pscustomobject]@{Exe=$Python;Args=@()})}
    $launcher=Get-Command py -ErrorAction SilentlyContinue
    if($launcher){$candidates+=@([pscustomobject]@{Exe=$launcher.Source;Args=@('-3.12')},[pscustomobject]@{Exe=$launcher.Source;Args=@('-3.13')})}
    $installed=Get-Command python -ErrorAction SilentlyContinue
    if($installed){$candidates+=@([pscustomobject]@{Exe=$installed.Source;Args=@()})}
    $bundled=Join-Path $env:USERPROFILE '.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
    if(Test-Path -LiteralPath $bundled){$candidates+=@([pscustomobject]@{Exe=$bundled;Args=@()})}
    $selected=$null
    foreach($candidate in $candidates){
        try {
            $exe=$candidate.Exe;$prefix=@($candidate.Args)
            & $exe @prefix -c 'import sys; sys.exit(0 if (3,12) <= sys.version_info[:2] <= (3,13) else 1)' 2>$null
            if($LASTEXITCODE -eq 0){$selected=$candidate;break}
        } catch {}
    }
    if(-not $selected){throw '需要 Python 3.12 或 3.13。安装后重试，或运行 start.ps1 -Python 完整python.exe路径。'}
    $exe=$selected.Exe;$prefix=@($selected.Args)
    & $exe @prefix -m venv (Join-Path $serviceDir '.venv')
    if($LASTEXITCODE -ne 0){throw '无法创建服务运行环境。'}
}
& $runtime -c 'import importlib.util,sys;sys.exit(0 if all(importlib.util.find_spec(n) for n in (''fastapi'',''uvicorn'',''websockets'',''PIL'')) else 1)'
if($LASTEXITCODE -ne 0){
    Write-Output '首次启动正在安装本地服务依赖…'
    & $runtime -m pip install -r (Join-Path $serviceDir 'requirements.txt')
    if($LASTEXITCODE -ne 0){throw '依赖安装失败，请检查网络后重试。'}
}
Write-Output '当前为局域网模式；电脑需保持开机。关闭本窗口或按 Ctrl+C 停止服务。'
Write-Output "本机社区：http://127.0.0.1:$Port/rencontre/"
Write-Output "服务地址：http://127.0.0.1:$Port"
if($Lan){
    Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object {
        $_.IPAddress -match '^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)' -and $_.AddressState -eq 'Preferred'
    } | Select-Object -ExpandProperty IPAddress -Unique | ForEach-Object { Write-Output "手机内 Rencontre 服务地址：http://${_}:$Port" }
    Write-Output '手机与电脑连接同一 Wi-Fi，并在 Windows 防火墙提示中按需允许专用网络。'
}
$listenAddress=if($Lan){'0.0.0.0'}else{'127.0.0.1'}
Push-Location -LiteralPath $projectDir
try {
    $serviceArgs=@('-m','server','--host',$listenAddress,'--port',"$Port")
    if($Database){$serviceArgs+=@('--db',$Database)}
    & $runtime @serviceArgs
}
finally { Pop-Location }
if($LASTEXITCODE -ne 0){throw '服务已退出，请查看上方错误。'}
