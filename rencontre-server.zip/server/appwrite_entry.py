"""Appwrite Functions HTTP boundary with request-local dispatch credentials.

Only this adapter sees the platform's short-lived request key.  Business HTTP
continues to use the existing Bearer/session and archive checks.
"""
import asyncio
from contextvars import ContextVar
import ipaddress
import json
import os
import re
import threading
import urllib.error
import urllib.request

from starlette.exceptions import HTTPException


WORKER_PATH = '/_internal/npc-worker'
_request_key = ContextVar('rencontre_appwrite_request_key', default='')
_runtime = None
_runtime_lock = threading.Lock()
_IDENTIFIER = re.compile(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,35}\Z')


def current_request_key():
    """Return the current invocation's key without placing it in ASGI state."""
    return _request_key.get()


def _rate_limit_client(headers):
    # This platform-injected IP is only a rate-limit bucket, never identity or
    # authorization. Arbitrary forwarding headers cannot change this value.
    value = headers.get('x-appwrite-client-ip', '')
    if not value or len(value) > 45 or '%' in value:
        return None
    try:
        return str(ipaddress.ip_address(value)), 0
    except ValueError:
        return None


def _json(context, value, status=200):
    body = json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode()
    return context.res.binary(body, status, {'content-type': 'application/json; charset=utf-8',
                                           'cache-control': 'no-store'})


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, msg, headers, newurl):
        return None


def submit_execution(envelope, request_key):
    """Submit this function's signed worker without retaining the request key."""
    endpoint = os.environ.get('APPWRITE_FUNCTION_API_ENDPOINT', '').rstrip('/')
    project = os.environ.get('APPWRITE_FUNCTION_PROJECT_ID', '')
    function = os.environ.get('APPWRITE_FUNCTION_ID', '')
    if (not re.fullmatch(r'https://[a-z0-9-]+\.cloud\.appwrite\.io/v1', endpoint)
            or not _IDENTIFIER.fullmatch(project) or not _IDENTIFIER.fullmatch(function)
            or not isinstance(request_key, str) or not 1 <= len(request_key) <= 8192):
        raise RuntimeError('Cloud queue is not configured')
    try:
        body = json.dumps(envelope, sort_keys=True, separators=(',', ':'),
                          ensure_ascii=True, allow_nan=False)
        if len(body) > 4096:
            raise ValueError()
        payload = json.dumps({'async': True, 'path': WORKER_PATH, 'method': 'POST',
                              'headers': {}, 'body': body}, separators=(',', ':')).encode()
        request = urllib.request.Request(endpoint + '/functions/' + function + '/executions',
            data=payload, method='POST', headers={'Content-Type': 'application/json',
                'X-Appwrite-Project': project, 'X-Appwrite-Key': request_key})
        with urllib.request.build_opener(_NoRedirect()).open(request, timeout=5) as response:
            if response.status not in (201, 202):
                raise ValueError()
            raw = response.read(16_385)
            if len(raw) > 16_384:
                raise ValueError()
            value = json.loads(raw)
            execution = value.get('$id') if isinstance(value, dict) else None
            if not isinstance(execution, str) or not _IDENTIFIER.fullmatch(execution):
                raise ValueError()
            return execution
    except urllib.error.HTTPError as error:
        error.close()
        raise RuntimeError('Cloud queue submission failed') from None
    except Exception:
        raise RuntimeError('Cloud queue submission failed') from None


def get_runtime():
    """Create the shared app only on its first execution, never during import."""
    global _runtime
    if _runtime is None:
        with _runtime_lock:
            if _runtime is None:
                # Require durable remote storage and disable local daemon loops.
                os.environ['RENCONTRE_SERVERLESS'] = '1'
                from .app import create_app
                from .npc_dispatch import Dispatcher
                app = create_app()
                dispatcher = Dispatcher(app, submit_execution)
                app.state.npc_dispatcher = dispatcher
                _runtime = AppwriteAdapter(app, dispatcher)
    return _runtime


async def main(context):
    """The Python runtime invokes main from an already-running event loop."""
    try:
        adapter = await asyncio.to_thread(get_runtime)
        return await adapter.async_call(context)
    except Exception:
        return _json(context, {'detail': '云端服务暂时不可用，请稍后重试'}, 503)


class AppwriteAdapter:
    def __init__(self, app, dispatcher):
        self.app, self.dispatcher = app, dispatcher

    def __call__(self, context):
        """Convenience for local callers without an active event loop."""
        return asyncio.run(self.async_call(context))

    async def async_call(self, context):
        headers = {str(name).lower(): str(value) for name, value in context.req.headers.items()}
        # Signed workers never need an execution key. Avoid carrying it into
        # their blocking database/model work in a separate thread.
        token = _request_key.set(headers.get('x-appwrite-key', '')
                                 if context.req.path != WORKER_PATH else '')
        try:
            body = context.req.body_binary
            if not isinstance(body, bytes):
                raise ValueError()
            path, method = context.req.path, context.req.method.upper()
            limit = 4096 if path == WORKER_PATH else 4_300_000 if path == '/api/images' else 100_000
            if len(body) > limit:
                return _json(context, {'detail': '请求内容过大，请缩小图片或文字后重试'}, 413)
            if path == WORKER_PATH:
                if method != 'POST':
                    return _json(context, {'detail': '此任务只接受 POST 请求'}, 405)
                envelope = json.loads(body)
                if not isinstance(envelope, dict):
                    raise ValueError()
                try:
                    value = await asyncio.to_thread(self.dispatcher.handle_worker, envelope)
                except HTTPException:
                    return _json(context, {'detail': '内部任务请求无效或已过期'}, 403)
                return _json(context, value)
            scope = {
                'type': 'http', 'asgi': {'version': '3.0', 'spec_version': '2.3'},
                'http_version': '1.1', 'method': method, 'scheme': context.req.scheme,
                'path': path, 'raw_path': path.encode('utf-8'), 'root_path': '',
                'query_string': context.req.query_string.encode('utf-8'),
                'headers': [(name.encode('latin-1'), value.encode('latin-1'))
                            for name, value in headers.items() if not name.startswith('x-appwrite-')],
                'client': _rate_limit_client(headers),
                'server': (context.req.host, int(context.req.port)), 'state': {},
            }
            status, response_headers, response_body = await self._http(scope, body)
            return context.res.binary(response_body, status, response_headers)
        except (TypeError, ValueError, UnicodeError):
            return _json(context, {'detail': '请求格式无效'}, 400)
        except Exception:
            # Runtime/provider errors may include headers or URLs. Never emit them.
            return _json(context, {'detail': '云端服务暂时不可用，请稍后重试'}, 503)
        finally:
            _request_key.reset(token)

    async def _http(self, scope, body):
        sent, status, headers, chunks, size = False, None, {}, [], 0

        async def receive():
            nonlocal sent
            if not sent:
                sent = True
                return {'type': 'http.request', 'body': body, 'more_body': False}
            # Returning an immediate disconnect races Starlette's response task.
            await asyncio.Event().wait()

        async def send(message):
            nonlocal status, headers, size
            if message['type'] == 'http.response.start':
                status = int(message['status'])
                headers = {name.decode('latin-1'): value.decode('latin-1')
                           for name, value in message['headers']
                           if name.lower() not in (b'connection', b'transfer-encoding')}
            elif message['type'] == 'http.response.body':
                data = message.get('body', b'')
                size += len(data)
                if size > 12_000_000:
                    raise ValueError()
                chunks.append(data)

        await self.app(scope, receive, send)
        if status is None:
            raise ValueError()
        return status, headers, b''.join(chunks)
